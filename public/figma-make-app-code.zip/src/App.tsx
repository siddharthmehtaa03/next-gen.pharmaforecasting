import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'
import Forecaster from './forecaster/Forecaster'
import {
  AlertCircle, AlertTriangle, ArrowLeft, ArrowUpDown, ArrowUp, ArrowDown, ArrowRight, BarChart3, Bell, Boxes, Check, CheckCircle2, ChevronDown, ChevronRight,
  Clock, Copy, Database, FileText, GitBranch, History, Info, Layers, Loader2, Lock, LockOpen, Plus,
  RefreshCw, RotateCcw, Search, Send, Settings2, ShieldAlert, ShieldCheck, SlidersHorizontal, Sparkles, TrendingUp, Upload, Download, Users, Workflow, X, Eye, Zap, ArrowUpRight, LogOut, Mail,
} from 'lucide-react'

/* ───────────────────────── Domain data (model taxonomy, working draft v2) ───────────────────────── */

type ArchId = 'D-01' | 'D-02' | 'D-03' | 'D-04' | 'D-05' | 'D-06' | 'D-07'
type Kind = 'input' | 'assumption' | 'derived'

// Engines differ in how they account for patients as state.
const ARCHETYPES: { id: ArchId; name: string; state: string; desc: string; note: string; unit: string; ev: string[]; review?: string }[] = [
  { id: 'D-01', name: 'Prevalent-Share', state: 'A standing pool', unit: 'Patients',
    desc: 'A pool of treated patients is re-stated each month and the brand captures a share of it. No memory of how patients arrived.',
    note: 'Share is rarely one number — nested cascades up to three levels, paths from parameterized curves.',
    ev: ['A-25 Cibinqo US', 'A-26 Hemophilia', 'A-31 Velsipity spec'] },
  { id: 'D-02', name: 'Rx-Share', state: 'No patients — prescriptions', unit: 'Scripts',
    desc: 'A basket of prescriptions defines the market, market volume is trended forward, and the brand takes a share of the basket.',
    note: 'Cousin of Prevalent-Share: the unit of account changes what downstream conversion math must do.',
    ev: ['A-22 Nurtec 1912', 'A-23 LES model'] },
  { id: 'D-03', name: 'Patient-Flow', state: 'Flowing cohorts', unit: 'Cohorts over time',
    desc: 'Patients start in month zero and stay on therapy along a decay curve. Volume is start cohorts convolved with persistency.',
    note: 'Boundary cases are configurations: incidence capture (Paxlovid) and days-of-therapy share (anti-infectives).',
    ev: ['A-18 Orgovyx', 'A-17 Elranatamab US', 'A-15 Lorlatinib ex-US', 'A-27 Paxlovid', 'A-29 Anti-infectives', 'A-32 Lorbrena US'] },
  { id: 'D-04', name: 'Brand Inflow-Outflow', state: 'A standing brand stock', unit: 'Stock of patients',
    desc: 'The brand’s own patient stock, fed by a monthly start rate and drained by a monthly discontinuation probability.',
    note: 'Mathematically Patient-Flow with a memoryless discontinuation hazard — the stock version of the same physics.',
    review: 'Not in the six-family catalogue. Open question: legacy “inflow/outflow” term — may fold into Patient-Flow as its memoryless configuration.',
    ev: ['A-17 Elranatamab US', 'A-16 Ibrance family'] },
  { id: 'D-05', name: 'Market Stock-Flow', state: 'A depletable population', unit: 'Addressable stock',
    desc: 'A stock of available patients is captured each period, captured patients leave the stock, and new patients flow in.',
    note: 'The vaccine engine. Three conservation conventions share one skeleton.',
    ev: ['A-1 OneAndDone', 'A-2 PrimaryBooster', 'A-3 C. difficile', 'A-4 RSV US', 'A-5 Mening ex-US', 'A-33 Comirnaty US', 'A-34 RSV internationals', 'A-35 Prevenar Adult'] },
  { id: 'D-06', name: 'Trend / Extrapolation', state: 'An observed series', unit: 'Historical series',
    desc: 'Projects an observed history forward — as the forecast for a sub-segment, or blended into another archetype’s near term.',
    note: 'Usually a component, not the whole brand. Method, data window and granularity are always shown with the line.',
    ev: ['A-14 Braftovi+Mektovi', 'A-31 Adcetris spec'] },
  { id: 'D-07', name: 'Peak-Year Sizing', state: 'A peak-year estimate', unit: 'Peak patients & sales',
    desc: 'Sizes the peak opportunity from analogs, trial endpoints or research, across target product profile variants.',
    note: 'Screening grade by construction. Forecaster edits never re-grade it — that needs CoE reconfiguration and a new version.',
    ev: ['BD&L screening template', 'Business Assessment TPP deck'] },
]
const TREND = {
  id: 'D-06', name: 'Trend / Extrapolation',
  desc: 'Not a peer engine. Moving average, exponential smoothing or regression applied wherever a series needs extending.',
  ev: ['A-14 Braftovi+Mektovi', 'A-31 Adcetris spec'],
  uses: ['Project actuals forward', 'Blend near-term actuals into the model', 'Cover sub-segments not modeled structurally'],
  methods: ['Moving average', 'Exp. smoothing', 'Regression'],
}
type Step = { id: string; label: string; kind: Kind }
const CHAINS: Record<ArchId, Step[]> = {
  'D-01': [
    { id: 'pool', label: 'Treated pool', kind: 'input' },
    { id: 'treated', label: 'Treated rate', kind: 'assumption' },
    { id: 'share', label: 'Share cascade', kind: 'assumption' },
    { id: 'pts', label: 'Brand patients', kind: 'derived' },
    { id: 'vol', label: 'Volume (units)', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-02': [
    { id: 'basket', label: 'Rx basket', kind: 'input' },
    { id: 'trend', label: 'Market trend', kind: 'assumption' },
    { id: 'share', label: 'Brand share path', kind: 'assumption' },
    { id: 'trx', label: 'Brand scripts', kind: 'derived' },
    { id: 'vol', label: 'Volume (units)', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-03': [
    { id: 'elig', label: 'Eligible population', kind: 'input' },
    { id: 'starts', label: 'New starts (month 0)', kind: 'assumption' },
    { id: 'persist', label: 'Persistency decay', kind: 'assumption' },
    { id: 'onrx', label: 'Patients on therapy', kind: 'derived' },
    { id: 'vol', label: 'Volume (units)', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-04': [
    { id: 'stock', label: 'Opening brand stock', kind: 'input' },
    { id: 'inflow', label: 'Monthly start rate', kind: 'assumption' },
    { id: 'outflow', label: 'Discontinuation probability', kind: 'assumption' },
    { id: 'close', label: 'Closing stock', kind: 'derived' },
    { id: 'vol', label: 'Volume (units)', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-05': [
    { id: 'elig', label: 'Eligible stock', kind: 'input' },
    { id: 'cover', label: 'Coverage ceiling', kind: 'assumption' },
    { id: 'capture', label: 'Capture rate', kind: 'assumption' },
    { id: 'doses', label: 'Doses administered', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-06': [
    { id: 'hist', label: 'Historical series', kind: 'input' },
    { id: 'method', label: 'Method & window', kind: 'assumption' },
    { id: 'events', label: 'Event adjustments', kind: 'assumption' },
    { id: 'proj', label: 'Projected series', kind: 'derived' },
    { id: 'net', label: 'Net sales', kind: 'derived' },
  ],
  'D-07': [
    { id: 'addr', label: 'Addressable population', kind: 'input' },
    { id: 'pshare', label: 'Peak share (analog)', kind: 'assumption' },
    { id: 'price', label: 'Peak price', kind: 'assumption' },
    { id: 'ppts', label: 'Peak patients', kind: 'derived' },
    { id: 'psales', label: 'Peak-year sales', kind: 'derived' },
  ],
}

type ModeDef = { id: string; label: string; help: string; options: string[]; def?: string; dropdown?: boolean; optional?: boolean; showIf?: (m: Record<string, string>) => boolean }
const MODES: Record<ArchId, ModeDef[]> = {
  'D-01': [
    { id: 'share', label: 'Share specification', help: 'Whether forecasters edit a curve’s drivers or the shares themselves.', options: ['Curve-generated', 'Typed', 'Calibrated', 'Theft-derived'] },
    { id: 'cascade', label: 'Nesting depth', help: 'Conditional shares: class → brand, or three levels. Totals are checked at every level.', options: ['Flat', 'Class to brand', 'Three-level'] },
  ],
  'D-02': [
    { id: 'path', label: 'Share path', help: 'How the brand’s share of the basket moves.', options: ['Curve-family menu', 'Event-anchored', 'Calibrated'] },
    { id: 'unit', label: 'Rx basis', help: 'The denominator shown on every share chart. NRx / NBRx carry mix and refill.', options: ['TRx', 'NRx', 'NBRx'] },
    { id: 'trend', label: 'Market trend', help: 'Kept separate from brand share — two controls, never one.', options: ['Method-driven', 'Event-driven'] },
  ],
  'D-03': [
    { id: 'actuals', label: 'Actuals regime', help: 'Sets the actuals boundary and the calibration source for history.', options: ['Aggregate actuals ingestion', 'Claims-level actuals', 'Pre-launch (no actuals)'] },
    { id: 'retreat', label: 'Retreatment', help: 'Whether patients who stop can re-enter therapy, and how re-entry is tracked.', options: ['Excluded', 'Allowed', 'Typed re-entry'], optional: true },
    { id: 'lot', label: 'Line-of-therapy sourcing', help: 'Where each line’s patients come from.', options: ['Independent', 'Named Feeders', 'Progression-Derived'] },
    { id: 'persist', label: 'Persistence specification', help: 'How time on therapy is described.', options: ['Forward DoT', 'Aggregate Churn', 'Cohort KM'] },
  ],
  'D-04': [
    { id: 'inflow', label: 'Start rate', help: 'How the monthly inflow is set.', options: ['Fixed monthly rate', 'Share-curve driven'] },
    { id: 'hazard', label: 'Discontinuation', help: 'Memoryless by definition of this engine.', options: ['Constant probability', 'Standard-decay persistency'] },
  ],
  'D-05': [
    { id: 'convention', label: 'Conservation', help: 'US backlog depletion and international throughput are different templates — pick per market.', options: ['Depletion (US backlog)', 'Cohort-throughput (intl.)', 'Seasonal dose-basket'] },
    { id: 'inflow', label: 'Inflow rule', help: 'How new eligible patients enter the stock.', options: ['Target-seeking', 'Rate-based'] },
    { id: 'reentry', label: 'Re-entry', help: 'Waning and boosters are time-linked chains, not a one-off percentage.', options: ['None', 'Waning', 'Booster chain'], optional: true },
    { id: 'catchup', label: 'Catch-up', help: 'Separate coverage for cohorts that missed the routine schedule.', options: ['On', 'Off'], optional: true },
  ],
  'D-06': [
    { id: 'method', label: 'Method', help: 'Locked at publish — forecasters can’t switch methods afterwards.', options: ['Exp. smoothing', 'Moving average', 'Regression', 'Event-anchored'] },
    { id: 'role', label: 'Role', help: 'Whether the output is the forecast, or feeds another archetype.', options: ['Actuals projection', 'Blend', 'Standalone sub-segment'] },
    { id: 'grain', label: 'Granularity', help: 'Grain of the input series and the projection.', options: ['Monthly', 'Weekly', 'Annual'] },
  ],
  'D-07': [
    { id: 'source', label: 'Parameter sourcing', help: 'Every critical assumption carries evidence and a confidence grade.', options: ['Analog-anchored', 'Trial-endpoint', 'Research'] },
    { id: 'region', label: 'Regional method', help: 'Ex-US as a multiple of US, or built country by country.', options: ['US × analog factor', 'Bottom-up'] },
    { id: 'tpp', label: 'Scenario', help: 'Target product profile variants are compared side by side.', options: ['Base TPP', 'Base + upside / downside TPP'] },
  ],
}

// Output units and time basis apply to every engine; the rest are engine-specific (taxonomy working draft).
const OUTPUT_UNITS: Record<ArchId, string[]> = {
  'D-01': ['Patients', 'Days of therapy'], 'D-02': ['Scripts (TRx)', 'Units (packs)'], 'D-03': ['Patients', 'Patient-months', 'Units (packs)'],
  'D-04': ['Patients', 'Patient-months'], 'D-05': ['Doses', 'Vaccinated patients'], 'D-06': ['Units (packs)', 'Net sales'], 'D-07': ['Peak patients', 'Peak-year sales'],
}
const modesFor = (a: ArchId): ModeDef[] => [
  { id: 'units', label: 'Output units', help: 'The unit every engine output is labelled in, so patients, doses and days of therapy never mix.', options: OUTPUT_UNITS[a] },
  ...(a === 'D-06' ? [] : [{ id: 'time', label: 'Time basis', help: 'Calculation grain of the engine. Planning outputs are splined to the submission grain.', options: a === 'D-07' ? ['Annual', 'Peak year only', 'Custom'] : ['Monthly', 'Quarterly', 'Annual', 'Custom'] }]),
  ...MODES[a],
]
const customTimeErr = (m: Record<string, string>) => {
  const n = Number(m.time_n)
  if (!m.time_n || !Number.isInteger(n) || n < 1) return 'Enter a whole number of 1 or more.'
  if (m.time_from && m.time_to && Number(m.time_to) < Number(m.time_from)) return 'End year must not be before start year.'
  return ''
}
const modeDefault = (a: ArchId, m: ModeDef) => (a === 'D-03' && m.id === 'persist') ? 'Aggregate Churn' : m.def ?? m.options[0]
const ALL: ArchId[] = ['D-01', 'D-02', 'D-03', 'D-04', 'D-05', 'D-06', 'D-07']
type Mod = { id: string; code: string; name: string; cat: string; desc: string; ev: string[]; required?: ArchId[]; rec?: ArchId[]; data?: string; patients?: boolean; needs?: string }
const RAW: [string, string, string, string[], Partial<Mod>?][] = [
  ['Population & top-of-funnel', 'Epi funnel builder', 'Population → incidence/prevalence → staged filters → eligible; arbitrary filter steps.', ['A-15', 'A-26'], { rec: ['D-01', 'D-03'], data: 'epi', patients: true }],
  ['Population & top-of-funnel', 'Age-structured cohorts', 'Single-year-of-age stocks with aging in/out and mortality survival.', ['A-1', 'A-4'], { rec: ['D-05'], data: 'age', patients: true }],
  ['Population & top-of-funnel', 'Risk stratification', 'Risk-percentage splits of a population with per-group parameters.', ['A-3', 'A-4'], { rec: ['D-05'], patients: true }],
  ['Population & top-of-funnel', 'Testing / biomarker gates', 'Percent tested × percent positive; optionally time-dynamic testing rates.', ['A-15', 'A-16'], { patients: true }],
  ['Population & top-of-funnel', 'Analog / reference-market scaling', 'A market sized as a multiplier of another; analog curve libraries.', ['A-9', 'A-29']],
  ['Population & top-of-funnel', 'Named-feeder inflows', 'New patients arriving off a specified other brand at a realized share.', ['A-15'], { patients: true }],
  ['Population & top-of-funnel', 'External data ingestion', 'UN population, published epi, claims-derived counts, market-research surveys pulled into the funnel.', ['A-13', 'A-21', 'A-35']],
  ['Population & top-of-funnel', 'Clinical-trial absorption', 'Eligible patients netted out to competitor or own trials.', ['A-13', 'A-15'], { patients: true }],
  ['Population & top-of-funnel', 'Access & funding gates', 'Reimbursement percentages; public/private funding as a cohort dimension.', ['A-5', 'A-26']],
  ['Population & top-of-funnel', 'Catch-up flows', 'Separate coverage machinery for cohorts that missed the routine schedule.', ['A-5', 'A-4'], { rec: ['D-05'], patients: true }],
  ['Population & top-of-funnel', 'Anti-vaccination carve-out', 'Vaccine-hesitant population as an explicit stock removed from the eligible pool.', ['A-34'], { patients: true }],
  ['Segmentation & structure', 'Segment schema + replication', 'Declare segments (payer, age, country, indication); run the engine per segment.', ['A-24', 'A-1'], { required: ALL }],
  ['Segmentation & structure', 'Roll-up & reaggregation', 'Recombine forecast lines into brand totals with selection controls.', ['A-24'], { required: ALL }],
  ['Segmentation & structure', 'Channel / payer dimension', 'Per-channel capture rates inside the engine, not just reporting splits.', ['A-3', 'A-7'], { data: 'payer' }],
  ['Segmentation & structure', 'Indication grids', 'Indication × regimen instances for multi-indication assets.', ['A-21', 'A-14']],
  ['Segmentation & structure', 'Market-model wrapper', 'One epi pool, multi-asset share matrix, per-asset revenue, franchise view.', ['A-7', 'A-8']],
  ['Lines of therapy & disease states', 'Line as attribute', 'Line modulates compliance, dosing, price; pools sized independently.', ['A-17'], { patients: true }],
  ['Lines of therapy & disease states', 'Progression-derived pools', 'Next-line eligibility built from upstream drop-offs, month by month.', ['A-11', 'A-12', 'A-32'], { patients: true }],
  ['Lines of therapy & disease states', 'Relapse-lag transitions', 'Movement between disease states through a timing distribution.', ['A-13'], { patients: true }],
  ['Lines of therapy & disease states', 'Attribute-carrying cohorts', 'Upstream exposure constrains downstream eligibility (typed patient flows).', ['A-13', 'A-32'], { patients: true }],
  ['Lines of therapy & disease states', 'Retreatment policy', 'Allowed, excluded, or typed re-entry to therapy as a configuration.', ['A-12', 'A-15'], { rec: ['D-03'], patients: true }],
  ['Lines of therapy & disease states', 'Disease-state branch trees', 'Surgical or chemo eligibility branches run as parallel instances.', ['A-12'], { patients: true }],
  ['Share machinery', 'Nested share cascades', 'Conditional shares to arbitrary depth: class → subclass → brand.', ['A-22', 'A-26'], { rec: ['D-01'] }],
  ['Share machinery', 'Share-curve generators', 'Start, peak, launch date, shape, time-to-peak, erosion — parameterized paths.', ['A-15', 'A-11'], { required: ['D-01', 'D-02'], rec: ['D-03', 'D-04'] }],
  ['Share machinery', 'Curve family libraries', 'Named selectable forms shared across a model.', ['A-22', 'A-14'], { required: ['D-02'] }],
  ['Share machinery', 'Cross-product interaction (3 tiers)', 'Cannibalization scalar → event-driven re-pathing → full share-theft matrix from named incumbents.', ['A-27', 'A-7', 'A-11', 'A-20', 'A-35']],
  ['Share machinery', 'Order-of-entry logic', 'Competitor sequencing drives share allocation.', ['A-4', 'A-21']],
  ['Share machinery', 'Custom uptake backends', 'User-supplied curves overriding the libraries.', ['A-20', 'A-21']],
  ['Persistence, dosing & regimen', 'Persistency grids', 'Cohort-by-month survival on therapy, with drop-off configuration.', ['A-18', 'A-17'], { required: ['D-03'], data: 'persist', patients: true }],
  ['Persistence, dosing & regimen', 'Days-of-therapy calculators', 'Manual, automatic, data-derived, label-adjusted DOT.', ['A-19', 'A-25'], { rec: ['D-03'] }],
  ['Persistence, dosing & regimen', 'Compliance matrices', 'By line of therapy and by SKU, as separate axes.', ['A-17'], { rec: ['D-01', 'D-04'] }],
  ['Persistence, dosing & regimen', 'Dosing regimen math', 'Cycles, cycle length, dosage days, titration schedules.', ['A-17', 'A-12'], { rec: ['D-03'] }],
  ['Persistence, dosing & regimen', 'Dose-sequence chains', 'First through Nth dose with inter-dose lag and per-dose compliance.', ['A-4', 'A-6'], { required: ['D-05'], patients: true }],
  ['Persistence, dosing & regimen', 'Booster due-pool queues', 'Newly-due plus backlog, drawn down by capture and compliance, remainder carried.', ['A-2'], { rec: ['D-05'], patients: true, needs: 'Dose-sequence chains' }],
  ['Persistence, dosing & regimen', 'Waning-immunity re-entry', 'Vaccinated patients re-enter the eligible pool when protection lapses.', ['A-4'], { patients: true }],
  ['Persistence, dosing & regimen', 'Free-drug / paid phasing', 'Patient-assistance volume as an explicit accounting flow.', ['A-17', 'A-16']],
  ['Cross-product & franchise', 'Franchise succession flows', 'Predecessor-to-successor patient migration: feeder brands, withdrawal with recapture, platform shifts.', ['A-20', 'A-15', 'A-10'], { patients: true }],
  ['Cross-product & franchise', 'Franchise incrementality', 'A launch’s revenue net of cannibalizing the firm’s own portfolio.', ['A-8']],
  ['Cross-product & franchise', 'Franchise rollups', 'Multi-asset net-revenue consolidation.', ['A-27', 'A-8']],
  ['Cross-product & franchise', 'Warehousing / bolus release', 'Patients parked on holding therapy, released at an approval event.', ['A-13'], { patients: true }],
  ['Cross-product & franchise', 'Combination-asset logic', 'Assets-in-combination counts, combo pricing and dosing, mono/combo instances.', ['A-12', 'A-17']],
  ['Events, LOE & scenarios', 'Dated event layers', 'Event registry with parameterized share or volume consequences — the most divergently implemented module.', ['A-9', 'A-14', 'A-22', 'A-32', 'A-35'], { rec: ['D-01', 'D-02'] }],
  ['Events, LOE & scenarios', 'LOE erosion', 'Erosion type, target share, time-to-target, generic entry.', ['A-15', 'A-12'], { rec: ['D-01', 'D-02', 'D-03', 'D-04'] }],
  ['Events, LOE & scenarios', 'Scenario management', 'Parallel scenario sheets, saved state loaded on demand, or stored multiplier vectors.', ['A-13', 'A-18', 'A-16'], { required: ALL }],
  ['Events, LOE & scenarios', 'Scenario comparison reporting', 'Side-by-side monthly, annual, and graphical deltas.', ['A-24', 'A-27']],
  ['Actuals, calibration & reconciliation', 'Actuals boundary management', 'The actuals / override / final / splined row pattern; last-actual-month per metric.', ['A-27', 'A-25'], { required: ALL, data: 'actuals' }],
  ['Actuals, calibration & reconciliation', 'Claims ingestion & NPS derivation', 'Claims → new-patient starts → diagnostics, with projection.', ['A-13', 'A-14'], { rec: ['D-03'], data: 'claims', patients: true }],
  ['Actuals, calibration & reconciliation', 'Data-source normalization', 'Factored-to-unfactored scalars; source-variance tracking.', ['A-25'], { rec: ['D-02'] }],
  ['Actuals, calibration & reconciliation', 'Calibration backends', 'Fitting shares or parameters to actuals; budget-calibrated conventions.', ['A-18', 'A-19', 'A-27'], { rec: ['D-01', 'D-02', 'D-03', 'D-04'] }],
  ['Actuals, calibration & reconciliation', 'Below-the-line set', 'Unexplained demand, HQ adjustments, inventory change, prior-period adjustments.', ['A-27', 'A-25']],
  ['Actuals, calibration & reconciliation', 'Selling-day adjustments', 'Trading-day calendar correction.', ['A-27']],
  ['Actuals, calibration & reconciliation', 'Shock overlays', 'Pandemic-style disruption layers on rates and starts.', ['A-3', 'A-13']],
  ['Actuals, calibration & reconciliation', 'Stock-reconciliation bridges', 'A conservation ledger proving patients balance year over year.', ['A-4'], { required: ['D-05'], patients: true }],
  ['Actuals, calibration & reconciliation', 'Seasonality decomposition', 'Seasonal split and reapplication around trend.', ['A-31']],
  ['Actuals, calibration & reconciliation', 'Annual↔monthly splining', 'Spline-based translation between planning and operating granularity.', ['A-30', 'A-18']],
  ['Conversion, financial & integration', 'Volume conversion chains', 'Patients → scripts or doses → units, per SKU and pack.', ['A-11', 'A-25'], { rec: ALL }],
  ['Conversion, financial & integration', 'Gross-to-net engines', 'Multiplicative factors, stacked discounts, one gross-to-net truth.', ['A-4', 'A-22', 'A-33'], { required: ALL, data: 'g2n' }],
  ['Conversion, financial & integration', 'Price & FX', 'Local-currency pricing, erosion, multi-country exchange.', ['A-5', 'A-28'], { required: ALL, data: 'price' }],
  ['Conversion, financial & integration', 'Submission & sync machinery', 'MOSAIC sync, LRF output formats, guidance comparison, validation gates, finance handoffs.', ['A-28', 'A-12'], { required: ALL }],
  ['Conversion, financial & integration', 'Presentation export', 'Deck generation from model state.', ['A-5', 'A-26']],
  ['Conversion, financial & integration', 'Porting & migration suites', 'Tooling to move a model between template versions.', ['A-16']],
  ['Conversion, financial & integration', 'Versioning & documentation', 'State persistence, data dictionaries, in-model FAQs and question logs.', ['A-4', 'A-30', 'A-37'], { required: ALL }],
  ['Conversion, financial & integration', 'Parallel trade', 'EU parallel-import volume and revenue adjustment.', ['A-37']],
  ['Conversion, financial & integration', 'Automated report generation', 'In-model report builder producing formatted outputs from model state.', ['A-32']],
  ['Share machinery', 'Competitor & market-share tracking', 'Tracks named competitor products and market share from script data, feeding share-based forecasts.', ['A-21', 'A-31']],
]
const MODULES: Mod[] = RAW.map(([cat, name, desc, ev, extra], i) => ({ id: `m${i + 1}`, code: String(i + 1).padStart(2, '0'), cat, name, desc, ev, ...extra }))
const CATS = ['All', ...Array.from(new Set(MODULES.map(m => m.cat)))]
// Vaccine-only machinery, and patient-carrying modules can't attach to Rx-Share (no patient state).
const VACCINE_ONLY = new Set(['Dose-sequence chains', 'Booster due-pool queues', 'Waning-immunity re-entry', 'Anti-vaccination carve-out', 'Stock-reconciliation bridges'])
const validFor = (m: Mod, a: ArchId) => !(a === 'D-02' && m.patients) && (!VACCINE_ONLY.has(m.name) || a === 'D-05')
const byName = (n: string) => MODULES.find(m => m.name === n)!

type DataInput = { id: string; name: string; feeds: string; suggested: string }
const BASE_INPUTS: Record<ArchId, DataInput[]> = {
  'D-01': [{ id: 'pool', name: 'Treated patient pool', feeds: 'Treated pool', suggested: 'IQVIA LAAD claims' }],
  'D-02': [{ id: 'basket', name: 'Prescription basket (TRx / NRx)', feeds: 'Rx basket', suggested: 'IQVIA NPA weekly' }],
  'D-03': [{ id: 'elig', name: 'Eligible population', feeds: 'Eligible population', suggested: 'Internal Epi Library' }],
  'D-04': [{ id: 'stock', name: 'Opening brand patient stock', feeds: 'Opening brand stock', suggested: 'Symphony PatientSource' }],
  'D-05': [{ id: 'eligstock', name: 'Unvaccinated eligible stock', feeds: 'Eligible stock', suggested: 'CDC NIS-Teen / Adult' }],
  'D-06': [{ id: 'hist', name: 'Historical series (units, by grain)', feeds: 'Historical series', suggested: 'SAP actuals (net sales)' }],
  'D-07': [{ id: 'addr', name: 'Addressable population (epi estimate)', feeds: 'Addressable population', suggested: 'Internal Epi Library' }],
}
const MODULE_INPUTS: Record<string, DataInput> = {
  epi: { id: 'epi', name: 'Incidence / prevalence & filter rates', feeds: 'Epi funnel builder', suggested: 'Internal Epi Library' },
  age: { id: 'age', name: 'Single-year-of-age population', feeds: 'Age-structured cohorts', suggested: 'UN population (WPP)' },
  payer: { id: 'payer', name: 'Per-channel capture rates', feeds: 'Channel / payer dimension', suggested: 'IQVIA LAAD claims' },
  persist: { id: 'persist', name: 'Cohort-by-month persistency', feeds: 'Persistency grids', suggested: 'Komodo Health' },
  claims: { id: 'claims', name: 'Patient-level claims', feeds: 'Claims ingestion & NPS derivation', suggested: 'IQVIA LAAD claims' },
  price: { id: 'price', name: 'Local-currency price & FX', feeds: 'Price & FX', suggested: 'Internal Pricing (Model N)' },
  g2n: { id: 'g2n', name: 'Discount & rebate factors', feeds: 'Gross-to-net engines', suggested: 'SAP actuals (net sales)' },
  actuals: { id: 'actuals', name: 'Actuals by metric (last-actual-month)', feeds: 'Actuals boundary management', suggested: 'SAP actuals (net sales)' },
}
const OWNERS = ['M. Okafor (Epi)', 'R. Lindqvist (Data)', 'S. Patel (Pricing)', 'J. Romero (Finance)']
const FORECASTERS = ['Michelle Tran', 'David Osei', 'Priya Raman', 'Tom Becker']

type Assumption = { id: string; name: string; unit: string; base: number; min: number; max: number; open?: boolean }
const COMMON_ASSUMPTIONS: Assumption[] = [
  { id: 'price', name: 'Annual price change', unit: '%', base: 4.5, min: 0, max: 7 },
  { id: 'g2n', name: 'Gross-to-net discount', unit: '%', base: 38, min: 32, max: 44 },
  { id: 'loe', name: 'LOE target share', unit: '% of pre-LOE', base: 20, min: 10, max: 35 },
]
const ENGINE_ASSUMPTIONS: Record<ArchId, Assumption[]> = {
  'D-01': [
    { id: 'treated', name: 'Treated rate', unit: '%', base: 46, min: 40, max: 52 },
    { id: 'peak', name: 'Peak brand share', unit: '%', base: 18, min: 12, max: 24, open: true },
    { id: 'ttp', name: 'Time to peak', unit: 'months', base: 36, min: 24, max: 48, open: true },
  ],
  'D-02': [
    { id: 'mtrend', name: 'Market Rx trend', unit: '% / yr', base: 3.2, min: 0, max: 6, open: true },
    { id: 'peak', name: 'Peak share of basket', unit: '%', base: 14, min: 9, max: 20, open: true },
    { id: 'ttp', name: 'Time to peak', unit: 'months', base: 30, min: 18, max: 42, open: true },
  ],
  'D-03': [
    { id: 'starts', name: 'New starts / month', unit: 'patients', base: 420, min: 300, max: 600, open: true },
    { id: 'persist12', name: '12-month persistency', unit: '%', base: 62, min: 55, max: 70, open: true },
    { id: 'compliance', name: 'Compliance', unit: '%', base: 84, min: 75, max: 92 },
  ],
  'D-04': [
    { id: 'inflow', name: 'Monthly start rate', unit: 'patients', base: 380, min: 280, max: 500, open: true },
    { id: 'disc', name: 'Discontinuation probability', unit: '% / month', base: 4.2, min: 3, max: 6, open: true },
    { id: 'compliance', name: 'Compliance', unit: '%', base: 84, min: 75, max: 92 },
  ],
  'D-05': [
    { id: 'ceiling', name: 'Coverage ceiling', unit: '%', base: 72, min: 60, max: 80 },
    { id: 'capture', name: 'Capture rate', unit: '% / month', base: 9, min: 5, max: 11, open: true },
    { id: 'boost', name: 'Per-dose compliance', unit: '%', base: 58, min: 45, max: 70, open: true },
  ],
  'D-06': [
    { id: 'window', name: 'Data window', unit: 'months', base: 24, min: 12, max: 36 },
    { id: 'evadj', name: 'Event adjustment', unit: '%', base: 0, min: -15, max: 15, open: true },
  ],
  'D-07': [
    { id: 'pshare', name: 'Peak share', unit: '%', base: 12, min: 6, max: 20, open: true },
    { id: 'ppeak', name: 'Years to peak', unit: 'years', base: 5, min: 3, max: 8, open: true },
    { id: 'analog', name: 'Ex-US analog factor', unit: '× US', base: 0.6, min: 0.4, max: 0.9 },
  ],
}
const assumptionsFor = (a: ArchId | null) => a ? [...ENGINE_ASSUMPTIONS[a], ...COMMON_ASSUMPTIONS] : []
const COMMON_FEEDS: Record<string, string> = { price: 'Price & FX', g2n: 'Gross-to-net engines', loe: 'LOE erosion' }
const assumptionMeta = (a: Assumption, arch: ArchId) => COMMON_FEEDS[a.id]
  ? { cat: 'Commercial & financial', feeds: COMMON_FEEDS[a.id] }
  : { cat: 'Engine', feeds: `${archName(arch)} engine` }

/* ───────────────────────── Configurator structure (alignment feedback) ───────────────────────── */

const STAGES = [
  { id: 1, title: 'Model Setup', short: 'Setup', sub: 'Subject + streams', icon: Settings2, desc: 'Describe what this model forecasts — fill in the fields below. Geography and planning cycle are set at Publish.' },
  { id: 2, title: 'Archetype', short: 'Archetype', sub: 'Per-stream selection', icon: Layers, desc: 'Choose the forecasting archetype for each revenue stream. The archetype decides which modes and modules are available downstream. Typical-use labels are for reference only.' },
  { id: 3, title: 'Modes', short: 'Modes', sub: 'Units · time · persistence', icon: SlidersHorizontal, desc: 'A mode is an alternative specification of the same engine. Only the modes valid for the chosen archetype are shown; required modes must be set before you continue.' },
  { id: 4, title: 'Modules', short: 'Modules', sub: 'Taxonomy buckets', icon: Boxes, desc: 'Attach the modules this stream needs. Modules come from the taxonomy, grouped by bucket; only those valid for the chosen archetype are listed.' },
  { id: 5, title: 'Bind Data', short: 'Data', sub: 'Input · source · refresh', icon: Database, desc: 'Review the governed source bound to each input, by revenue stream, and when it was last refreshed.' },
  { id: 6, title: 'Review', short: 'Review', sub: 'Summary · flow · output', icon: CheckCircle2, desc: 'The complete model in one place: configuration and model flow. Clear any open checks before you publish.' },
  { id: 7, title: 'Publish & Assign', short: 'Publish', sub: 'Geo · cycle · assign', icon: Send, desc: 'Set geography and planning cycle, choose who forecasts and who can see the model, then publish. Earlier versions stay in the audit history.' },
] as const
const LAST = STAGES.length
const REVIEW = LAST - 1

const ARCH_DETAIL: Record<ArchId, { question: string; uses: string[]; status: 'Certified' | 'Under review'; limit: string; audience: string; ceiling?: string }> = {
  'D-01': { audience: 'Brand forecasters · patient-share', question: 'What share of an existing treated pool will the brand capture?', uses: ['Chronic, established markets', 'Entry into a known treated pool'], status: 'Certified', limit: 'No memory of how patients arrived — stock and flow are implied through persistency.' },
  'D-02': { audience: 'Finance · Rx / alliance conventions', question: 'How many scripts will the brand win in a trended Rx basket?', uses: ['Retail and primary-care brands', 'Episodic or acute therapies'], status: 'Certified', limit: 'Carries no patients — patient-based modules are unavailable.' },
  'D-03': { audience: 'Brand forecasters · oncology & specialty', question: 'How many patients start, and how long do they stay?', uses: ['Oncology and specialty', 'Single-course antivirals (incidence capture)'], status: 'Certified', limit: 'Needs persistency by cohort and month to be credible.' },
  'D-04': { audience: 'Legacy specialty models', question: 'How does the brand’s own patient stock grow and drain?', uses: ['Brands with stable monthly start and drop-off rates'], status: 'Under review', limit: 'Under review — may fold into Patient-Flow. Not allowed at Valuation tier.' },
  'D-05': { audience: 'Vaccine forecasters', question: 'How fast can we deplete the eligible, unprotected population?', uses: ['Vaccines — routine, catch-up, seasonal', 'Booster and multi-dose schedules'], status: 'Certified', limit: 'Conservation convention must match the vaccine’s immunity duration.' },
  'D-06': { audience: 'Data science · component use', question: 'Where does the observed series go if nothing structural changes?', uses: ['Actuals projection', 'Sub-segments not modeled structurally'], status: 'Certified', limit: 'A component — don’t let it stand in for the whole brand forecast.' },
  'D-07': { audience: 'Business Assessment · BD&L', question: 'How big could this asset be in its peak year?', uses: ['Early assessment', 'TPP variant comparison'], status: 'Certified', ceiling: 'Screening', limit: 'Screening grade only. Outputs are ranges, never valuation-grade.' },
}
const ENGINES: Record<ArchId, string[]> = {
  'D-01': ['v3.2 · certified', 'v3.3 · beta'], 'D-02': ['v2.6 · certified', 'v2.7 · beta'], 'D-03': ['v4.1 · certified', 'v4.2 · beta'],
  'D-04': ['v1.4 · under review'], 'D-05': ['v2.0 · certified', 'v2.1 · beta'], 'D-06': ['v1.8 · certified'], 'D-07': ['v1.2 · certified'],
}
const GOVERNED = new Set(['Custom uptake backends', 'Calibration backends', 'Below-the-line set', 'Porting & migration suites', 'Parallel trade'])
const BUCKETS = CATS.slice(1)
const FALLBACKS = ['Block forecast run', 'Carry last good value', 'Manual upload with reason']
const ASSUMPTION_SOURCES = ['Market research (ATU 2026)', 'Analog benchmark', 'KOL advisory panel', 'Clinical trial readout', 'Brand team judgement']
const ASSUMPTION_OWNERS = ['Brand forecaster', 'Brand lead', 'CoE analyst', 'Market Access', 'Pricing', 'API supply', 'Compliance', 'Gross-to-Net']
/** Named contacts per business function; assignees are notified when rows are assigned to them. */
const OWNER_CONTACT: Record<string, string> = { 'Brand forecaster': 'Michelle Tran', 'Brand lead': 'A. Nguyen', 'CoE analyst': 'K. Brandt', 'Market Access': 'E. Walsh', 'Pricing': 'S. Patel', 'API supply': 'H. Ito', 'Compliance': 'C. Duarte', 'Gross-to-Net': 'J. Romero' }
const PEOPLE = ['K. Brandt (CoE)', 'A. Nguyen (Brand lead)', 'S. Patel (Pricing)', 'E. Walsh (Market Access)', 'J. Romero (Finance)', 'M. Okafor (Epi)', 'Michelle Tran (Forecaster)']
const ROLES: { r: Role; d: string }[] = [
  { r: 'Creator', d: 'Owns the model, invites people, publishes.' },
  { r: 'Editor', d: 'Edits every step of this model only.' },
  { r: 'Viewer', d: 'Read-only access to this model.' },
]
const FIELD_LABEL: Record<string, string> = { brand: 'brand', asset: 'asset', therapyArea: 'therapy area', lifecycle: 'lifecycle', inds: 'revenue streams', market: 'geography', cycle: 'planning cycle', forecasters: 'forecasters', visibility: 'visibility', viewers: 'viewers', release: 'release type', geoRestrict: 'geography restrictions', team: 'collaborators', bindings: 'data bindings', baseline: 'baseline', slices: 'slices', notes: 'notes', modules: 'modules', perms: 'assumptions', modes: 'modes', arch: 'archetype', name: 'stream name', dim: 'dimension' }
const ME = 'J. Andersen'

/* ───────────────────────── Model library data ───────────────────────── */

type MStatus = 'Draft' | 'Published'
type Fresh = 'Current' | 'Delayed' | 'Partial' | 'Missing'
type Version = { v: string; date: string; by: string; note: string; scenarios: number }
type ModelRow = {
  id: string; brand: string; inds: { name: string; arch: string }[]; market: string; cycle: string; version: string
  status: MStatus; fresh: Fresh; issues: number; updated: string; by: string; step?: number; restricted?: boolean; versions: Version[]
  fx?: FixtureId; tag?: string; name?: string; diff?: { kind: '+' | '−' | '~'; text: string }[]
}
const SEED_MODELS: ModelRow[] = [
  { id: 'a', brand: 'Velsipity', inds: [{ name: 'Ulcerative colitis', arch: '' }], market: 'US', cycle: 'OP 2027', version: 'v1.0 draft', status: 'Draft', fresh: 'Current', issues: 3, updated: 'Today, 09:12', by: 'You', step: 2, versions: [] },
  { id: 'd', brand: 'Abrysvo', inds: [{ name: 'RSV — older adults', arch: 'Market Stock-Flow' }], market: 'US', cycle: 'OP 2027', version: 'v1.3 draft', status: 'Draft', fresh: 'Partial', issues: 2, updated: 'Sep 24', by: 'You', step: 5,
    versions: [{ v: 'v1.2', date: 'Jun 12', by: 'You', note: 'Seasonal dose-basket for 2026/27.', scenarios: 9 }] },
  { id: 'f', brand: 'Elrexfio', inds: [{ name: 'Multiple myeloma 4L+', arch: 'Patient-Flow' }, { name: 'Multiple myeloma 2L', arch: 'Brand Inflow-Outflow' }], market: 'US', cycle: 'OP 2027', version: 'v2.0', status: 'Published', fresh: 'Current', issues: 0, updated: 'Oct 5', by: 'K. Brandt',
    versions: [{ v: 'v1.1', date: 'Mar 3', by: 'K. Brandt', note: 'Free-drug phasing added.', scenarios: 6 }] },
  { id: 'b', brand: 'Cibinqo', inds: [{ name: 'Atopic dermatitis', arch: 'Prevalent-Share' }], market: 'US', cycle: 'OP 2027', version: 'v2.3', status: 'Published', fresh: 'Current', issues: 0, updated: 'Oct 2', by: 'A. Nguyen',
    versions: [{ v: 'v2.3', date: 'Oct 2', by: 'A. Nguyen', note: 'Share cascade re-based on Q3 claims.', scenarios: 14 }, { v: 'v2.2', date: 'Jun 18', by: 'A. Nguyen', note: 'LOE erosion added.', scenarios: 22 }, { v: 'v2.1', date: 'Jan 9', by: 'You', note: 'Initial OP 2026 build.', scenarios: 31 }] },
  { id: 'c', brand: 'Nurtec ODT', inds: [{ name: 'Migraine — acute', arch: 'Rx-Share' }, { name: 'Migraine — preventive', arch: 'Rx-Share' }], market: 'US', cycle: 'Q4 2026 Re-forecast', version: 'v4.1', status: 'Published', fresh: 'Delayed', issues: 0, updated: 'Sep 28', by: 'K. Brandt',
    versions: [{ v: 'v4.1', date: 'Sep 28', by: 'K. Brandt', note: 'S-shaped curve family for preventive.', scenarios: 11 }, { v: 'v4.0', date: 'May 2', by: 'K. Brandt', note: 'Split into two indications.', scenarios: 18 }] },
  { id: 'e', brand: 'Lorbrena', inds: [{ name: 'ALK+ NSCLC 1L', arch: 'Patient-Flow' }, { name: 'ALK+ NSCLC 2L+', arch: 'Patient-Flow' }], market: 'EU5', cycle: 'LRP 2027–2036', version: 'v3.0', status: 'Published', fresh: 'Current', issues: 0, updated: 'Sep 19', by: 'L. Moreau',
    versions: [{ v: 'v3.0', date: 'Sep 19', by: 'L. Moreau', note: 'Progression-derived 2L pool.', scenarios: 8 }] },
  { id: 'x', brand: 'Project Halo', inds: [{ name: 'Restricted', arch: '' }], market: 'Global', cycle: 'BD screening', version: '—', status: 'Draft', fresh: 'Current', issues: 0, updated: '—', by: 'BD team', restricted: true, versions: [] },
]
const ACTIVITY = [
  { who: 'K. Brandt', what: 'published Elrexfio v2.0 · 6 scenarios re-pinned', when: 'Oct 5, 16:40', icon: CheckCircle2 },
  { who: 'You', what: 'resumed Abrysvo v1.3 draft (Step 5)', when: 'Oct 4, 11:02', icon: Clock },
  { who: 'System', what: 'IQVIA NPA weekly feed is 9 days late (Nurtec ODT)', when: 'Oct 3, 06:00', icon: Clock },
  { who: 'A. Nguyen', what: 'published Cibinqo v2.3 · 14 scenarios re-pinned', when: 'Oct 2, 09:30', icon: CheckCircle2 },
  { who: 'You', what: 'created Velsipity draft from blank', when: 'Oct 1, 14:18', icon: Plus },
]
const CYCLES = [{ name: 'OP 2027', due: 'Nov 14' }, { name: 'Q4 2026 Re-forecast', due: 'Oct 31' }, { name: 'LRP 2027–2036', due: 'Feb 6' }]

/* ───────────────────────── Edge-case fixtures (Help → Edge-case fixtures) ───────────────────────── */

type FixtureId = 'prelaunch' | 'loe' | 'retired' | 'locked' | 'frozen' | 'overlap' | 'diff' | 'integrity' | 'belowHistory' | 'vaccineCeiling' | 'bigSlices' | 'emptySlice' | 'fxMix'
const fxRow = (id: string, fx: FixtureId, tag: string, brand: string, inds: [string, string][], extra: Partial<ModelRow> = {}): ModelRow => ({
  id, fx, tag, brand, inds: inds.map(([name, arch]) => ({ name, arch })), market: 'US', cycle: 'OP 2027', version: 'v1.0 draft', status: 'Draft',
  fresh: 'Current', issues: 1, updated: 'Today', by: 'You', versions: [], ...extra,
})
const FIXTURE_MODELS: ModelRow[] = [
  fxRow('f1', 'prelaunch', 'Pre-launch', 'Hympavzi', [['Hemophilia A/B', 'Prevalent-Share']], { fresh: 'Missing' }),
  fxRow('f2', 'loe', 'LOE in 2 months', 'Xeljanz', [['Rheumatoid arthritis', 'Prevalent-Share']], { version: 'v5.2', status: 'Published', issues: 0, versions: [{ v: 'v5.2', date: 'Aug 1', by: 'A. Nguyen', note: 'Pre-LOE baseline.', scenarios: 12 }] }),
  fxRow('f3', 'retired', 'Engine retiring', 'Ibrance', [['HR+ breast cancer', 'Brand Inflow-Outflow']], { version: 'v6.0', status: 'Published', issues: 0, by: 'L. Moreau', versions: [{ v: 'v6.0', date: 'Apr 4', by: 'L. Moreau', note: 'Runs on D-04 v1.4.', scenarios: 19 }] }),
  fxRow('f4', 'locked', 'K. Brandt editing', 'Abrysvo', [['RSV — maternal', 'Market Stock-Flow']], { version: 'v1.4 draft', by: 'K. Brandt' }),
  fxRow('f5', 'frozen', 'Cycle frozen', 'Comirnaty', [['COVID-19 — 2026/27 season', 'Market Stock-Flow']], { cycle: 'Q4 2026 Re-forecast' }),
  fxRow('f6', 'overlap', 'Shared patients', 'Eliquis', [['Atrial fibrillation', 'Prevalent-Share'], ['Venous thromboembolism', 'Patient-Flow']], { market: 'EU5' }),
  fxRow('f8', 'diff', 'Diff vs v2.3', 'Cibinqo', [['Atopic dermatitis', 'Prevalent-Share']], { version: 'v2.4 draft', issues: 0,
    versions: [{ v: 'v2.3', date: 'Oct 2', by: 'A. Nguyen', note: 'Share cascade re-based on Q3 claims.', scenarios: 14 }],
    diff: [{ kind: '+', text: 'Module: Adherence & compliance' }, { kind: '~', text: 'Peak brand share band 12–24% → 10–26%' }, { kind: '~', text: 'Treated patient pool: IQVIA LAAD → Symphony PatientSource' }] }),
  fxRow('f9', 'integrity', 'Share > 100%', 'Vyndaqel', [['ATTR-CM', 'Prevalent-Share']]),
  fxRow('f10', 'belowHistory', 'Band vs actuals', 'Lorbrena', [['ALK+ NSCLC 1L', 'Patient-Flow']]),
  fxRow('f11', 'vaccineCeiling', 'Ceiling reached', 'Prevnar 20', [['Adult pneumococcal', 'Market Stock-Flow']]),
  fxRow('f12', 'bigSlices', '32k combinations', 'Zavzpret', [['Migraine — acute', 'Rx-Share']]),
  fxRow('f14', 'emptySlice', 'Zero-patient value', 'Litfulo', [['Alopecia areata', 'Prevalent-Share']]),
  fxRow('f15', 'fxMix', 'FX not set', 'Bavencio', [['Urothelial carcinoma 1L maint.', 'Patient-Flow']], { market: 'EU5' }),
]
const FIXTURE_ACTIVITY = [
  { who: 'System', what: 'IQVIA restated Jan–Mar 2026 history for Nurtec ODT (−4%) · 3 inputs affected', when: 'Today, 06:00', icon: RefreshCw },
  { who: 'Platform', what: 'engine D-04 v1.4 retires Nov 30 · 2 models affected', when: 'Today, 08:15', icon: AlertTriangle },
  { who: 'K. Brandt', what: 'requested control of the Abrysvo maternal draft', when: 'Today, 09:40', icon: Users },
]
const RESTRICTED_RE = /halo|restricted|bd pipeline/i

/* ───────────────────────── Small UI primitives ───────────────────────── */

/** AI action shown next to errors. Applies Charles's safe fixes for the affected steps. */
function FixForMe({ onClick, className }: { onClick: () => void; className?: string }) {
  return (
    <button type="button" onClick={onClick}
      className={cx('inline-flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-md border border-brand/30 bg-brand-soft px-3 text-[13px] font-semibold text-brand transition-colors hover:border-brand hover:bg-brand hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand', className)}>
      <Sparkles size={14} />Fix for me
    </button>
  )
}

function cx(...c: (string | false | null | undefined)[]) { return c.filter(Boolean).join(' ') }

function Btn({ children, variant = 'primary', size = 'md', disabled, onClick, icon, title, className }: {
  children?: ReactNode; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'sm' | 'md'; disabled?: boolean
  onClick?: () => void; icon?: ReactNode; title?: string; className?: string
}) {
  return (
    <button
      type="button" title={title} disabled={disabled} onClick={onClick}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand disabled:cursor-not-allowed',
        size === 'sm' ? 'h-8 px-3 text-[13px]' : 'h-10 px-4 text-sm',
        variant === 'primary' && 'bg-brand text-white hover:bg-brand-dark disabled:bg-border-strong',
        variant === 'secondary' && 'border border-border-strong bg-surface text-text hover:border-text disabled:text-text-3',
        variant === 'ghost' && 'text-text-2 hover:bg-surface-2 hover:text-text disabled:text-text-3',
        variant === 'danger' && 'text-err hover:bg-err-soft',
        className,
      )}
    >
      {icon}{children}
    </button>
  )
}

function Badge({ tone = 'neutral', children }: { tone?: 'neutral' | 'brand' | 'ok' | 'warn' | 'err'; children: ReactNode }) {
  return (
    <span className={cx(
      'inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide',
      tone === 'neutral' && 'bg-surface-2 text-text-2',
      tone === 'brand' && 'bg-brand-soft text-brand',
      tone === 'ok' && 'bg-ok-soft text-ok',
      tone === 'warn' && 'bg-warn-soft text-warn',
      tone === 'err' && 'bg-err-soft text-err',
    )}>{children}</span>
  )
}

/** Which section and field Charles is filling right now (drives the gradient highlight). */
type AgentState = { section: string | null; field: string | null }
const AgentCtx = createContext<AgentState>({ section: null, field: null })

/** Wraps a card in an animated gradient ring while Charles works inside it. */
function AgentSection({ id, children }: { id: string; children: ReactNode }) {
  const a = useContext(AgentCtx)
  if (a.section !== id) return <>{children}</>
  return (
    <div className="agent-section" data-agent-section={id}>
      <span className="agent-bg absolute -top-3 right-4 z-10 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold text-white shadow-md"><Sparkles size={11} className="animate-pulse" />{ASSISTANT} is filling this section</span>
      {children}
    </div>
  )
}

function Field({ label, hint, error, children, required, ai, className, agent }: { label: string; hint?: string; error?: string; children: ReactNode; required?: boolean; ai?: boolean; className?: string; agent?: string }) {
  const now = useContext(AgentCtx).field
  const live = !!agent && now === agent
  return (
    <label className={cx('block min-w-0', live && 'agent-field', className)} data-agent={agent}>
      <span className="mb-1.5 flex items-center gap-2 text-[13px] font-semibold text-text">
        <span>{label}{required && <span className="text-err"> *</span>}</span>
        {live ? <span className="inline-flex items-center gap-1 rounded bg-[#7c3aed]/10 px-1.5 py-0.5 text-[10px] font-semibold text-[#7c3aed]"><Loader2 size={10} className="animate-spin" />{ASSISTANT} is typing</span>
          : ai && <span className="inline-flex items-center gap-1 rounded bg-brand-soft px-1.5 py-0.5 text-[10px] font-semibold text-brand"><Sparkles size={10} />Filled by {ASSISTANT} · review</span>}
      </span>
      {children}
      {error ? (
        <span className="mt-1.5 flex items-center gap-1 text-xs text-err"><AlertCircle size={12} />{error}</span>
      ) : hint ? <span className="mt-1.5 block text-xs text-text-3">{hint}</span> : null}
    </label>
  )
}

const inputCls = (err?: boolean) => cx(
  'h-10 w-full rounded-md border bg-surface px-3 text-sm text-text outline-none transition-colors placeholder:text-text-3 focus:border-brand focus:ring-2 focus:ring-brand/15',
  err ? 'border-err' : 'border-border-strong',
)

function Segmented({ value, options, onChange }: { value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <div className="inline-flex flex-wrap rounded-md border border-border-strong bg-surface p-0.5" role="radiogroup">
      {options.map(o => (
        <button key={o} type="button" role="radio" aria-checked={value === o} onClick={() => onChange(o)}
          className={cx('rounded px-3 py-1.5 text-[13px] font-medium transition-colors', value === o ? 'bg-text text-white' : 'text-text-2 hover:text-text')}>
          {o}
        </button>
      ))}
    </div>
  )
}

function Switch({ on, onChange, disabled, label }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)}
      className={cx('relative h-5 w-9 shrink-0 rounded-full transition-colors disabled:opacity-50', on ? 'bg-brand' : 'bg-border-strong')}>
      <span className={cx('absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all', on ? 'left-[18px]' : 'left-0.5')} />
    </button>
  )
}

function Banner({ tone, title, children, action }: { tone: 'info' | 'ok' | 'warn' | 'err'; title: string; children?: ReactNode; action?: ReactNode }) {
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'err' ? AlertCircle : tone === 'warn' ? AlertTriangle : Info
  return (
    <div role={tone === 'err' ? 'alert' : 'status'} className={cx('rise flex gap-3 rounded-lg border p-3.5',
      tone === 'info' && 'border-brand/20 bg-brand-soft/60', tone === 'ok' && 'border-ok/25 bg-ok-soft',
      tone === 'warn' && 'border-warn/25 bg-warn-soft', tone === 'err' && 'border-err/25 bg-err-soft')}>
      <Icon size={18} className={cx('mt-px shrink-0', tone === 'info' && 'text-brand', tone === 'ok' && 'text-ok', tone === 'warn' && 'text-warn', tone === 'err' && 'text-err')} />
      <div className="min-w-0 flex-1 text-sm">
        <p className="font-semibold text-text">{title}</p>
        {children && <div className="mt-0.5 text-text-2">{children}</div>}
      </div>
      {action}
    </div>
  )
}

function Card({ title, sub, right, children, className }: { title?: string; sub?: string; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cx('rounded-lg border border-border bg-surface', className)}>
      {title && (
        <header className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 border-b border-border px-5 py-4">
          <div className="min-w-0 flex-1"><h3 className="text-[15px] font-semibold text-text">{title}</h3>{sub && <p className="mt-0.5 text-[13px] text-text-2">{sub}</p>}</div>
          {right && <div className="shrink-0">{right}</div>}
        </header>
      )}
      <div className="min-w-0 p-5">{children}</div>
    </section>
  )
}

function EmptyState({ icon, title, children, action }: { icon: ReactNode; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-lg border border-dashed border-border-strong bg-surface px-6 py-12 text-center">
      <div className="mb-3 grid h-11 w-11 place-items-center rounded-full bg-surface-2 text-text-2">{icon}</div>
      <p className="font-semibold text-text">{title}</p>
      {children && <p className="mt-1 max-w-sm text-sm text-text-2">{children}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}


function Logo({ name = 'NextGen Forecasting' }: { name?: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width="26" height="26" viewBox="0 0 26 26" aria-hidden>
        <path d="M13 1.5c6.4 0 11.5 5.1 11.5 11.5S19.4 24.5 13 24.5 1.5 19.4 1.5 13" fill="none" stroke="#0000C9" strokeWidth="3" strokeLinecap="round" />
        <circle cx="13" cy="13" r="4" fill="#0000C9" />
      </svg>
      <span className="text-[19px] font-bold tracking-tight text-brand">{name}</span>
    </div>
  )
}

const FRESH_TONE: Record<Fresh, 'ok' | 'warn' | 'err'> = { Current: 'ok', Delayed: 'warn', Partial: 'warn', Missing: 'err' }
function FreshBadge({ f }: { f: Fresh }) {
  return <Badge tone={FRESH_TONE[f]}>{f === 'Current' ? <Check size={10} /> : f === 'Missing' ? <AlertCircle size={10} /> : <Clock size={10} />}{f}</Badge>
}

/* ───────────────────────── State shape ───────────────────────── */

type Slice = { id: string; name: string; values: string[] }
type Binding = {
  source: string; owner: string; confidence: 'High' | 'Medium' | 'Low'; status: 'idle' | 'testing' | 'ok' | 'error'; msg?: string
  fresh?: { state: Fresh; refreshed: string; boundary: string; coverage: number }; fallback?: string; reason?: string; uploaded?: boolean
}
type Perm = { open: boolean; min: number; max: number; owner: string; source: string; confidence: '' | 'High' | 'Medium' | 'Low'; grain: string; value: number; notes: string; fval?: number }
type BaseRow = { id: string; name: string; eng: string; v: number[] }
type Baseline = { n: number; at: string; sig: string; rows: BaseRow[] }
type Ind = { id: string; name: string; desc?: string; dim?: string; dimOther?: string; arch: ArchId | null; engine: string; sliceArch: Record<string, string>; modes: Record<string, string>; modules: string[]; perms: Record<string, Perm> }
type Config = {
  brand: string; asset: string; subjectType: string; therapyArea: string; lifecycle: string; subnational: boolean; context: string; competing: boolean; market: string; cycle: string; start: string; end: string; granularity: string; grade: string; slices: Slice[]
  shared: { price: boolean; g2n: boolean }; inds: Ind[]; active: string; bindings: Record<string, Binding>
  depth: string; notes: string; forecasters: string[]; version: string
  selfForecast: boolean; visibility: string; baseline: Baseline | null; aiFields: string[]
  // lifecycle & governance edge cases
  prelaunch: boolean; launch: string; loe: string; loeTo: string; overlap: string; fx: string
  lockedBy: string; frozen: boolean; override: string; signReason: string
  cascade: number[]; lastActual: Record<string, number>; zeroValues: string[]; retired: boolean
  // collaboration, release & change tracking
  team: Member[]; release: string; viewers: string[]; geoRestrict: boolean; log: LogEntry[]; notified: string[]
}
type Role = 'Creator' | 'Editor' | 'Viewer'
type Member = { name: string; role: Role }
type LogEntry = { what: string; who: string; when: string }
type Seed = { from?: ModelRow; copy?: boolean; blank?: boolean; importFile?: string; importStreams?: string[] }

/** Product of nested shares, e.g. class × subclass × brand. Above 100% means the cascade is mis-specified. */
const cascadeTotal = (c: Config) => c.cascade.length ? Math.round(c.cascade.reduce((p, x) => p * x / 100, 100)) : 0
const comboCount = (c: Config) => c.slices.reduce((n, s) => n * Math.max(s.values.length, 1), 1)

const emptyInd = (id: string, name: string): Ind => ({ id, name, arch: null, engine: '', sliceArch: {}, modes: {}, modules: [], perms: {} })
function initInd(ind: Ind, arch: ArchId): Ind {
  return {
    ...ind, arch, engine: ENGINES[arch][0], sliceArch: {},
    modules: Array.from(new Set([...requiredFor(arch), ...MODULES.filter(m => m.rec?.includes(arch) && validFor(m, arch)).map(m => m.id)])),
    modes: { ...Object.fromEntries(modesFor(arch).map(m => [m.id, modeDefault(arch, m)])), trend: TREND.methods[0] },
    // CoE-locked rows carry the CoE's structural provenance; forecaster-editable rows must be documented by the configurator.
    perms: Object.fromEntries(assumptionsFor(arch).map(a => [a.id, a.open
      ? { open: true, min: a.min, max: a.max, owner: '', source: '', confidence: '' as const, grain: 'Monthly', value: a.base, notes: '' }
      : { open: false, min: a.min, max: a.max, owner: 'CoE analyst', source: 'Analog benchmark', confidence: 'High' as const, grain: 'Monthly', value: a.base, notes: '' }])),
  }
}
const archByName = (n: string) => ARCHETYPES.find(a => a.name === n)?.id ?? null
const nextVersion = (v: string) => { const [maj, min] = v.replace('v', '').split('.').map(Number); return `v${maj}.${(min || 0) + 1}` }

function freshConfig(seed: Seed): Config {
  const base: Config = {
    brand: 'Brand X', asset: 'Brand X', subjectType: 'Brand / Asset', therapyArea: 'Oncology', lifecycle: 'Pipeline (Pre-Launch)', subnational: false, context: '', competing: false, market: 'United States', cycle: 'OP 2027', start: '2026-01', end: '2030-12', granularity: 'Monthly', grade: 'Operational planning',
    slices: [{ id: 's1', name: 'Payer', values: ['Commercial', 'Medicare', 'Medicaid'] }, { id: 's2', name: 'Risk group', values: ['High risk', 'Standard risk'] }],
    shared: { price: true, g2n: true }, inds: [emptyInd('i1', 'Indication A'), emptyInd('i2', 'Revenue Stream 2')], active: 'i1', bindings: {},
    depth: 'Simple + advanced', notes: '', forecasters: [], version: 'v1.0',
    selfForecast: false, visibility: 'Assigned forecasters only', baseline: null, aiFields: [],
    prelaunch: false, launch: '', loe: '', loeTo: '', overlap: '', fx: '', lockedBy: '', frozen: false, override: '', signReason: '',
    cascade: [], lastActual: {}, zeroValues: [], retired: false,
    team: [{ name: ME, role: 'Creator' }, { name: 'K. Brandt (CoE)', role: 'Editor' }, { name: 'E. Walsh (Market Access)', role: 'Viewer' }], release: 'Working version', viewers: [], geoRestrict: true, log: [], notified: [],
  }
  if (seed.importFile) {
    const brand = seed.importFile.replace(/\.[^.]+$/, '').split(/[_\s-]+/)[0] || 'Imported'
    return { ...base, brand, asset: brand, inds: (seed.importStreams ?? ['Stream 1 (from sheet “Forecast_1”)', 'Stream 2 (from sheet “Forecast_2”)']).map((n, k) => ({ ...emptyInd(`i${k + 1}`, n), dim: 'Indication' })), aiFields: ['brand', 'inds'], notes: `Imported from ${seed.importFile}. Structure parsed by ${'Charles'}; archetypes still need your choice.`,
      log: [{ what: `Model imported from ${seed.importFile}`, who: ME, when: 'Just now' }] }
  }
  if (seed.blank) return { ...base, brand: '', asset: '', inds: [emptyInd('i1', '')] }
  if (seed.from) {
    const m = seed.from
    const inds = m.inds.map((x, k) => {
      const a = archByName(x.arch); const i = emptyInd(`i${k + 1}`, x.name); const ind = a ? initInd(i, a) : i
      return seed.copy ? { ...ind, perms: Object.fromEntries(Object.entries(ind.perms).map(([id, p]) => [id, p.open ? { ...p, owner: OWNERS[0], source: 'Internal Epi Library', confidence: 'Medium' as const } : p])) } : ind
    })
    const c: Config = { ...base, brand: m.brand, asset: m.brand, market: m.market === 'US' ? 'United States' : m.market, cycle: m.cycle, inds, active: inds[0].id, version: seed.copy ? 'v1.0' : m.version.endsWith('draft') ? m.version.replace(' draft', '') : nextVersion(m.version) }
    if (seed.copy) {
      const pre = { ...c, notes: `Copied from ${m.brand} ${m.version}.`, forecasters: FORECASTERS.slice(0, 2) }
      const bindings = Object.fromEntries(inputsFor(pre).map(b => [b.key, { source: b.input.suggested, owner: OWNERS[0], confidence: 'Medium' as const, status: 'ok' as const, msg: 'Connected.', fresh: { state: 'Current' as Fresh, refreshed: 'today 06:00', boundary: 'Aug 2026', coverage: 100 } }]))
      return { ...pre, bindings }
    }
    return applyFixture(c, m.fx)
  }
  return base
}

function applyFixture(c: Config, fx?: FixtureId): Config {
  const i0 = c.inds[0]
  const setPerm = (id: string, p: Partial<Perm>) => ({ ...c, inds: [{ ...i0, perms: { ...i0.perms, [id]: { ...i0.perms[id], ...p } } }, ...c.inds.slice(1)] })
  switch (fx) {
    case 'prelaunch': return { ...c, prelaunch: true, launch: '2027-03', start: '2027-01', notes: 'Analog-based: Hemlibra uptake curve.' }
    case 'loe': return { ...c, loe: '2026-12', loeTo: '2027-06' }
    case 'retired': return { ...c, retired: true }
    case 'locked': return { ...c, lockedBy: 'K. Brandt' }
    case 'frozen': return { ...c, frozen: true }
    case 'overlap': return { ...c, overlap: '' }
    case 'integrity': return { ...c, cascade: [62, 58, 290], inds: [{ ...i0, modes: { ...i0.modes, cascade: 'Three-level' } }] }
    case 'belowHistory': return { ...c, lastActual: { persist12: 48 } }
    case 'vaccineCeiling': return setPerm('capture', { open: true, min: 9, max: 14 })
    case 'bigSlices': return { ...c, slices: ['Payer', 'Region', 'Channel', 'Age band', 'Line of therapy'].map((n, k) => ({ id: `s${k}`, name: n, values: Array.from({ length: 8 }, (_, j) => `${n} ${j + 1}`) })) }
    case 'emptySlice': return { ...c, zeroValues: ['Payer · Medicaid'] }
    case 'fxMix': return { ...c, fx: '' }
    default: return c
  }
}

type Issue = { msg: string; field?: string; ind?: string }
type Bound = { key: string; scope: string; scopeLabel: string; input: DataInput }

function requiredFor(arch: ArchId | null) { return arch ? MODULES.filter(m => m.required?.includes(arch)).map(m => m.id) : [] }
const indLabel = (c: Config, i: Ind) => c.inds.length > 1 ? `${i.name || 'Untitled indication'} — ` : ''

function inputsFor(c: Config, only?: string): Bound[] {
  const out: Bound[] = []
  const seen = new Set<string>()
  c.inds.filter(i => !only || i.id === only).forEach(ind => {
    if (!ind.arch) return
    const keys = new Set(MODULES.filter(m => ind.modules.includes(m.id) && m.data).map(m => m.data!))
    ;[...BASE_INPUTS[ind.arch], ...[...keys].map(k => MODULE_INPUTS[k])].forEach(input => {
      const shared = (input.id === 'price' && c.shared.price) || (input.id === 'g2n' && c.shared.g2n)
      const scope = shared ? 'brand' : ind.id
      const key = `${scope}:${input.id}`
      if (seen.has(key)) return
      seen.add(key)
      out.push({ key, scope, scopeLabel: shared ? 'Brand-level · shared across indications' : ind.name || 'Untitled indication', input })
    })
  })
  return out
}
const resolved = (b?: Binding) => !!b && (b.status === 'ok' || (b.status === 'error' && !!b.fallback && b.fallback !== FALLBACKS[0] && (b.reason?.trim().length ?? 0) >= 10 && (b.fallback !== FALLBACKS[2] || !!b.uploaded)))
const missingMeta = (p: Perm) => !p.owner || !p.source || !p.confidence
const outOfBand = (p: Perm) => p.open && (p.min >= p.max || p.value < p.min || p.value > p.max)
/** Everything the baseline depends on. If it changes after a run, the baseline is out of date. */
const baselineSig = (c: Config) => JSON.stringify([c.inds.map(i => [i.id, i.arch, i.engine, i.modes, [...i.modules].sort(), Object.entries(i.perms).map(([k, p]) => [k, p.value, p.open, p.min, p.max])]), Object.entries(c.bindings).map(([k, b]) => [k, b.source, b.status]).sort()])

function validate(stage: number, c: Config): Issue[] {
  const out: Issue[] = []
  if (stage === 1) {
    if (!c.brand.trim()) out.push({ field: 'brand', msg: 'Enter the model name.' })
    if (!c.asset.trim()) out.push({ field: 'asset', msg: 'Enter the brand or asset name.' })
    if (c.inds.length === 0) out.push({ field: 'inds', msg: 'Add at least one revenue stream.' })
    const names = c.inds.map(i => i.name.trim().toLowerCase())
    c.inds.forEach((i, k) => {
      if (!i.name.trim()) out.push({ field: `ind-${i.id}`, msg: `Stream ${k + 1} needs a name.` })
      else if (names.indexOf(i.name.trim().toLowerCase()) !== k) out.push({ field: `ind-${i.id}`, msg: `“${i.name}” is listed twice.` })
    })
  }
  if (stage === 2) c.inds.forEach(i => {
    if (!i.arch) { out.push({ ind: i.id, msg: `${indLabel(c, i)}choose an archetype.` }); return }
    if (c.retired && i.arch === 'D-04') out.push({ ind: i.id, field: 'retired', msg: `${indLabel(c, i)}engine D-04 v1.4 retires Nov 30. Migrate to Patient-Flow (D-03) before publishing.` })
    if (ARCH_DETAIL[i.arch].ceiling && c.grade !== ARCH_DETAIL[i.arch].ceiling)
      out.push({ ind: i.id, field: 'combo', msg: `${indLabel(c, i)}${ARCHETYPES.find(a => a.id === i.arch)!.name} is screening grade — set the tier to Screening, or pick another archetype.` })
    if (c.grade === 'Valuation' && (i.engine.includes('beta') || ARCH_DETAIL[i.arch].status !== 'Certified'))
      out.push({ ind: i.id, field: 'combo', msg: `${indLabel(c, i)}${i.engine.includes('beta') ? 'beta engines' : 'archetypes under review'} can’t be used at Valuation tier. Pick a certified engine or lower the tier.` })
  })
  if (stage === 3) c.inds.forEach(i => {
    if (!i.arch) { out.push({ ind: i.id, msg: `${indLabel(c, i)}choose an archetype first.` }); return }
    modesFor(i.arch).filter(m => !m.optional && !m.options.includes(i.modes[m.id])).forEach(m => out.push({ ind: i.id, field: m.id, msg: `${indLabel(c, i)}set ${m.label.toLowerCase()}.` }))
    if (i.modes.time === 'Custom' && customTimeErr(i.modes)) out.push({ ind: i.id, field: 'time', msg: `${indLabel(c, i)}complete the custom time basis.` })
  })
  if (stage === 4) c.inds.forEach(i => {
    if (!i.arch) { out.push({ ind: i.id, msg: `${indLabel(c, i)}choose an archetype first.` }); return }
    if (i.arch === 'D-02') {
      const bad = MODULES.filter(m => i.modules.includes(m.id) && m.patients)
      if (bad.length) out.push({ ind: i.id, field: 'patients', msg: `${indLabel(c, i)}Rx-Share carries no patients — remove ${bad.map(m => m.name).join(', ')}.` })
    }
    MODULES.filter(m => i.modules.includes(m.id) && m.needs && !i.modules.includes(byName(m.needs).id))
      .forEach(m => out.push({ ind: i.id, field: 'needs', msg: `${indLabel(c, i)}${m.name} needs ${m.needs} attached.` }))
  })
  if (stage === 5) {
    // Pre-launch: no actuals exist, so analog or manual sources are enough and nothing needs a live test.
    const ins = inputsFor(c)
    if (c.prelaunch) {
      const unbound = ins.filter(i => !c.bindings[i.key]?.source)
      if (unbound.length) out.push({ msg: `${unbound.length} input${unbound.length > 1 ? 's need' : ' needs'} an analog or manual source.` })
      return out
    }
    const unbound = ins.filter(i => !c.bindings[i.key]?.source)
    const failed = ins.filter(i => c.bindings[i.key]?.status === 'error' && !resolved(c.bindings[i.key]))
    const untested = ins.filter(i => c.bindings[i.key]?.source && c.bindings[i.key]?.status === 'idle')
    if (!ins.length) out.push({ msg: 'No inputs yet — choose archetypes first.' })
    if (unbound.length) out.push({ msg: `${unbound.length} input${unbound.length > 1 ? 's have' : ' has'} no source yet.` })
    if (failed.length) out.push({ msg: `${failed.length} failed connection${failed.length > 1 ? 's need' : ' needs'} another source or a fallback with a reason.` })
    if (untested.length) out.push({ msg: `${untested.length} connection${untested.length > 1 ? 's' : ''} not tested yet.` })
  }
  if (stage === LAST) {
    if (!c.market) out.push({ field: 'market', msg: 'Choose a geography.' })
    if (!c.cycle) out.push({ field: 'cycle', msg: 'Choose a planning cycle.' })
    if (c.forecasters.length === 0 && !c.selfForecast) out.push({ field: 'forecasters', msg: 'Assign at least one forecaster, or act as the forecaster yourself.' })
    if (!c.visibility) out.push({ field: 'visibility', msg: 'Choose who can see this model.' })
  }
  return out
}

/** Non-blocking: things a CoE should know before publishing, but may accept. */
function warningsFor(c: Config): { msg: string; stage: number }[] {
  const out: { msg: string; stage: number }[] = []
  inputsFor(c).forEach(b => {
    const x = c.bindings[b.key]
    if (x?.fresh && x.fresh.state !== 'Current') out.push({ stage: 5, msg: `${b.input.name}: data is ${x.fresh.state.toLowerCase()} (${x.fresh.state === 'Partial' ? `${x.fresh.coverage}% coverage` : `refreshed ${x.fresh.refreshed}`}).` })
    if (x?.status === 'error' && resolved(x)) out.push({ stage: 5, msg: `${b.input.name}: running on “${x.fallback}”.` })
  })
  if (c.inds.length && c.inds.every(i => i.arch === 'D-06')) out.push({ stage: 2, msg: 'Every indication uses Trend / Extrapolation — a component method is standing in for the whole brand forecast.' })
  if (c.inds.some(i => i.arch === 'D-06' && i.modes.role === 'Blend') && c.inds.every(i => i.arch === 'D-06')) out.push({ stage: 3, msg: 'Trend role is “Blend” but there is no structural archetype to blend into.' })
  c.inds.forEach(i => {
    MODULES.filter(m => i.modules.includes(m.id) && GOVERNED.has(m.name)).forEach(m => out.push({ stage: 4, msg: `${indLabel(c, i)}${m.name} is a governed module and will be flagged for CoE sign-off.` }))
    if (i.engine.includes('beta')) out.push({ stage: 2, msg: `${indLabel(c, i)}runs on beta engine ${i.engine.split(' ')[0]}.` })
  })
  if (comboCount(c) > 5000) out.push({ stage: 1, msg: `${comboCount(c).toLocaleString()} slice combinations. Runs will be slow; collapse a slice or move it to reporting only.` })
  c.zeroValues.forEach(v => out.push({ stage: 1, msg: `${v} has no patients in the source data — it will forecast zero.` }))
  if (c.prelaunch) out.push({ stage: 5, msg: 'Pre-launch: no actuals boundary. Forecast is analog-based until launch data arrives.' })
  if (c.loe) out.push({ stage: 1, msg: `LOE is uncertain (${c.loe} → ${c.loeTo || c.loe}). Forecasters should carry an early and late LOE scenario.` })
  return out
}

/** "Fix for me": resolves what it safely can for one step and lists each change. Never picks an archetype from scratch or edits locked values. */
function autoFix(stage: number, c: Config): { c: Config; changes: string[] } {
  const ch: string[] = []
  let n = c
  const nm = (i: Ind, k: number) => i.name || `Stream ${k + 1}`
  if (stage === 1) {
    if (!n.brand.trim()) { const v = n.asset.trim() || 'Velsipity'; n = { ...n, brand: v }; ch.push(`Model name set to “${v}”`) }
    if (!n.asset.trim()) { n = { ...n, asset: n.brand }; ch.push(`Brand or asset set to “${n.brand}”`) }
    if (!n.inds.length) { const i = emptyInd('i1', 'Ulcerative colitis'); n = { ...n, inds: [i], active: i.id }; ch.push('Added revenue stream “Ulcerative colitis”') }
    const seen = new Set<string>()
    n = { ...n, inds: n.inds.map((i, k) => {
      let name = i.name.trim()
      if (!name) { name = `Revenue stream ${k + 1}`; ch.push(`Stream ${k + 1} named “${name}”`) }
      const base = name; let j = 2
      while (seen.has(name.toLowerCase())) name = `${base} (${j++})`
      if (name !== base && i.name.trim()) ch.push(`Duplicate “${base}” renamed to “${name}”`)
      seen.add(name.toLowerCase())
      return name === i.name ? i : { ...i, name }
    }) }
  }
  if (stage === 2) {
    const donor = n.inds.find(i => i.arch)
    const drop: string[] = []
    n = { ...n, inds: n.inds.map((i, k) => {
      if (!i.arch && donor) { drop.push(i.id); ch.push(`${nm(i, k)}: archetype copied from ${donor.name} (${archName(donor.arch)})`); return initInd(i, donor.arch!) }
      if (n.retired && i.arch === 'D-04') { drop.push(i.id); ch.push(`${nm(i, k)}: migrated from retiring D-04 to Patient-Flow (D-03)`); return initInd(i, 'D-03') }
      return i
    }) }
    n = { ...n, bindings: Object.fromEntries(Object.entries(n.bindings).filter(([key]) => !drop.some(id => key.startsWith(`${id}:`)))) }
    const ceil = n.inds.map(i => i.arch && ARCH_DETAIL[i.arch].ceiling).find(Boolean)
    if (ceil && n.grade !== ceil) { n = { ...n, grade: ceil }; ch.push(`Tier set to ${ceil} to match the screening-grade archetype`) }
    if (n.grade === 'Valuation') {
      n = { ...n, inds: n.inds.map((i, k) => {
        if (!i.arch || !i.engine.includes('beta')) return i
        const cert = ENGINES[i.arch].find(e => e.includes('certified'))
        if (cert) { ch.push(`${nm(i, k)}: engine switched to certified ${cert.split(' ')[0]}`); return { ...i, engine: cert } }
        return i
      }) }
      if (n.inds.some(i => i.arch && (i.engine.includes('beta') || ARCH_DETAIL[i.arch].status !== 'Certified'))) { n = { ...n, grade: 'Operational planning' }; ch.push('Tier lowered to Operational planning (archetype under review)') }
    }
  }
  if (stage === 3) {
    n = { ...n, inds: n.inds.map((i, k) => {
      if (!i.arch) return i
      const modes = { ...i.modes }
      modesFor(i.arch).filter(m => !m.optional && !m.options.includes(modes[m.id])).forEach(m => { modes[m.id] = modeDefault(i.arch!, m); ch.push(`${nm(i, k)}: ${m.label.toLowerCase()} set to ${modes[m.id]}`) })
      if (modes.time === 'Custom' && customTimeErr(modes)) {
        if (customTimeErr(modes).startsWith('Enter')) modes.time_n = '1'
        if (modes.time_from && modes.time_to && Number(modes.time_to) < Number(modes.time_from)) modes.time_to = modes.time_from
        ch.push(`${nm(i, k)}: custom time basis completed`)
      }
      return { ...i, modes }
    }) }
    if (cascadeTotal(n) > 100) { n = { ...n, cascade: n.cascade.map(v => Math.min(v, 100)) }; ch.push('Share cascade levels capped at 100%') }
  }
  if (stage === 4) {
    n = { ...n, inds: n.inds.map((i, k) => {
      if (!i.arch) return i
      let mods = i.modules
      const bad = MODULES.filter(m => mods.includes(m.id) && !validFor(m, i.arch!))
      if (bad.length) { mods = mods.filter(id => !bad.some(m => m.id === id)); ch.push(`${nm(i, k)}: removed ${bad.map(m => m.name).join(', ')} (not valid for ${archName(i.arch)})`) }
      MODULES.filter(m => mods.includes(m.id) && m.needs && !mods.includes(byName(m.needs).id)).forEach(m => { mods = [...mods, byName(m.needs!).id]; ch.push(`${nm(i, k)}: attached ${m.needs}, needed by ${m.name}`) })
      return mods === i.modules ? i : { ...i, modules: mods }
    }) }
  }
  if (stage === 5) {
    const bindings = { ...n.bindings }
    const ok = { status: 'ok' as const, msg: 'Connected.', fresh: { state: 'Current' as Fresh, refreshed: 'today 06:00', boundary: 'Aug 2026', coverage: 100 }, fallback: undefined, reason: undefined }
    let bound = 0, retried = 0, tested = 0
    inputsFor(n).forEach(b => {
      const x = bindings[b.key]
      const base = x ?? { source: '', owner: OWNERS[0], confidence: 'Medium' as const, status: 'idle' as const }
      if (!x?.source) { bindings[b.key] = { ...base, source: b.input.suggested, ...ok }; bound++ }
      else if (x.status === 'error' && !resolved(x)) { bindings[b.key] = { ...x, source: x.source === b.input.suggested ? 'IQVIA LAAD claims' : b.input.suggested, ...ok }; retried++ }
      else if (x.status === 'idle') { bindings[b.key] = { ...x, ...ok }; tested++ }
    })
    if (bound) ch.push(`Bound and tested the suggested source on ${bound} input${bound > 1 ? 's' : ''}`)
    if (retried) ch.push(`Switched ${retried} failed connection${retried > 1 ? 's' : ''} to a working governed source`)
    if (tested) ch.push(`Tested ${tested} untested connection${tested > 1 ? 's' : ''}`)
    n = { ...n, bindings }
  }
  if (stage === LAST) {
    if (!n.market) { n = { ...n, market: 'United States' }; ch.push('Geography set to United States') }
    if (!n.cycle) { n = { ...n, cycle: CYCLES[0].name }; ch.push(`Planning cycle set to ${CYCLES[0].name}`) }
    if (!n.forecasters.length && !n.selfForecast) { n = { ...n, forecasters: FORECASTERS.slice(0, 2) }; ch.push(`Assigned ${FORECASTERS.slice(0, 2).join(' and ')} as forecasters`) }
    if (!n.visibility) { n = { ...n, visibility: 'Assigned forecasters only' }; ch.push('Visibility set to assigned forecasters only') }
  }
  return { c: n, changes: ch }
}
/** Runs autoFix across steps in order, so later fixes (e.g. the baseline) see earlier ones. */
function autoFixAll(stages: number[], c: Config) {
  let n = c; const changes: string[] = []
  ;[...stages].sort((a, b) => a - b).forEach(s => { const r = autoFix(s, n); n = r.c; changes.push(...r.changes) })
  const left = stages.flatMap(s => validate(s, n).map(i => i.msg))
  return { c: n, changes, left }
}

/* ───────────────────────── App ───────────────────────── */

type Toast = { tone: 'ok' | 'err' | 'info'; text: string }

export default function App() {
  const [view, setView] = useState<'landing' | 'models' | 'config' | 'admin' | 'forecast'>('landing')
  const [models, setModels] = useState<ModelRow[]>(SEED_MODELS)
  const [seed, setSeed] = useState<Seed>({})
  const [run, setRun] = useState(0)
  const [toast, setToast] = useState<Toast | null>(null)
  const [ai, setAi] = useState(false)
  const [fixtures, setFixtures] = useState(false)
  const toggleFixtures = () => {
    const on = !fixtures
    setFixtures(on)
    setModels(ms => on ? [...FIXTURE_MODELS, ...ms] : ms.filter(m => !m.fx))
    setView('models')
    setToast({ tone: 'info', text: on ? `${FIXTURE_MODELS.length} edge-case fixtures added to the library` : 'Edge-case fixtures removed' })
  }

  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(null), 3400); return () => clearTimeout(t) } }, [toast])
  // Assistant hidden for now: no top-bar button or Ctrl/⌘ + / shortcut, so `ai` stays false

  const open = (s: Seed) => { setSeed(s); setRun(r => r + 1); setView('config'); window.scrollTo({ top: 0 }) }
  const resume = (m: ModelRow) => open(m.id === 'a' ? {} : { from: m })

  return (
    view === 'landing' ? <><Landing onCoE={() => setView('models')} onForecast={() => { setView('forecast'); window.scrollTo({ top: 0 }) }} /><Charles greeting={`Hi ${ME.split(' ')[0]}, I’m ${ASSISTANT}. Pick a workspace and I’ll come with you.`} context={['Home']} chips={['Help me build a model']} respond={pageRespond('the home page')} /></> :
    <div className="flex min-h-dvh flex-col">
      <TopBar onHome={() => setView('landing')} onAdmin={() => { setView('admin'); window.scrollTo({ top: 0 }) }} onLogout={() => { setView('landing'); setToast({ tone: 'info', text: 'You’ve been logged out.' }) }} models={models} onResume={resume} ai={ai} onAI={() => setAi(v => !v)} notify={setToast} fixtures={fixtures} onFixtures={toggleFixtures} />
      {view === 'admin' && <Charles greeting={`I can explain roles, scopes and BD access on this page. Changes here are made by you, not me.`} context={['Admin controls']} chips={['What does an Editor do?', 'How is BD access granted?']} respond={pageRespond('Admin controls')} />}
      {view === 'forecast' ? <Forecaster onHome={() => setView('landing')} notify={setToast} /> : view === 'admin' ? <AccessControl notify={setToast} onBack={() => setView('models')} /> : view === 'models'
        ? <ModelsHome fixtures={fixtures} models={models} setModels={setModels} onOpen={open} onResume={resume} notify={setToast} ai={ai} closeAI={() => setAi(false)} />
        : <Configurator key={run} seed={seed} onExit={() => setView('models')} notify={setToast} ai={ai} closeAI={() => setAi(false)}
            onPublished={(c) => setModels(ms => {
              const row: ModelRow = { tag: undefined, fx: undefined, id: seed.from && !seed.copy ? seed.from.id : `n${run}`, brand: c.brand, inds: c.inds.map(i => ({ name: i.name, arch: ARCHETYPES.find(a => a.id === i.arch)?.name ?? '' })), market: c.market === 'United States' ? 'US' : c.market, cycle: c.cycle, version: c.version, status: 'Published', fresh: 'Current', issues: 0, updated: 'Just now', by: 'You', versions: [{ v: c.version, date: 'Today', by: ME, note: c.notes || 'Published from the configurator.', scenarios: 0 }, ...(seed.from && !seed.copy ? seed.from.versions : [])] }
              const id = seed.from && !seed.copy ? seed.from.id : Object.keys(seed).length === 0 ? 'a' : null
              return id ? ms.map(m => m.id === id ? { ...row, id } : m) : [row, ...ms]
            })} />}
      {toast && (
        <div role="status" className="rise fixed bottom-24 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-md bg-text px-4 py-2.5 text-sm text-white shadow-lg">
          {toast.tone === 'ok' ? <CheckCircle2 size={16} className="text-[#6ee7b7]" /> : toast.tone === 'err' ? <AlertCircle size={16} className="text-[#fda4af]" /> : <Info size={16} />}
          {toast.text}
        </div>
      )}
    </div>
  )
}

/* ───────────────────────── Landing ───────────────────────── */

function ForecastBackdrop() {
  // Faint dot grid, fading toward the edges
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 [background-image:radial-gradient(circle,var(--color-border-strong)_1px,transparent_1px)] [background-size:22px_22px] [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_75%)] opacity-60" />
    </div>
  )
}

const ROLE_ENTRIES: { id: string; title: string; who: string; desc: string; live: boolean }[] = [
  { id: 'config', title: 'Configure models', who: 'Forecasting CoE', live: true, desc: 'Set up, govern and publish forecast models.' },
  { id: 'forecast', title: 'Create or manage forecasts', who: 'Brand and commercial forecasters', live: true, desc: 'Build forecasts and scenarios from published models.' },
  { id: 'perf', title: 'View performance and decisions', who: 'Leadership and brand teams', live: false, desc: 'Track forecasts against actuals and record decisions.' },
]

function Landing({ onCoE, onForecast }: { onCoE: () => void; onForecast: () => void }) {
  const [note, setNote] = useState('')
  const downloadCode = () => {
    const link = document.createElement('a')
    link.href = '/figma-make-app-code.zip'
    link.download = 'figma-make-app-code.zip'
    link.click()
  }
  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-background selection:bg-brand selection:text-white">
      <ForecastBackdrop />
      <header className="relative z-10 flex h-16 items-center justify-between px-8">
        <Logo />
        <span className="hidden text-xs text-text-3 md:inline">Signed in as <strong className="font-semibold text-text">{ME}</strong></span>
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-5xl flex-1 flex-col items-center justify-center px-6 pb-16">
        <div className="flex items-center gap-2">
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-text-3">Integrated Forecasting</p>
          <Badge tone="warn">MVP prototype</Badge>
        </div>
        <h1 className="mt-3 text-center text-3xl font-bold tracking-tight text-text sm:text-4xl">
          Build the model once. <span className="text-brand">Forecast inside it.</span>
        </h1>
        <p className="mt-3 max-w-xl text-center text-sm text-text-2">Pick where you want to start.</p>


        <div className="mt-10 grid w-full gap-5 md:grid-cols-3">
          {ROLE_ENTRIES.map(r => (
            <div key={r.id} className={cx('flex flex-col rounded-2xl border bg-surface/95 p-6 backdrop-blur', r.live ? 'border-brand/30 shadow-lg shadow-brand/5' : 'border-dashed border-border-strong')}>
              <div className="flex items-center justify-between gap-2">
                <p className="font-mono text-[11px] font-semibold uppercase tracking-wider text-text-3">{r.who}</p>
                <Badge tone={r.live ? 'ok' : 'neutral'}>{r.live ? 'Available' : 'Concept'}</Badge>
              </div>
              <h2 className="mt-3 text-xl font-bold tracking-tight">{r.title}</h2>
              <p className="mt-2 flex-1 text-sm text-text-2">{r.desc}</p>
              {r.live
                ? <button type="button" onClick={r.id === 'forecast' ? onForecast : onCoE} className="mt-6 inline-flex items-center gap-2 border-t border-border pt-4 text-sm font-bold text-brand hover:underline">Get started <ArrowRight size={16} /></button>
                : <button type="button" onClick={() => setNote(`${r.title} is a concept in this prototype and is not built yet. Its scope is awaiting forecasting SME validation.`)} className="mt-6 inline-flex items-center gap-2 border-t border-border pt-4 text-sm font-semibold text-text-2 hover:text-brand">Coming soon <ArrowRight size={16} /></button>}
            </div>
          ))}
        </div>
        {note && <p role="status" className="mt-4 max-w-2xl text-center text-sm text-text-2">{note}</p>}
      </main>
      <footer className="relative z-10 flex justify-center px-6 pb-6">
        <Btn
          variant="secondary"
          size="sm"
          icon={<Download size={14} aria-hidden />}
          onClick={downloadCode}
          className="bg-surface/80 text-xs text-text-2 shadow-sm backdrop-blur hover:border-brand/40 hover:text-brand"
        >
          Download updated code
        </Btn>
      </footer>
    </div>
  )
}

/* ───────────────────────── Shell ───────────────────────── */

function useDismiss(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const h = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) close() }
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') close() }
    document.addEventListener('mousedown', h); document.addEventListener('keydown', k)
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('keydown', k) }
  }, [open, close])
  return ref
}




function TopBar({ onHome, onAdmin, onLogout, models, onResume, fixtures }: { onHome: () => void; onAdmin: () => void; onLogout: () => void; models: ModelRow[]; onResume: (m: ModelRow) => void; ai: boolean; onAI: () => void; notify: (t: Toast) => void; fixtures: boolean; onFixtures: () => void }) {
  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-4 border-b border-border bg-surface px-5">
      <button type="button" onClick={onHome} aria-label="Go to home"><Logo /></button>
      <div className="ml-auto flex items-center gap-1.5">
        <ActivityMenu fixtures={fixtures} />
        <Notifications models={models} onResume={onResume} />
        <ProfileMenu onAdmin={onAdmin} onLogout={onLogout} />
      </div>
    </header>
  )
}

type Note = { id: string; tone: 'brand' | 'warn' | 'ok' | 'err'; title: string; body: string; time: string; cta?: string; model?: ModelRow }

function notesFor(models: ModelRow[]): Note[] {
  const out: Note[] = []
  const byFx = (f: FixtureId) => models.find(m => m.fx === f)
  if (byFx('retired')) out.push({ id: 'n-ret', tone: 'warn', title: 'Engine D-04 v1.4 retires Nov 30', body: 'Ibrance and 1 other model run on it. Migrate to Patient-Flow (D-03).', time: 'Today, 08:15', cta: 'Review', model: byFx('retired') })
  if (byFx('locked')) out.push({ id: 'n-lock', tone: 'brand', title: 'K. Brandt requested control of Abrysvo (maternal)', body: 'You hold the draft lock. Hand over or keep editing.', time: 'Today, 09:40', cta: 'Open', model: byFx('locked') })
  if (byFx('frozen')) out.push({ id: 'n-frz', tone: 'err', title: 'Q4 2026 Re-forecast is frozen', body: 'Comirnaty draft is read-only. Overrides need a reason.', time: 'Yesterday', cta: 'Open', model: byFx('frozen') })
  if (byFx('diff')) out.push({ id: 'n-pin', tone: 'brand', title: 'Michelle Tran is pinned to Cibinqo v2.3', body: 'When v2.4 publishes she’ll be offered a rebase with a diff.', time: 'Today' })
  if (models.some(m => m.fx)) out.push({ id: 'n-rst', tone: 'err', title: 'IQVIA restated history for Nurtec ODT', body: 'Jan–Mar 2026 revised by −4%. 3 inputs affected.', time: 'Today, 06:00', cta: 'Review', model: models.find(m => m.id === 'c') })
  models.filter(m => !m.restricted && !m.fx).forEach(m => {
    if (m.status === 'Draft') out.push({ id: m.id, tone: 'brand', title: `Continue configuring ${m.brand} ${m.market}`, body: `Step ${m.step ?? 1} of ${LAST} · ${m.issues} item${m.issues === 1 ? '' : 's'} to fix`, time: m.updated, cta: 'Resume', model: m })
    if (m.fresh !== 'Current' && m.status === 'Published') out.push({ id: m.id + 'f', tone: 'err', title: `${m.brand}: data ${m.fresh.toLowerCase()}`, body: 'Forecasters see a stale-data warning on their scenarios', time: m.updated, cta: 'Check feeds', model: m })
    if (m.status === 'Published' && m.updated === 'Just now') out.push({ id: m.id + 'p', tone: 'ok', title: `${m.brand} ${m.version} published`, body: 'Forecasters notified', time: m.updated })
  })
  return out
}

function ActivityMenu({ fixtures }: { fixtures: boolean }) {
  const [open, setOpen] = useState(false)
  const ref = useDismiss(open, () => setOpen(false))
  const items = fixtures ? [...FIXTURE_ACTIVITY, ...ACTIVITY] : ACTIVITY

  return (
    <div ref={ref} className="relative">
      <button type="button" onClick={() => setOpen(!open)} aria-label="Recent activity" aria-expanded={open} title="Recent activity"
        className={cx('grid h-9 w-9 place-items-center rounded-full text-text-2 transition-colors hover:bg-surface-2 hover:text-text', open && 'bg-surface-2 text-text')}>
        <History size={18} />
      </button>
      {open && (
        <div className="rise absolute right-0 top-11 z-40 w-[360px] max-w-[calc(100vw-24px)] overflow-hidden rounded-lg border border-border bg-surface shadow-xl">
          <div className="border-b border-border px-4 py-3">
            <p className="text-sm font-semibold">Recent activity</p>
            <p className="text-xs text-text-3">Who changed, submitted or published what.</p>
          </div>
          <ol className="max-h-[420px] space-y-3 overflow-y-auto px-4 py-3">
            {items.map(a => (
              <li key={a.when} className="flex gap-3 text-sm">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-surface-2 text-text-2"><a.icon size={13} /></span>
                <p className="flex-1"><b>{a.who}</b> <span className="text-text-2">{a.what}</span><span className="block text-xs text-text-3">{a.when}</span></p>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  )
}

function Notifications({ models, onResume }: { models: ModelRow[]; onResume: (m: ModelRow) => void }) {
  const [open, setOpen] = useState(false)
  const [read, setRead] = useState<Set<string>>(new Set())
  const [dismissed, setDismissed] = useState<Set<string>>(new Set())
  const ref = useDismiss(open, () => setOpen(false))
  const notes = notesFor(models).filter(n => !dismissed.has(n.id)).sort((a, b) => Number(!!b.cta) - Number(!!a.cta))
  const unread = notes.filter(n => n.cta && !read.has(n.id)).length
  const icon = (t: Note['tone']) => t === 'warn' ? <AlertTriangle size={15} /> : t === 'ok' ? <CheckCircle2 size={15} /> : t === 'err' ? <Clock size={15} /> : <FileText size={15} />
  const tint = { brand: 'bg-brand-soft text-brand', warn: 'bg-warn-soft text-warn', ok: 'bg-ok-soft text-ok', err: 'bg-err-soft text-err' }

  return (
    <div ref={ref} className="relative">
      <button type="button" onClick={() => setOpen(!open)} aria-label={`Notifications${unread ? `, ${unread} need action` : ''}`} aria-expanded={open}
        className={cx('relative grid h-9 w-9 place-items-center rounded-full text-text-2 transition-colors hover:bg-surface-2 hover:text-text', open && 'bg-surface-2 text-text')}>
        <Bell size={18} />
        {unread > 0 && <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-err px-1 text-[10px] font-bold text-white ring-2 ring-surface">{unread}</span>}
      </button>
      {open && (
        <div className="rise absolute right-0 top-11 z-40 w-[380px] max-w-[calc(100vw-24px)] overflow-hidden rounded-lg border border-border bg-surface shadow-xl">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <p className="text-sm font-semibold">Notifications {unread > 0 && <span className="ml-1 font-normal text-text-3">· {unread} need action</span>}</p>
            {notes.length > 0 && <button type="button" onClick={() => setRead(new Set(notes.map(n => n.id)))} className="text-xs font-semibold text-brand hover:underline">Mark all read</button>}
          </div>
          {notes.length === 0 ? (
            <div className="px-6 py-10 text-center">
              <div className="mx-auto grid h-10 w-10 place-items-center rounded-full bg-ok-soft text-ok"><Check size={18} /></div>
              <p className="mt-3 text-sm font-semibold">You’re all caught up</p>
              <p className="mt-1 text-xs text-text-2">Drafts, returns, stale feeds and publish events show up here.</p>
            </div>
          ) : (
            <ul className="max-h-[420px] divide-y divide-border overflow-y-auto">
              {notes.map(n => {
                const isUnread = !!n.cta && !read.has(n.id)
                return (
                  <li key={n.id} className={cx('group flex gap-3 px-4 py-3', isUnread && 'bg-brand-soft/40')}>
                    <span className={cx('grid h-8 w-8 shrink-0 place-items-center rounded-md', tint[n.tone])}>{icon(n.tone)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-semibold leading-snug">{n.title}</p>
                      <p className="text-xs text-text-2">{n.body}</p>
                      <div className="mt-1.5 flex items-center gap-3">
                        <span className="text-[11px] text-text-3">{n.time}</span>
                        {n.cta && n.model && <button type="button" onClick={() => { setRead(r => new Set(r).add(n.id)); setOpen(false); onResume(n.model!) }} className="inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">{n.cta}<ArrowRight size={12} /></button>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {isUnread && <span className="mt-1 h-2 w-2 rounded-full bg-brand" aria-label="Unread" />}
                      <button type="button" onClick={() => setDismissed(d => new Set(d).add(n.id))} aria-label="Dismiss" className="text-text-3 opacity-0 transition-opacity hover:text-text group-hover:opacity-100 focus:opacity-100"><X size={14} /></button>
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}

/* ───────────────────────── Assistant (bounded by the governed engine) ───────────────────────── */

type Reply =
  | { kind: 'text'; title: string; body: ReactNode; cites?: string[]; link?: { label: string; go: () => void } }
  | { kind: 'list'; title: string; empty: string; items: { text: string; tone: 'err' | 'warn' | 'ok'; link?: { label: string; go: () => void } }[] }
  | { kind: 'proposal'; title: string; changes: string[]; apply: () => void; undo: () => void; missing?: string[]; link?: { label: string; go: () => void } }
  | { kind: 'denied'; title: string; body: string }
type Msg = { id: number; q?: string; reply?: Reply; state?: 'proposed' | 'applied' | 'undone' | 'dismissed' }

function Assistant({ open, onClose, context, chips, respond }: { open: boolean; onClose: () => void; context: string[]; chips: string[]; respond: (q: string) => Reply }) {
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [q, setQ] = useState('')
  const [thinking, setThinking] = useState(false)
  const end = useRef<HTMLDivElement>(null)
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, thinking])
  useEffect(() => { if (!open) return; const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [open, onClose])
  if (!open) return null
  const send = (text: string) => {
    const t = text.trim(); if (!t || thinking) return
    setQ(''); setMsgs(m => [...m, { id: Date.now(), q: t }]); setThinking(true)
    setTimeout(() => { const r = respond(t); setMsgs(m => [...m, { id: Date.now() + 1, reply: r, state: r.kind === 'proposal' ? 'proposed' : undefined }]); setThinking(false) }, 650)
  }
  const setState = (id: number, state: Msg['state']) => setMsgs(m => m.map(x => x.id === id ? { ...x, state } : x))

  return (
    <aside role="complementary" aria-label="Assistant" className="rise fixed bottom-0 right-0 top-14 z-40 flex w-full max-w-[400px] flex-col border-l border-border bg-surface shadow-2xl">
      <header className="border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 text-sm font-semibold"><Sparkles size={15} className="text-brand" />Assistant</p>
          <Btn variant="ghost" size="sm" onClick={onClose} icon={<X size={16} />}><span className="sr-only">Close assistant</span></Btn>
        </div>
        <p className="text-xs text-text-2">Explains, audits and proposes. Only the governed engine calculates — nothing changes until you confirm.</p>
        <div className="mt-2 flex flex-wrap gap-1">{context.map(x => <span key={x} className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-text-2">{x}</span>)}</div>
      </header>
      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {msgs.length === 0 && (
          <div className="rounded-lg bg-background p-4 text-sm text-text-2">
            <p className="font-semibold text-text">What can I help with?</p>
            <p className="mt-1 text-xs">Try one of these, or ask in your own words.</p>
          </div>
        )}
        {msgs.map(m => m.q ? (
          <div key={m.id} className="ml-8 rounded-lg rounded-br-sm bg-brand px-3 py-2 text-sm text-white">{m.q}</div>
        ) : m.reply && <ReplyCard key={m.id} r={m.reply} state={m.state} setState={s => setState(m.id, s)} />)}
        {thinking && <div className="flex items-center gap-2 text-xs text-text-3"><Loader2 size={13} className="animate-spin" />Checking the model…</div>}
        <div ref={end} />
      </div>
      <div className="border-t border-border p-3">
        <div className="mb-2 flex gap-1.5 overflow-x-auto pb-1">
          {chips.map(c => <button type="button" key={c} onClick={() => send(c)} className="shrink-0 rounded-full border border-border px-2.5 py-1 text-xs text-text-2 hover:border-brand hover:text-brand">{c}</button>)}
        </div>
        <form onSubmit={e => { e.preventDefault(); send(q) }} className="flex gap-2">
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Ask about this model…" aria-label="Ask the assistant" className={inputCls()} />
          <Btn disabled={!q.trim() || thinking} onClick={() => send(q)} icon={<Send size={15} />}><span className="sr-only">Send</span></Btn>
        </form>
      </div>
    </aside>
  )
}

/* ───────────────────────── Charles (collapsible configuration assistant) ───────────────────────── */

const ASSISTANT = 'Charles' // Name pending confirmation against the internal naming convention.

function AssistantMark({ size = 32 }: { size?: number }) {
  return (
    <span className="grid shrink-0 place-items-center rounded-full bg-brand text-white shadow-sm ring-2 ring-brand-soft" style={{ width: size, height: size }}>
      <Sparkles size={Math.round(size * 0.5)} />
    </span>
  )
}

/** Floating launcher, bottom-right on every page. Opens a chat panel; full screen on phones. Stays mounted so the conversation is kept. */
function Charles({ open: openProp, onToggle, context, chips, respond, greeting, extra, busy }: { open?: boolean; onToggle?: () => void; context: string[]; chips: string[]; respond: (q: string) => Reply; greeting: string; extra?: ReactNode; busy?: boolean }) {
  const [own, setOwn] = useState(false)
  const open = openProp ?? own
  const toggle = onToggle ?? (() => setOwn(v => !v))
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [q, setQ] = useState('')
  const [thinking, setThinking] = useState(false)
  const box = useRef<HTMLDivElement>(null)
  useEffect(() => { box.current?.scrollTo({ top: box.current.scrollHeight, behavior: 'smooth' }) }, [msgs, thinking, extra])
  useEffect(() => { if (!open) return; const k = (e: KeyboardEvent) => e.key === 'Escape' && toggle(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [open])
  const send = (text: string) => {
    const t = text.trim(); if (!t || thinking) return
    setQ(''); setMsgs(m => [...m, { id: Date.now(), q: t }]); setThinking(true)
    setTimeout(() => { const r = respond(t); setMsgs(m => [...m, { id: Date.now() + 1, reply: r, state: r.kind === 'proposal' ? 'proposed' : undefined }]); setThinking(false) }, 600)
  }
  const setState = (id: number, state: Msg['state']) => setMsgs(m => m.map(x => x.id === id ? { ...x, state } : x))

  return (
    <>
      <button type="button" onClick={toggle} aria-label={open ? `Close ${ASSISTANT}` : `Open ${ASSISTANT}`} aria-expanded={open}
        className={cx('fixed bottom-4 right-4 z-[55] grid h-14 w-14 place-items-center rounded-full text-white shadow-xl outline-none transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 sm:bottom-6 sm:right-6', open && 'max-sm:hidden', busy ? 'agent-bg' : 'bg-brand')}>
        {busy && <span aria-hidden className="absolute inset-0 animate-ping rounded-full bg-[#7c3aed]/40" />}
        {open ? <X size={22} /> : <Sparkles size={22} className={busy ? 'animate-pulse' : undefined} />}
        {!open && !busy && <span className="pointer-events-none absolute right-16 hidden whitespace-nowrap rounded-full bg-text px-2.5 py-1 text-xs font-semibold text-white shadow md:block">Ask {ASSISTANT}</span>}
        {busy && !open && <span className="pointer-events-none absolute right-16 whitespace-nowrap rounded-full bg-text px-2.5 py-1 text-xs font-semibold text-white shadow">{ASSISTANT} is working…</span>}
      </button>
      <aside aria-label={ASSISTANT} className={cx(open ? 'rise flex' : 'hidden',
        'fixed inset-0 z-[56] flex-col overflow-hidden bg-surface shadow-2xl sm:inset-auto sm:bottom-24 sm:right-6 sm:h-[min(640px,calc(100dvh-8rem))] sm:w-[400px] sm:rounded-2xl sm:border sm:border-border')}>
        <header className="relative border-b border-border px-4 py-3">
          <span aria-hidden className={cx('absolute inset-x-0 top-0 h-1', busy ? 'agent-bg' : 'bg-brand')} />
          <div className="flex items-center gap-3">
            <span className={cx('grid h-9 w-9 shrink-0 place-items-center rounded-full text-white', busy ? 'agent-bg' : 'bg-brand')}><Sparkles size={17} /></span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold leading-tight">{ASSISTANT}</p>
              <p className="flex items-center gap-1.5 text-xs text-text-3"><span className={cx('h-1.5 w-1.5 rounded-full', busy ? 'animate-pulse bg-[#7c3aed]' : 'bg-ok')} />{busy ? 'Working in the configurator' : 'Forecasting assistant'}</p>
            </div>
            <Btn variant="ghost" size="sm" onClick={toggle} icon={<X size={16} />} title={`Close ${ASSISTANT}`}><span className="sr-only">Close {ASSISTANT}</span></Btn>
          </div>
          <div className="mt-2.5 flex flex-wrap gap-1">{context.map(x => <span key={x} className="max-w-full truncate rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-text-2">{x}</span>)}</div>
        </header>
        <div ref={box} className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
          <div className="flex gap-2.5">
            <AssistantMark size={24} />
            <div className="min-w-0 rounded-lg rounded-tl-sm bg-background p-3 text-sm text-text-2">{greeting}</div>
          </div>
          {extra}
          {msgs.map(m => m.q ? (
            <div key={m.id} className="ml-8 break-words rounded-lg rounded-br-sm bg-brand px-3 py-2 text-sm text-white">{m.q}</div>
          ) : m.reply && <ReplyCard key={m.id} r={m.reply} state={m.state} setState={st => setState(m.id, st)} />)}
          {thinking && <div className="flex items-center gap-2 text-xs text-text-3"><Loader2 size={13} className="animate-spin" />{ASSISTANT} is thinking…</div>}
        </div>
        <div className="border-t border-border p-3">
          <div className="mb-2 flex gap-1.5 overflow-x-auto pb-1">
            {chips.map(c => <button type="button" key={c} onClick={() => send(c)} className="shrink-0 rounded-full border border-border px-2.5 py-1 text-xs text-text-2 hover:border-brand hover:text-brand">{c}</button>)}
          </div>
          <form onSubmit={e => { e.preventDefault(); send(q) }} className="flex gap-2">
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Describe your model, or ask a question…" aria-label={`Message ${ASSISTANT}`} className={inputCls()} />
            <Btn disabled={!q.trim() || thinking} onClick={() => send(q)} icon={<Send size={15} />}><span className="sr-only">Send</span></Btn>
          </form>
          <p className="mt-2 text-[10px] leading-snug text-text-3">Suggests changes for you to review. Never publishes, never edits engine math or CoE-locked assumptions.</p>
        </div>
      </aside>
    </>
  )
}

/** Chat card that scripts the bounded use case and shows each agent step as it runs. */
function DemoCard({ steps, demo, onRun, onStop, onReview }: { steps: string[]; demo: { i: number; done: boolean } | null; onRun: () => void; onStop: () => void; onReview: () => void }) {
  const running = !!demo && !demo.done
  return (
    <div className={cx('rounded-xl p-[1.5px]', running ? 'agent-bg' : 'bg-[linear-gradient(90deg,#0000c9,#7c3aed,#db2777)]')}>
      <div className="rounded-[10px] bg-surface p-3.5 text-sm">
        <span className="mb-1.5 inline-flex items-center gap-1 rounded bg-[#7c3aed]/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[#7c3aed]"><Zap size={10} />Demo · agent workflow</span>
        <p className="font-semibold">Build Model Setup from one sentence</p>
        <p className="mt-1.5 rounded-md bg-background px-2.5 py-2 text-xs italic text-text-2">“Set up a Braftovi US model, oncology brand in growth, with streams for NSCLC, CRC and melanoma by indication.”</p>
        {demo && (
          <ol className="mt-3 space-y-2">{steps.map((t, k) => {
            const st = demo.i > k || demo.done ? 'done' : demo.i === k ? 'doing' : 'todo'
            return <li key={t} className={cx('flex items-center gap-2 text-xs', st === 'todo' ? 'text-text-3' : 'text-text')}>
              {st === 'done' ? <CheckCircle2 size={14} className="shrink-0 text-ok" /> : st === 'doing' ? <Loader2 size={14} className="shrink-0 animate-spin text-[#7c3aed]" /> : <span className="h-3.5 w-3.5 shrink-0 rounded-full border border-border-strong" />}
              <span className={cx(st === 'doing' && 'agent-caret font-semibold')}>{t}</span>
            </li>
          })}</ol>
        )}
        <div className="mt-3 flex flex-wrap gap-2">
          {!demo && <Btn size="sm" icon={<Sparkles size={13} />} onClick={onRun}>Watch {ASSISTANT} build it</Btn>}
          {running && <Btn size="sm" variant="secondary" onClick={onStop}>Stop</Btn>}
          {demo?.done && <><Btn size="sm" onClick={onReview}>Review filled fields</Btn><Btn size="sm" variant="ghost" icon={<RotateCcw size={13} />} onClick={onRun}>Replay</Btn></>}
        </div>
        <p className="mt-2 text-[10px] text-text-3">Bounded to Model Setup. Later steps stay with you.</p>
      </div>
    </div>
  )
}

/** Generic replies for pages outside the configurator. */
const pageRespond = (where: string) => (q: string): Reply => /build|set ?up|create|new model|configure/i.test(q)
  ? { kind: 'text', title: 'Let’s build it in the configurator', body: `Start a new model from the library, then open me on Model Setup. Describe the model in one sentence and I’ll fill the fields while you watch.` }
  : { kind: 'text', title: `On ${where}`, body: 'I can explain what you see here, find models and point you to the right step. Field changes happen inside the configurator, where every change waits for your review.' }

function ReplyCard({ r, state, setState }: { r: Reply; state?: Msg['state']; setState: (s: Msg['state']) => void }) {
  const tag = (label: string, cls: string) => <span className={cx('mb-1.5 inline-block rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide', cls)}>{label}</span>
  return (
    <div className="mr-4 rounded-lg rounded-bl-sm border border-border p-3 text-sm">
      {r.kind === 'text' && <>
        {tag('Explanation', 'bg-surface-2 text-text-2')}
        <p className="font-semibold">{r.title}</p><div className="mt-1 text-text-2">{r.body}</div>
        {r.cites && <p className="mt-2 font-mono text-[10px] text-text-3">Sources: {r.cites.join(' · ')}</p>}
        {r.link && <button type="button" onClick={r.link.go} className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">{r.link.label}<ArrowRight size={12} /></button>}
      </>}
      {r.kind === 'list' && <>
        {tag('Audit', 'bg-surface-2 text-text-2')}
        <p className="font-semibold">{r.title}</p>
        {r.items.length === 0 ? <p className="mt-1 flex items-center gap-1.5 text-ok"><CheckCircle2 size={14} />{r.empty}</p> : (
          <ul className="mt-2 space-y-2">{r.items.map((it, k) => (
            <li key={k} className="flex gap-2 text-xs">
              {it.tone === 'err' ? <AlertCircle size={13} className="mt-px shrink-0 text-err" /> : it.tone === 'warn' ? <AlertTriangle size={13} className="mt-px shrink-0 text-warn" /> : <CheckCircle2 size={13} className="mt-px shrink-0 text-ok" />}
              <span className="flex-1 text-text-2">{it.text}{it.link && <button type="button" onClick={it.link.go} className="ml-1 font-semibold text-brand hover:underline">{it.link.label}</button>}</span>
            </li>))}</ul>
        )}
      </>}
      {r.kind === 'proposal' && <>
        {state === 'applied' ? tag('Applied', 'bg-ok-soft text-ok') : state === 'undone' ? tag('Reverted', 'bg-surface-2 text-text-2') : state === 'dismissed' ? tag('Dismissed', 'bg-surface-2 text-text-3') : tag('Proposed — not applied', 'bg-warn-soft text-warn')}
        <p className="font-semibold">{r.title}</p>
        <ul className="mt-2 space-y-1 text-xs text-text-2">{r.changes.map(c => <li key={c} className="flex gap-1.5"><Plus size={12} className="mt-0.5 shrink-0 text-brand" />{c}</li>)}</ul>
        {r.missing && r.missing.length > 0 && (
          <div className="mt-2 rounded-md bg-warn-soft/60 p-2">
            <p className="text-[11px] font-semibold text-warn">Still needed before you can continue</p>
            <ul className="mt-1 space-y-0.5 text-xs text-text-2">{r.missing.map(m => <li key={m} className="flex gap-1.5"><AlertCircle size={12} className="mt-0.5 shrink-0 text-warn" />{m}</li>)}</ul>
          </div>
        )}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {state === 'proposed' && <><Btn size="sm" onClick={() => { r.apply(); setState('applied') }}>Apply</Btn><Btn size="sm" variant="ghost" onClick={() => setState('dismissed')}>Dismiss</Btn></>}
          {state === 'applied' && <Btn size="sm" variant="secondary" icon={<History size={13} />} onClick={() => { r.undo(); setState('undone') }}>Undo</Btn>}
          {state === 'applied' && r.link && <button type="button" onClick={r.link.go} className="inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">{r.link.label}<ArrowRight size={12} /></button>}
        </div>
      </>}
      {r.kind === 'denied' && <>
        {tag('Not permitted', 'bg-err-soft text-err')}
        <p className="flex items-center gap-1.5 font-semibold"><ShieldAlert size={14} className="text-err" />{r.title}</p><p className="mt-1 text-text-2">{r.body}</p>
      </>}
    </div>
  )
}

/* ───────────────────────── Model library (home) ───────────────────────── */

const STATUS_TONE: Record<MStatus, 'ok' | 'neutral'> = { Draft: 'neutral', Published: 'ok' }

const modelName = (m: ModelRow) => m.name ?? `${m.brand} ${m.market} forecast`
type SortKey = 'name' | 'brand' | 'market' | 'arch' | 'version' | 'status' | 'updated'
const SORT_VAL: Record<SortKey, (m: ModelRow) => string> = {
  name: modelName, brand: m => m.brand, market: m => `${m.market} ${m.cycle}`, arch: m => m.inds.map(i => i.arch).join(' '),
  version: m => m.version, status: m => m.status, updated: m => m.updated,
}

function ModelsHome({ fixtures, models, setModels, onOpen, onResume, notify, ai, closeAI }: {
  fixtures: boolean; models: ModelRow[]; setModels: (m: ModelRow[]) => void; onOpen: (s: Seed) => void; onResume: (m: ModelRow) => void; notify: (t: Toast) => void; ai: boolean; closeAI: () => void
}) {
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'All' | 'Attention' | MStatus>('All')
  const [creating, setCreating] = useState(false)
  const [versions, setVersions] = useState<ModelRow | null>(null)
  const visible = models.filter(m => !m.restricted)
  const counts = {
    Attention: visible.filter(m => m.status === 'Draft' && m.issues > 0).length,
    Draft: visible.filter(m => m.status === 'Draft').length,
    Published: visible.filter(m => m.status === 'Published').length,
  }
  const match = (m: ModelRow) => filter === 'All' || (filter === 'Attention' ? m.status === 'Draft' && m.issues > 0 : m.status === filter)
  const [fBrand, setFBrand] = useState('All')
  const brandsAll = Array.from(new Set(visible.map(m => m.brand))).sort()
  const dim = (m: ModelRow) => fBrand === 'All' || m.brand === fBrand
  const anyFilter = filter !== 'All' || !!q || fBrand !== 'All'
  const clearAll = () => { setQ(''); setFilter('All'); setFBrand('All') }
  const [sort, setSort] = useState<{ k: SortKey; dir: 1 | -1 } | null>(null)
  const filtered = models.filter(m => (m.restricted ? !anyFilter : match(m) && dim(m)) && `${modelName(m)} ${m.brand} ${m.inds.map(i => `${i.name} ${i.arch}`).join(' ')} ${m.market} ${m.cycle}`.toLowerCase().includes(q.toLowerCase()))
  const rows = sort ? [...filtered].sort((a, b) => a.restricted !== b.restricted ? (a.restricted ? 1 : -1) : SORT_VAL[sort.k](a).localeCompare(SORT_VAL[sort.k](b), undefined, { numeric: true }) * sort.dir) : filtered
  const toggleSort = (k: SortKey) => setSort(s => s?.k === k ? (s.dir === 1 ? { k, dir: -1 } : null) : { k, dir: 1 })

  const respond = (t: string): Reply => {
    const s = t.toLowerCase()
    if (/stale|fresh|late|data/.test(s)) return { kind: 'list', title: 'Models running on non-current data', empty: 'All feeds are current.', items: visible.filter(m => m.fresh !== 'Current').map(m => ({ tone: 'warn' as const, text: `${m.brand} ${m.market} — ${m.fresh.toLowerCase()} data.`, link: { label: 'Open', go: () => onResume(m) } })) }
    if (/attention|today|todo|what should|priorit/.test(s)) return { kind: 'list', title: 'Needs you, most urgent first', empty: 'Nothing waiting on you.', items: visible.filter(m => m.status === 'Draft').sort((a, b) => b.issues - a.issues).map(m => ({ tone: m.issues > 0 ? 'warn' as const : 'ok' as const, text: `${m.brand} ${m.market} — draft, ${m.issues} item${m.issues === 1 ? '' : 's'} to fix (${m.cycle}).`, link: { label: 'Resume', go: () => onResume(m) } })) }
    if (RESTRICTED_RE.test(s) || /\bbd\b/.test(s)) return { kind: 'denied', title: 'That record is in a restricted partition', body: 'BD / Pipeline models are not visible from the CoE workspace, and I can’t read or summarise them. Request access from the BD lead.' }
    if (/patient-flow|archetype|which models|use/.test(s)) return { kind: 'text', title: 'Archetype usage across the library', body: <ul className="mt-1 space-y-0.5 text-xs">{ARCHETYPES.map(a => <li key={a.id}><b className="text-text">{a.name}</b> — {visible.filter(m => m.inds.some(i => i.arch === a.name)).map(m => m.brand).join(', ') || 'none yet'}</li>)}</ul> }
    return { kind: 'text', title: 'I can help with the model library', body: 'Ask what needs attention, which models are on stale data, or where an archetype is used. I can’t see restricted BD records.' }
  }

  return (
    <main className={cx('mx-auto w-full max-w-[1240px] flex-1 px-6 py-10 transition-[padding]', ai && 'xl:pr-[420px]')}>
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">Model library</h1>
          <p className="mt-1 text-text-2">Every brand model in one place, from draft to published.</p>
        </div>
        <Btn icon={<Plus size={16} />} className="shrink-0" onClick={() => setCreating(true)}>New model</Btn>
      </header>

      {visible.length === 0 ? (
        <div>
          <EmptyState icon={<Boxes size={20} />} title="No brand models yet" action={<Btn icon={<Plus size={16} />} onClick={() => setCreating(true)}>Configure your first model</Btn>}>
            Set up a brand, pick an archetype per indication and publish a version forecasters can use.
          </EmptyState>
        </div>
      ) : (
        <>
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {([['Attention', 'Needs you', 'Drafts with open items', AlertTriangle, 'warn'], ['Published', 'Live versions', 'In forecasters’ hands', CheckCircle2, 'ok']] as const).map(([k, l, d, Icon, tone]) => (
              <button type="button" key={k} aria-pressed={filter === k} onClick={() => setFilter(filter === k ? 'All' : k)}
                className={cx('flex items-start gap-3 rounded-lg border bg-surface p-4 text-left transition-colors', filter === k ? 'border-brand ring-1 ring-brand' : 'border-border hover:border-border-strong')}>
                <span className={cx('grid h-9 w-9 shrink-0 place-items-center rounded-md', tone === 'warn' && 'bg-warn-soft text-warn', tone === 'ok' && 'bg-ok-soft text-ok')}><Icon size={17} /></span>
                <span className="min-w-0"><span className="block font-mono text-2xl font-semibold leading-none">{counts[k]}</span><span className="mt-1 block text-[13px] font-semibold">{l}</span><span className="block text-xs text-text-3">{d}</span></span>
              </button>
            ))}
          </div>

          <div className="mt-6 flex flex-col gap-3">
            <div className="relative w-full max-w-sm">
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-text-2" />
              <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search models" className={cx(inputCls(), 'pl-9!')} />
            </div>
          </div>

          <div className="mt-3 overflow-x-auto rounded-lg border border-border bg-surface">
            {rows.length === 0 ? (
              <div className="p-10 text-center">
                <p className="font-semibold">No models match</p>
                <p className="mt-1 text-sm text-text-2">Try another search or clear the filter.</p>
                <Btn variant="secondary" size="sm" className="mt-4" onClick={clearAll}>Clear filters</Btn>
              </div>
            ) : (
              <table className="w-full min-w-[980px] text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-text-3">
                    {([['name', 'Model name'], ['brand', 'Brand & indications'], ['market', 'Market · cycle'], ['arch', 'Archetype'], ['version', 'Version'], ['status', 'Status'], ['updated', 'Updated']] as const).map(([k, h]) => {
                      const on = sort?.k === k
                      const Icon = !on ? ArrowUpDown : sort.dir === 1 ? ArrowUp : ArrowDown
                      return (
                        <th key={k} className="px-4 py-3 font-semibold" aria-sort={on ? (sort.dir === 1 ? 'ascending' : 'descending') : 'none'}>
                          <button type="button" onClick={() => toggleSort(k)} className={cx('inline-flex items-center gap-1 uppercase tracking-wide outline-none hover:text-text focus-visible:text-brand', on && 'text-text')}>
                            {h}<Icon size={12} className={on ? 'text-brand' : 'opacity-60'} />
                          </button>
                        </th>
                      )
                    })}
                    <th className="px-4 py-3"><span className="sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(m => m.restricted ? (
                    <tr key={m.id} className="border-b border-border bg-background/60 text-text-3 last:border-0">
                      <td className="px-4 py-3.5" colSpan={7}><p className="flex items-center gap-2 font-semibold"><Lock size={14} />{m.brand}</p><p className="text-xs">BD / Pipeline partition — details hidden. Request access from the BD lead.</p></td>
                      <td className="px-4 py-3.5 text-right"><Btn variant="ghost" size="sm" onClick={() => notify({ tone: 'info', text: 'Access request sent to the BD lead.' })}>Request access</Btn></td>
                    </tr>
                  ) : (
                    <tr key={m.id} className="border-b border-border align-top last:border-0 hover:bg-background">
                      <td className="px-4 py-3.5 font-semibold">{modelName(m)}</td>
                      <td className="px-4 py-3.5"><p className="font-medium">{m.brand}</p><p className="text-xs text-text-2">{m.inds.map(i => i.name).join(' · ')}</p>{m.tag && <span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-warn-soft px-2 py-0.5 text-[11px] font-semibold text-warn"><AlertTriangle size={11} />{m.tag}</span>}</td>
                      <td className="px-4 py-3.5"><p>{m.market}</p><p className="text-xs text-text-2">{m.cycle}</p></td>
                      <td className="px-4 py-3.5 text-[13px]">{Array.from(new Set(m.inds.map(i => i.arch).filter(Boolean))).join(' + ') || <span className="text-text-3">Not chosen</span>}</td>
                      <td className="px-4 py-3.5 font-mono text-xs">{m.version}</td>
                      <td className="px-4 py-3.5"><Badge tone={STATUS_TONE[m.status]}>{m.status}</Badge>{m.issues > 0 && <p className="mt-1 text-xs text-err">{m.issues} to fix{m.step ? ` · step ${m.step}/${LAST}` : ''}</p>}</td>
                      <td className="px-4 py-3.5 text-xs text-text-2">{m.updated}<br />{m.by}</td>
                      <td className="whitespace-nowrap px-4 py-3.5 text-right">
                        <div className="flex justify-end gap-1">
                          {m.versions.length > 0 && <Btn variant="ghost" size="sm" icon={<History size={14} />} onClick={() => setVersions(m)} title="Versions & audit"><span className="sr-only">Versions</span></Btn>}
                          {m.fx
                            ? <Btn size="sm" onClick={() => onOpen({ from: m })}>Open</Btn>
                            : m.status === 'Published'
                            ? <>{m.status === 'Published' && <Btn size="sm" onClick={() => notify({ tone: 'info', text: `Forecast creation for ${m.brand} ${m.version} is a forecaster workflow — not built in this prototype yet.` })}>Start forecast</Btn>}<Btn variant="secondary" size="sm" onClick={() => setVersions(m)}>View</Btn></>
                            : <Btn size="sm" onClick={() => onResume(m)}>Resume</Btn>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

        </>
      )}

      {creating && <NewModelDialog models={visible.filter(m => m.status === 'Published')} onClose={() => setCreating(false)} onStart={s => { setCreating(false); onOpen(s) }} />}
      {versions && <VersionsDrawer m={versions} onClose={() => setVersions(null)} onNew={() => { setVersions(null); onOpen({ from: versions }) }} />}
      <Charles greeting={`Hi ${ME.split(' ')[0]}, I’m ${ASSISTANT}. Ask about your models, or start a new one and I’ll help set it up.`} context={['CoE workspace', 'Model library', `${visible.length} models`]} chips={['What needs my attention?', 'Which models have stale data?', 'Where is Patient-Flow used?']} respond={respond} />
    </main>
  )
}

const IMPORT_NAME = 'Braftovi US model'
const IMPORT_SHEETS = [{ sheet: 'Forecast_NSCLC', name: 'NSCLC (BRAF V600E)' }, { sheet: 'Forecast_CRC', name: 'CRC (BRAF V600E)' }, { sheet: 'Forecast_Melanoma', name: 'Melanoma (BRAF V600)' }]
const IMPORT_INPUTS = [
  { table: 'Inputs_Epi', match: 'Incidence / prevalence & filter rates' },
  { table: 'Inputs_Persistency', match: 'Cohort-by-month persistency' },
  { table: 'Inputs_Price_FX', match: 'Local-currency price & FX' },
  { table: 'Inputs_GTN', match: 'Discount & rebate factors' },
  { table: 'Inputs_KOL_notes', match: '' },
]

function NewModelDialog({ models, onClose, onStart }: { models: ModelRow[]; onClose: () => void; onStart: (s: Seed) => void }) {
  const [mode, setMode] = useState<'blank' | 'copy' | 'import'>('copy')
  const [file, setFile] = useState('')
  const [parsing, setParsing] = useState(false)
  const [from, setFrom] = useState(models[0]?.id ?? '')
  const [step, setStep] = useState(0)
  const [checks, setChecks] = useState(0)
  const [map, setMap] = useState(IMPORT_SHEETS.map(x => ({ ...x, include: true })))
  const [inMap, setInMap] = useState(IMPORT_INPUTS.map(x => x.match))
  const pickFile = (name: string) => { setFile(name); setParsing(true); setStep(1); setChecks(0); [1, 2, 3, 4].forEach(k => setTimeout(() => { setChecks(k); if (k === 4) setParsing(false) }, k * 450)) }
  const streams = map.filter(x => x.include)
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  const src = models.find(m => m.id === from)
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-brand-dark/50 p-4" role="dialog" aria-modal="true" aria-labelledby="new-title" onClick={onClose}>
      <div className="rise flex max-h-[92dvh] w-full max-w-2xl flex-col rounded-lg bg-surface shadow-xl" onClick={e => e.stopPropagation()}>
        <header className="flex items-start justify-between gap-4 border-b border-border px-6 py-5">
          <div><h2 id="new-title" className="text-lg font-semibold">New brand model</h2>
            <p className="mt-1 text-sm text-text-2">Choose a starting point. Every path uses the same nine steps.</p></div>
          <button type="button" aria-label="Close" onClick={onClose} className="rounded p-1 text-text-3 hover:bg-surface-2 hover:text-text"><X size={16} /></button>
        </header>
        <div className="flex-1 space-y-5 overflow-y-auto px-6 py-5">
        <div className="grid gap-3 sm:grid-cols-3">
          {([['copy', 'Use a template', 'Copy a published model', Copy], ['blank', 'Start from scratch', 'Blank configuration', Plus], ['import', 'Import a model', 'Upload a supported .xlsx', Upload]] as const).map(([id, t, d, Icon]) => (
            <button type="button" key={id} aria-pressed={mode === id} disabled={id === 'copy' && !models.length} onClick={() => setMode(id)}
              className={cx('flex h-full items-start gap-3 rounded-md border p-3.5 text-left transition-colors disabled:opacity-40', mode === id ? 'border-brand bg-brand-soft/50 ring-1 ring-brand' : 'border-border-strong hover:border-text')}>
              <span className={cx('grid h-8 w-8 shrink-0 place-items-center rounded-md', mode === id ? 'bg-brand text-white' : 'bg-surface-2 text-brand')}><Icon size={15} /></span>
              <span className="min-w-0"><span className="block whitespace-nowrap text-[13px] font-semibold">{t}</span><span className="mt-0.5 block text-xs text-text-2">{d}</span></span>
            </button>
          ))}
        </div>
        {mode === 'blank' && <p className="rounded-md bg-surface-2 px-3.5 py-3 text-[13px] text-text-2">You’ll pick the archetype, modules and data bindings yourself in the steps that follow.</p>}
        {mode === 'copy' && models.length > 0 && (
          <div>
            <Field label="Template" hint={src ? `${src.inds.length} indication${src.inds.length > 1 ? 's' : ''} · ${Array.from(new Set(src.inds.map(i => i.arch))).join(' + ')} · ${src.version}` : undefined}>
              <select className={inputCls()} value={from} onChange={e => setFrom(e.target.value)}>
                {models.map(m => <option key={m.id} value={m.id}>{m.brand} {m.market} · {m.version}</option>)}
              </select>
            </Field>
          </div>
        )}
        {mode === 'import' && (
          <div>
            <ol className="mb-4 flex items-center gap-1 text-[11px] font-semibold">
              {['Upload', 'Validate format', 'Map to model', 'Review'].map((t, k) => (
                <li key={t} className="flex flex-1 items-center gap-1.5">
                  <button type="button" disabled={k > step || (k > 0 && !file)} onClick={() => setStep(k)} className={cx('flex items-center gap-1.5 disabled:cursor-default', k <= step ? 'text-brand' : 'text-text-3')}>
                    <span className={cx('grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px]', k < step ? 'bg-brand text-white' : k === step ? 'border-2 border-brand' : 'border border-border-strong')}>{k < step ? <Check size={11} /> : k + 1}</span>
                    <span className="hidden sm:inline">{t}</span>
                  </button>
                  {k < 3 && <span className={cx('h-px flex-1', k < step ? 'bg-brand' : 'bg-border')} />}
                </li>
              ))}
            </ol>

            {step === 0 && <>
              <label className="flex cursor-pointer flex-col items-center rounded-md border border-dashed border-border-strong px-4 py-6 text-center hover:border-brand">
                <Upload size={18} className="text-text-2" />
                <span className="mt-2 text-sm font-semibold">Choose an .xlsx file</span>
                <span className="text-xs text-text-3">Use a workbook exported from this platform or the standard import template.</span>
                <input type="file" accept=".xlsx" className="sr-only" onChange={e => { const f = e.target.files?.[0]; if (f) pickFile(f.name) }} />
              </label>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
                <button type="button" onClick={() => pickFile('Braftovi_US_OP2027_export.xlsx')} className="font-semibold text-brand hover:underline">Try with a sample export</button>
                <button type="button" onClick={() => {}} className="inline-flex items-center gap-1 text-text-2 hover:text-text"><FileText size={12} />Download import template</button>
              </div>
            </>}

            {step === 1 && (
              <div className="rounded-md border border-border p-4">
                <p className="flex items-center gap-2 text-sm font-semibold"><FileText size={15} className="text-text-2" />{file}</p>
                <ul className="mt-3 space-y-2 text-[13px]">
                  {['File type is .xlsx and opens without errors', 'Platform export signature found (template v3.2)', `${IMPORT_SHEETS.length} forecast sheets and ${IMPORT_INPUTS.length} input tables detected`, 'No macros or external links. Formulas are not imported; the governed engine recalculates'].map((t, k) => (
                    <li key={t} className={cx('flex gap-2', checks > k ? 'text-text' : 'text-text-3')}>{checks > k ? <CheckCircle2 size={15} className="mt-px shrink-0 text-ok" /> : checks === k ? <Loader2 size={15} className="mt-px shrink-0 animate-spin text-brand" /> : <span className="mt-px h-[15px] w-[15px] shrink-0 rounded-full border border-border-strong" />}{t}</li>
                  ))}
                </ul>
                {!parsing && <div className="mt-3"><Banner tone="ok" title="Format recognised">The workbook matches the supported structure. Next, confirm how sheets map to revenue streams.</Banner></div>}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-text-2">Sheets → revenue streams</p>
                  <ul className="divide-y divide-border rounded-md border border-border">
                    {map.map((x, k) => (
                      <li key={x.sheet} className="flex flex-wrap items-center gap-2 px-3 py-2">
                        <input type="checkbox" aria-label={`Include ${x.sheet}`} className="h-4 w-4 accent-brand" checked={x.include} onChange={e => setMap(m => m.map((y, j) => j === k ? { ...y, include: e.target.checked } : y))} />
                        <span className="w-32 shrink-0 truncate font-mono text-xs text-text-2">{x.sheet}</span>
                        <ArrowRight size={13} className="shrink-0 text-text-3" />
                        <input aria-label={`Stream name for ${x.sheet}`} disabled={!x.include} className={cx(inputCls(), 'h-8! min-w-[140px] flex-1 text-[13px] disabled:opacity-50')} value={x.name} onChange={e => setMap(m => m.map((y, j) => j === k ? { ...y, name: e.target.value } : y))} />
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-text-2">Input tables → data inputs</p>
                  <ul className="divide-y divide-border rounded-md border border-border">
                    {IMPORT_INPUTS.map((x, k) => (
                      <li key={x.table} className="flex flex-wrap items-center gap-2 px-3 py-2 text-[13px]">
                        <span className="w-40 shrink-0 truncate font-mono text-xs text-text-2">{x.table}</span>
                        <ArrowRight size={13} className="shrink-0 text-text-3" />
                        <select aria-label={`Map ${x.table}`} className={cx(inputCls(!inMap[k]), 'h-8! min-w-[160px] flex-1 text-[13px]')} value={inMap[k]} onChange={e => setInMap(m => m.map((v, j) => j === k ? e.target.value : v))}>
                          <option value="">Not mapped — skip</option>{[...Object.values(MODULE_INPUTS).map(i => i.name), 'Treated patient pool'].map(o => <option key={o}>{o}</option>)}
                        </select>
                        {inMap[k] ? <CheckCircle2 size={14} className="shrink-0 text-ok" /> : <AlertTriangle size={14} className="shrink-0 text-warn" />}
                      </li>
                    ))}
                  </ul>
                  {inMap.some(v => !v) && <p className="mt-1.5 text-xs text-warn">{inMap.filter(v => !v).length} table{inMap.filter(v => !v).length > 1 ? 's' : ''} not mapped. They’ll be skipped; you can bind data in step 5.</p>}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="rounded-md border border-border p-3"><p className="text-[11px] font-bold uppercase tracking-wider text-ok">Pre-filled from the file</p>
                  <ul className="mt-2 space-y-1 text-[13px]"><li>Model name: <b>{IMPORT_NAME}</b></li><li>{streams.length} revenue stream{streams.length === 1 ? '' : 's'}: {streams.map(x => x.name).join(', ')}</li><li>{inMap.filter(Boolean).length} data inputs mapped</li><li>Assumption values as starting points</li></ul></div>
                <div className="rounded-md border border-border p-3"><p className="text-[11px] font-bold uppercase tracking-wider text-warn">You still decide</p>
                  <ul className="mt-2 space-y-1 text-[13px]"><li>Archetype per stream (step 2)</li><li>Modes and modules (steps 3–4)</li><li>Locks, bands and owners (step 6)</li><li>Geography and cycle (Publish)</li></ul></div>
              </div>
            )}
            <div className="mt-3 rounded-md border border-dashed border-warn/50 bg-warn/5 px-3 py-2 text-xs text-text-2"><b className="text-text">Proposed flow, to validate with the client:</b> supported structure, which fields auto-populate, and error handling. Arbitrary workbooks are not supported.</div>
          </div>
        )}
        </div>
        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-6 py-4">
        <p className="min-w-0 flex-1 text-xs text-text-3">Lineage recorded: {mode === 'copy' && src ? `template ${src.brand} ${src.version}` : mode === 'import' ? (file ? `imported from ${file}` : 'imported file') : 'created from scratch'}. Geography and cycle are assigned at Publish.</p>
        <div className="flex shrink-0 gap-2">
          <Btn variant="secondary" onClick={onClose}>Cancel</Btn>
          {mode === 'import' && step > 0 && <Btn variant="ghost" onClick={() => setStep(s => s - 1)}>Back</Btn>}
          {mode === 'import' && step < 3
            ? <Btn disabled={!file || parsing || (step === 2 && !streams.length)} onClick={() => setStep(s => s + 1)} icon={<ArrowRight size={16} />}>{step === 0 ? 'Upload' : step === 1 ? 'Map to model' : 'Review'}</Btn>
            : <Btn onClick={() => onStart(mode === 'copy' && src ? { from: src, copy: true } : mode === 'import' ? { importFile: file, importStreams: streams.map(x => x.name) } : { blank: true })} icon={<ArrowRight size={16} />}>Start configuring</Btn>}
        </div>
        </footer>
      </div>
    </div>
  )
}

function VersionsDrawer({ m, onClose, onNew }: { m: ModelRow; onClose: () => void; onNew: () => void }) {
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  const audit = [
    ...m.versions.map(v => ({ t: `${v.by} published ${v.v}`, d: v.date })),
    { t: `${m.by} last changed configuration`, d: m.updated },
    { t: 'IQVIA LAAD claims refreshed · actuals through Aug 2026', d: 'Oct 3' },
  ]
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-brand-dark/40" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label="Versions and audit" onClick={e => e.stopPropagation()} className="rise flex h-full w-full max-w-md flex-col bg-surface shadow-2xl">
        <header className="flex items-start justify-between border-b border-border px-5 py-4">
          <div><p className="font-mono text-[11px] uppercase tracking-widest text-text-3">Versions & audit</p><p className="font-semibold">{m.brand} {m.market}</p><p className="text-xs text-text-2">{m.inds.map(i => `${i.name} · ${i.arch}`).join(' / ')}</p></div>
          <Btn variant="ghost" size="sm" onClick={onClose} icon={<X size={16} />}><span className="sr-only">Close</span></Btn>
        </header>
        <div className="flex-1 overflow-y-auto p-5">
          {m.diff && m.diff.length > 0 && (
            <div className="mb-5 rounded-md border border-brand/30 bg-brand-soft/40 p-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-brand">Draft {m.version} vs live {m.versions[0]?.v}</p>
              <ul className="mt-2 space-y-1.5">
                {m.diff.map(d => (
                  <li key={d.text} className="flex items-start gap-2 text-[13px]">
                    <span className={cx('grid h-5 w-5 shrink-0 place-items-center rounded font-mono text-xs font-bold', d.kind === '+' ? 'bg-ok-soft text-ok' : d.kind === '−' ? 'bg-err-soft text-err' : 'bg-warn-soft text-warn')}>{d.kind}</span>{d.text}
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-text-2">Forecasters pinned to {m.versions[0]?.v} are offered a rebase with this diff when it publishes.</p>
            </div>
          )}
          <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-text-3">Published versions · read-only</p>
          <ol className="mt-3 space-y-2">
            {m.versions.map((v, k) => (
              <li key={v.v} className="rounded-md border border-border p-3">
                <div className="flex items-center justify-between"><span className="flex items-center gap-2 font-mono text-sm font-semibold">{v.v}{k === 0 && <Badge tone="ok">Live</Badge>}</span><span className="text-xs text-text-3">{v.date} · {v.by}</span></div>
                <p className="mt-1 text-[13px] text-text-2">{v.note}</p>
                <p className="mt-1 flex items-center gap-1 text-xs text-text-3"><Lock size={11} />{v.scenarios} scenarios pinned to this version</p>
              </li>
            ))}
          </ol>
          <p className="mt-6 text-xs font-semibold uppercase tracking-wide text-text-3">Audit trail</p>
          <ol className="mt-3 space-y-2 border-l border-border pl-4">
            {audit.map(a => <li key={a.t} className="text-[13px]"><p>{a.t}</p><p className="text-xs text-text-3">{a.d}</p></li>)}
          </ol>
        </div>
        <footer className="border-t border-border p-4">
          <Btn className="w-full" icon={<GitBranch size={16} />} onClick={onNew}>Start {nextVersion(m.versions[0]?.v ?? m.version)} draft</Btn>
          <p className="mt-2 text-center text-xs text-text-3">Published versions never change. A new draft leaves existing scenarios untouched.</p>
        </footer>
      </aside>
    </div>
  )
}

/* ───────────────────────── Configurator shell ───────────────────────── */

type Ctx = {
  c: Config; ind: Ind; update: (p: Partial<Config>) => void; updInd: (id: string, p: Partial<Ind>) => void
  setArch: (id: string, a: ArchId) => void; notify: (t: Toast) => void; go: (n: number) => void
  /** "Fix for me": applies Charles's safe fixes for the given steps. */
  fix: (stages: number[]) => void
}

function Configurator({ seed, onExit, notify, onPublished, ai, closeAI }: {
  seed: Seed; onExit: () => void; notify: (t: Toast) => void; onPublished: (c: Config) => void; ai: boolean; closeAI: () => void
}) {
  const [c, setC] = useState<Config>(() => freshConfig(seed))
  const [stage, setStage] = useState(1)
  const [visited, setVisited] = useState<Set<number>>(new Set([1]))
  const [attempted, setAttempted] = useState<Set<number>>(new Set())
  const [saving, setSaving] = useState<'saved' | 'saving'>('saved')
  const [published, setPublished] = useState<string | null>(null)
  const first = useRef(true)
  const [asked, setAsked] = useState(false)
  const [overriding, setOverriding] = useState(false)
  const [reason, setReason] = useState('')
  const [assist, setAssist] = useState(false)
  const [fixNote, setFixNote] = useState<{ before: Config; changes: string[]; left: string[] } | null>(null)
  const readOnly = !!c.lockedBy || (c.frozen && !c.override)

  // Every edit is recorded (what · who · when); repeated edits to the same thing collapse into one entry.
  const stamp = () => new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
  const logged = (prev: Config, what: string) => prev.log[0]?.what === what ? prev.log : [{ what, who: ME, when: `Today, ${stamp()}` }, ...prev.log].slice(0, 80)
  const update = (p: Partial<Config>) => setC(prev => {
    const keys = Object.keys(p).filter(k => FIELD_LABEL[k])
    const n = { ...prev, ...p }
    return keys.length && !('log' in p) ? { ...n, log: logged(prev, `Changed ${keys.map(k => FIELD_LABEL[k]).join(', ')}`) } : n
  })
  const updInd = (id: string, p: Partial<Ind>) => setC(prev => {
    const i0 = prev.inds.find(i => i.id === id)
    const keys = Object.keys(p).filter(k => FIELD_LABEL[k])
    const n = { ...prev, inds: prev.inds.map(i => i.id === id ? { ...i, ...p } : i) }
    return keys.length ? { ...n, log: logged(prev, `${i0?.name || 'Stream'}: changed ${keys.map(k => FIELD_LABEL[k]).join(', ')}`) } : n
  })
  const setArch = (id: string, a: ArchId) => setC(prev => ({
    ...prev, inds: prev.inds.map(i => i.id === id ? initInd(i, a) : i),
    bindings: Object.fromEntries(Object.entries(prev.bindings).filter(([k]) => !k.startsWith(`${id}:`))),
  }))
  const ind = c.inds.find(i => i.id === c.active) ?? c.inds[0]
  const [sharing, setSharing] = useState(false)
  const [history, setHistory] = useState(false)
  const [agent, setAgent] = useState<AgentState>({ section: null, field: null })
  const [demo, setDemo] = useState<{ i: number; done: boolean } | null>(null)
  const demoId = useRef(0)
  useEffect(() => () => { demoId.current++ }, [])
  const DEMO_STEPS = ['Read the description', 'Model name and brand', 'Asset type, therapy area, lifecycle', 'Revenue streams: NSCLC, CRC, Melanoma', 'Hand back for review']
  /** Scripted agent run: types each Model Setup field in turn so the user can watch the workflow populate. */
  const runDemo = async () => {
    const id = ++demoId.current
    const wait = (ms: number) => new Promise<void>((ok, no) => setTimeout(() => demoId.current === id ? ok() : no(new Error('cancelled')), ms))
    const focus = (f: string) => { setAgent(a => ({ ...a, field: f })); setTimeout(() => document.querySelector(`[data-agent="${f}"]`)?.scrollIntoView({ block: 'center', behavior: 'smooth' }), 50) }
    const type = async (f: string, text: string, put: (v: string) => Partial<Config>) => { focus(f); for (let k = 1; k <= text.length; k++) { setC(p => ({ ...p, ...put(text.slice(0, k)) })); await wait(45) } await wait(250) }
    const pick = async (f: string, p: Partial<Config>) => { focus(f); await wait(500); setC(x => ({ ...x, ...p })); await wait(400) }
    try {
      if (stage !== 1) go(1)
      if (window.innerWidth < 1024) setAssist(false)
      setDemo({ i: 0, done: false }); setAgent({ section: null, field: null })
      await wait(900)
      setDemo({ i: 1, done: false }); setAgent({ section: 'subject', field: null })
      await type('brand', 'Braftovi US model', v => ({ brand: v }))
      await type('asset', 'Braftovi', v => ({ asset: v }))
      setDemo({ i: 2, done: false })
      await pick('subjectType', { subjectType: 'Brand / Asset' })
      await pick('therapyArea', { therapyArea: 'Oncology' })
      await pick('lifecycle', { lifecycle: 'Growth' })
      setDemo({ i: 3, done: false }); setAgent({ section: 'streams', field: null })
      const ids = ['d1', 'd2', 'd3'].map(x => `i${Date.now()}${x}`)
      setC(p => ({ ...p, inds: ids.map(i => ({ ...emptyInd(i, ''), dim: 'Indication' })), active: ids[0] }))
      await wait(400)
      const names = ['NSCLC (BRAF V600E)', 'CRC (BRAF V600E)', 'Melanoma (BRAF V600)']
      for (let k = 0; k < 3; k++) {
        focus(`stream-${k}`)
        for (let j = 1; j <= names[k].length; j++) { const v = names[k].slice(0, j); setC(p => ({ ...p, inds: p.inds.map(i => i.id === ids[k] ? { ...i, name: v } : i) })); await wait(40) }
        await wait(250)
      }
      setDemo({ i: 4, done: false }); setAgent({ section: null, field: null })
      await wait(600)
      setC(p => ({ ...p, aiFields: ['brand', 'asset', 'subjectType', 'therapyArea', 'lifecycle', 'inds'], log: logged(p, `${ASSISTANT} filled Model Setup: Braftovi, oncology, 3 streams`) }))
      setDemo({ i: 5, done: true })
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch { setAgent({ section: null, field: null }) }
  }
  const demoBusy = !!demo && !demo.done

  useEffect(() => {
    if (first.current) { first.current = false; return }
    setSaving('saving'); const t = setTimeout(() => setSaving('saved'), 700); return () => clearTimeout(t)
  }, [c])

  // Platform binds governed sources as inputs appear, so Bind Data is a review step.
  useEffect(() => {
    if (!inputsFor(c).some(b => c.bindings[b.key]?.status !== 'ok')) return
    setC(prev => ({ ...prev, bindings: { ...prev.bindings, ...Object.fromEntries(inputsFor(prev).filter(b => prev.bindings[b.key]?.status !== 'ok').map(b => [b.key, autoBinding(b, prev.bindings[b.key])])) } }))
  }, [c])
  const issues = useMemo(() => STAGES.map(s => validate(s.id, c)), [c])
  const warns = useMemo(() => warningsFor(c), [c])
  const blocking = STAGES.slice(0, LAST - 1).filter(s => issues[s.id - 1].length)
  const status = (id: number): 'done' | 'error' | 'current' | 'todo' => {
    const bad = issues[id - 1].length > 0
    if (id === stage) return attempted.has(id) && bad ? 'error' : 'current'
    if (id === LAST) return visited.has(LAST) ? (blocking.length ? 'error' : 'done') : 'todo'
    if (visited.has(id) && !bad && id < LAST) return 'done'
    if ((attempted.has(id) || (visited.has(id) && id < stage)) && bad) return 'error'
    return 'todo'
  }
  const doneCount = STAGES.filter(s => s.id < LAST && status(s.id) === 'done').length
  const firstOpen = STAGES.find(s => s.id < LAST && issues[s.id - 1].length)?.id ?? LAST
  const canGo = (id: number) => id <= stage || visited.has(id) || id <= firstOpen

  const go = (id: number) => { setFixNote(null); setStage(id); setVisited(v => new Set(v).add(id)); window.scrollTo({ top: 0 }) }
  const next = () => {
    if (stage >= LAST) return
    setAttempted(a => new Set(a).add(stage))
    if (issues[stage - 1].length) { notify({ tone: 'err', text: 'Fix the highlighted items to continue.' }); return }
    go(stage + 1)
  }
  const nextRef = useRef(next); nextRef.current = next
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); nextRef.current() } }
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h)
  }, [])

  const show = attempted.has(stage)
  const S = STAGES[stage - 1]
  const fix = (stages: number[]) => {
    const r = autoFixAll(stages, c)
    setFixNote({ before: c, changes: r.changes, left: r.left })
    if (r.changes.length) { setC(r.c); notify({ tone: 'ok', text: `${ASSISTANT} fixed ${r.changes.length} item${r.changes.length > 1 ? 's' : ''}. Review the summary at the top.` }) }
    else notify({ tone: 'info', text: 'Nothing here can be fixed automatically — it needs your decision.' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  const ctx: Ctx = { c, ind, update, updInd, setArch, notify, go, fix }
  const ins = inputsFor(c)
  const okData = ins.filter(b => resolved(c.bindings[b.key])).length
  const stale = ins.filter(b => c.bindings[b.key]?.fresh && c.bindings[b.key]!.fresh!.state !== 'Current').length
  const archName = (i: Ind) => ARCHETYPES.find(a => a.id === i.arch)?.name

  /* assistant: explains, audits, diagnoses and proposes — never calculates */
  const respond = (t: string): Reply => {
    const s = t.toLowerCase()
    if (/formula|math|equation|edit the engine|change the engine|hazard function/.test(s)) return { kind: 'denied', title: 'Engine math is locked', body: 'No one edits engine math inside a model — including me. Raise a version request with the platform team; it ships as a new certified engine version.' }
    if (/\b(publish (it|now|for me|the model)|auto.?publish)\b/.test(s)) return { kind: 'denied', title: 'Publishing is yours to do', body: 'I can audit the model before you publish, but publishing and assigning forecasters always needs your explicit action in the Publish step.' }
    if (/unlock|change (a |the )?locked|edit (a |the )?locked|override (a |the )?locked/.test(s)) return { kind: 'denied', title: 'CoE-locked assumptions stay locked', body: 'I can fill missing owner, source or confidence, but I never change a CoE-locked value or its lock. Change it yourself in the Assumptions register.' }
    if (/this step|explain (the )?step|what do i do|where am i|what (is|are) (this|modes|modules|archetypes?|the baseline)/.test(s)) return { kind: 'text', title: `Step ${stage} · ${S.title}`, body: S.desc }
    if (RESTRICTED_RE.test(s)) return { kind: 'denied', title: 'That record is in a restricted partition', body: 'Insider-restricted BD models are invisible to the CoE workspace. I can’t read, compare or summarise them.' }
    if (/100|over.*share|share.*over|cascade/.test(s)) return c.cascade.length
      ? { kind: 'text', title: `Cascade multiplies to ${cascadeTotal(c).toFixed(0)}%`, body: `The levels ${c.cascade.join('% × ')}% are nested, so the last one is a share of the previous — a value above 100% at any level pushes the total past 100%. Lower that level or switch it to a parent-relative share.`, link: { label: 'Go to Modes', go: () => go(3) } }
      : { kind: 'text', title: 'No nested cascade on this model', body: 'Share can only exceed 100% when cascade levels are nested. This model uses a single share band.' }
    if (/migrat|certified|retired/.test(s) && c.retired) {
      const before = c.inds
      return { kind: 'proposal', title: 'Migrate D-04 v1.4 → Patient-Flow D-03 v4.1', changes: ['Archetype: Brand Inflow-Outflow → Patient-Flow', 'Modules reset to D-03 recommendations', 'Data bindings for D-04 inputs cleared'], apply: () => { before.forEach(i => i.arch === 'D-04' && setArch(i.id, 'D-03')); update({ retired: false }) }, undo: () => update({ inds: before, retired: true }) }
    }
    if (/publish|audit|ready|check|missing/.test(s)) {
      const items = [
        ...STAGES.slice(0, LAST - 1).flatMap(st => issues[st.id - 1].map(i => ({ tone: 'err' as const, text: i.msg, link: { label: `Go to ${st.short}`, go: () => go(st.id) } }))),
        ...issues[LAST - 1].map(i => ({ tone: 'err' as const, text: i.msg, link: { label: 'Go to Publish', go: () => go(LAST) } })),
        ...warns.map(w => ({ tone: 'warn' as const, text: w.msg, link: { label: 'Review', go: () => go(w.stage) } })),
      ]
      return { kind: 'list', title: `Pre-publish audit · ${items.filter(i => i.tone === 'err').length} blocking, ${warns.length} to review`, empty: 'Nothing blocking. Ready to publish.', items }
    }
    if (/data|fail|stale|fresh|komodo|feed|source/.test(s)) {
      const items = ins.flatMap((b): { tone: 'err' | 'warn'; text: string; link: { label: string; go: () => void } }[] => {
        const x = c.bindings[b.key]
        if (!x?.source) return [{ tone: 'err' as const, text: `${b.input.name} has no source. Suggested: ${b.input.suggested}.`, link: { label: 'Bind', go: () => go(5) } }]
        if (x.status === 'error' && !resolved(x)) return [{ tone: 'err' as const, text: `${b.input.name}: ${x.msg}`, link: { label: 'Fix', go: () => go(5) } }]
        if (x.fresh && x.fresh.state !== 'Current') return [{ tone: 'warn' as const, text: `${b.input.name} is ${x.fresh.state.toLowerCase()} — actuals through ${x.fresh.boundary}.`, link: { label: 'Review', go: () => go(5) } }]
        return []
      })
      return { kind: 'list', title: 'Data diagnostic', empty: ins.length ? 'Every input is bound and current.' : 'No inputs yet — choose archetypes first.', items }
    }
    if (/recommend|attach|module|set up/.test(s)) {
      if (!ind.arch) return { kind: 'text', title: 'Choose an archetype first', body: `Modules depend on the archetype for ${ind.name || 'this indication'}.`, link: { label: 'Go to Archetypes', go: () => go(2) } }
      const miss = MODULES.filter(m => m.rec?.includes(ind.arch!) && !ind.modules.includes(m.id) && validFor(m, ind.arch!))
      if (!miss.length) return { kind: 'text', title: 'All default modules are attached', body: `${ind.name} already has every taxonomy default for ${archName(ind)}.` }
      const before = ind.modules, id = ind.id
      return { kind: 'proposal', title: `Attach ${miss.length} taxonomy default module${miss.length > 1 ? 's' : ''} to ${ind.name}`, changes: miss.map(m => `${m.name} (${m.cat})`), apply: () => updInd(id, { modules: [...before, ...miss.map(m => m.id)] }), undo: () => updInd(id, { modules: before }) }
    }
    if (/owner|metadata|confidence|assumption|fill/.test(s)) {
      const id = ind.id, before = ind.perms
      const gaps = Object.entries(before).filter(([, p]) => missingMeta(p))
      if (!gaps.length) return { kind: 'text', title: 'Open assumptions are documented', body: 'Every open assumption has an owner, source and confidence.' }
      return { kind: 'proposal', title: `Fill metadata on ${gaps.length} open assumption${gaps.length > 1 ? 's' : ''}`, changes: gaps.map(([k]) => `${assumptionsFor(ind.arch).find(a => a.id === k)?.name}: Brand forecaster · ${ASSUMPTION_SOURCES[0]} · Medium`), apply: () => updInd(id, { perms: Object.fromEntries(Object.entries(before).map(([k, p]) => [k, missingMeta(p) ? { ...p, owner: p.owner || ASSUMPTION_OWNERS[0], source: p.source || ASSUMPTION_SOURCES[0], confidence: p.confidence || 'Medium' } : p])) }), undo: () => updInd(id, { perms: before }) }
    }
    if (/archetype|which|fit|compare|engine/.test(s)) {
      // Explains the catalogue only: no archetype recommendation until validated logic and history exist.
      return { kind: 'text', title: 'How the archetypes differ', body: <><ul className="space-y-1">{ARCH_GRID.map(a => <li key={a.id}><b className="text-text">{a.name}</b> — {ARCH_DETAIL[a.id].question}</li>)}</ul><span className="mt-2 block text-xs">Pick the one whose question matches the stream. I don’t recommend an archetype yet — that needs validated history and explainable rules.</span></>, link: { label: 'Open Archetype', go: () => go(2) } }
    }
    return { kind: 'text', title: 'Here’s what I can do on this model', body: 'Describe the model, like “Velsipity, immunology, launch stage, streams for UC and Crohn’s”, and I’ll fill the fields for you to review. I can also explain this step, bind suggested sources, document assumptions, or audit before publishing. Changes always wait for your Apply.' }
  }

  /* Charles: reads plain-language requests and proposes governed field changes — nothing applies until confirmed */
  const casperGreeting = stage === 1
    ? `Hi ${ME.split(' ')[0]}, I’m ${ASSISTANT}. Describe the model in your own words — for example “set up a model for Velsipity in immunology at launch, with streams for ulcerative colitis and Crohn’s” — and I’ll fill the fields for you to review. You can also type them in directly.`
    : `You’re on ${S.title}. Ask me to explain this step, or tell me what to set up. Every change waits for your Apply.`

  const fillFrom = (raw: string): Reply | null => {
    const s = raw.toLowerCase().replace(/[‘’]/g, "'")
    const sn = s.replace(/-/g, ' ')
    let n: Config = c
    const ch: string[] = []
    const put = (p: Partial<Config>, msg: string) => { n = { ...n, ...p }; ch.push(msg) }
    const cap = (x: string) => x.trim().replace(/^./, m => m.toUpperCase())
    const newStreams: string[] = []

    const nm = /(?:name(?: the model| it)?(?: to| as)?|call(?: it| the model)?|called|named|model for|brand is|model is|set up|build|create|configure)\s+(?:a |an |the )?(?:new )?(?:model |brand )?(?:for |called |named )?["“]?([\w-]+(?: [\w-]+){0,2})/i.exec(raw)
    if (nm) {
      const words: string[] = []
      for (const w of nm[1].split(' ')) { if (/^[A-Z0-9]/.test(w)) words.push(w); else break }
      const name = words.join(' ')
      if (name && !/^(Model|Pipeline|Brand|Franchise|Portfolio|Patient|Prevalent|Rx|Set|Add|Use|All|The|A)$/i.test(words[0]) && name !== n.brand) {
        put({ brand: name }, `Model name: ${name}`)
        if (!n.asset.trim() || n.asset === c.brand) put({ asset: name }, `Brand / asset: ${name}`)
      }
    }
    const as = /\b(?:brand|asset)(?: name)? (?:is|=|:)\s*["“]?([A-Z][\w-]*(?: [A-Z][\w-]*)?)/.exec(raw)
    if (as && as[1] !== n.asset) put({ asset: as[1] }, `Brand / asset: ${as[1]}`)

    const type = ([['pipeline asset', 'Pipeline asset'], ['franchise', 'Franchise'], ['portfolio component', 'Portfolio component'], ['portfolio', 'Portfolio'], ['market level', 'Market-level asset'], ['brand', 'Brand / Asset']] as const).find(([k]) => sn.includes(k))
    if (type && /\b(type|is a|as a|asset|franchise|portfolio)\b/.test(s) && type[1] !== n.subjectType) put({ subjectType: type[1] }, `Model type: ${type[1]}`)
    const ta = ['Oncology', 'Immunology', 'Neurology', 'Rare disease', 'Cardiometabolic', 'Infectious disease', 'Vaccines'].find(o => s.includes(o.toLowerCase()))
    if (ta && ta !== n.therapyArea) put({ therapyArea: ta }, `Therapy area: ${ta}`)
    const life = /pre.?launch|pipeline \(|in the pipeline/.test(s) ? 'Pipeline (Pre-Launch)' : /loss of exclusivity|\bloe\b/.test(s) ? 'Loss of exclusivity' : /\bmature\b/.test(s) ? 'Mature' : /\bgrowth\b|\bgrowing\b/.test(s) ? 'Growth' : /\blaunch(ed|ing)?\b/.test(s) ? 'Launch' : ''
    if (life && life !== n.lifecycle) put({ lifecycle: life }, `Lifecycle stage: ${life}`)

    const adding = /\badd (?:a |another |one )?(?:revenue )?stream (?:for|called|named)?\s*([^.;\n]+)/i.exec(raw)
    const listed = /\b(?:streams?|indications?|lines?)\b(?: are| is| for| include| including)?\s*[:\-–]?\s*([^.;\n]+)/i.exec(raw)
    const split = (x: string) => x.replace(/ (?:with|using|on|in|as|at|by|on archetype)\b.*/i, '').split(/,| and |&|\//i).map(cap).filter(w => w.length > 1 && !/^(Stream|Streams|Indication|Indications)$/i.test(w))
    if (adding) {
      const names = split(adding[1]).slice(0, 4)
      if (names.length) {
        const blank = n.inds.filter(i => !i.name.trim() && !i.arch)
        const fresh = names.map((x, k) => ({ ...emptyInd(`i${Date.now()}${k}`, x) }))
        const inds = blank.length ? [...n.inds.filter(i => !blank.includes(i)), ...fresh] : [...n.inds, ...fresh]
        newStreams.push(...fresh.map(f => f.id))
        put({ inds, active: fresh[0].id }, `Add stream${names.length > 1 ? 's' : ''}: ${names.join(', ')}`)
      }
    } else if (!listed && nm && /\bwith\b/i.test(raw)) {
      const w = /\bwith\s+([^.;\n]+?)(?= on | using | as |\.|;|$)/i.exec(raw)
      const names = w ? split(w[1]).filter(x => !ARCHETYPES.some(a => x.toLowerCase().replace(/-/g, ' ').includes(a.name.toLowerCase().replace(/-/g, ' ')))).slice(0, 6) : []
      if (names.length) {
        const inds = names.map((x, k) => n.inds[k] ? { ...n.inds[k], name: x } : emptyInd(`i${Date.now()}${k}`, x))
        newStreams.push(...inds.map(i => i.id))
        put({ inds, active: inds[0].id }, `Revenue stream${names.length > 1 ? 's' : ''}: ${names.join(', ')}`)
      }
    } else if (listed && /,| and |&/.test(listed[1])) {
      const names = split(listed[1]).slice(0, 6)
      if (names.length > 1) {
        const inds = names.map((x, k) => n.inds[k] ? { ...n.inds[k], name: x } : emptyInd(`i${Date.now()}${k}`, x))
        newStreams.push(...inds.map(i => i.id))
        put({ inds, active: inds[0].id }, `Revenue streams: ${names.join(', ')}`)
      }
    }

    const arch = ARCHETYPES.find(a => sn.includes(a.name.toLowerCase().replace(/-/g, ' ')) || new RegExp(`\\b${a.id.toLowerCase().replace('-', '.?')}\\b`).test(s))
    if (arch) {
      const all = /\b(all|every|each|both)\b/.test(s) || newStreams.length > 1
      const targets = n.inds.filter(i => all ? true : newStreams.length === 1 ? newStreams.includes(i.id) : i.id === n.active)
      const todo = targets.filter(i => i.arch !== arch.id)
      if (todo.length) {
        const ids = new Set(todo.map(i => i.id))
        n = { ...n, inds: n.inds.map(i => ids.has(i.id) ? initInd(i, arch.id) : i), bindings: Object.fromEntries(Object.entries(n.bindings).filter(([k]) => !Array.from(ids).some(id => k.startsWith(`${id}:`)))) }
        ch.push(`Archetype ${arch.name} (${arch.id}) for ${todo.map(i => i.name || 'Untitled stream').join(', ')}, with its recommended engine, modes and modules`)
      }
    }

    const mk = /\b(united states|usa|u\.s\.|us)\b/.test(s) ? 'United States' : /\beu5\b|europe/.test(s) ? 'EU5' : /japan/.test(s) ? 'Japan' : /china/.test(s) ? 'China' : /rest of (the )?world/.test(s) ? 'Rest of world' : ''
    if (mk && /geograph|market|region|country|for the|in the|\beu5\b|japan|china/.test(s) && mk !== n.market) put({ market: mk }, `Geography: ${mk} (confirmed at Publish)`)
    const cy = CYCLES.find(x => s.includes(x.name.toLowerCase())) ?? (/\bq4\b/.test(s) ? CYCLES[1] : /\blrp\b/.test(s) ? CYCLES[2] : /\bop 2027\b|\bop\b/.test(s) ? CYCLES[0] : undefined)
    if (cy && cy.name !== n.cycle) put({ cycle: cy.name }, `Planning cycle: ${cy.name} (confirmed at Publish)`)
    const tier = /screening/.test(s) ? 'Screening' : /valuation/.test(s) ? 'Valuation' : /operational/.test(s) ? 'Operational planning' : ''
    if (tier && /tier|grade/.test(s) && tier !== n.grade) put({ grade: tier }, `Tier: ${tier}`)

    const fc = /forecaster|assign|share with|give access/.test(s) ? FORECASTERS.filter(f => f.toLowerCase().split(' ').some(w => w.length > 2 && new RegExp(`\\b${w}\\b`).test(s))) : []
    if (fc.length && fc.join() !== n.forecasters.join()) put({ forecasters: fc }, `Forecasters: ${fc.join(', ')}`)

    const rest = /(set me up|finish|complete|auto.?fill|fill (in )?(everything|the rest|all)|populate (everything|the rest|all)|the rest|everything)/.test(s)
    if (rest || /\b(bind|map|connect)\b.*\b(sources?|data|inputs?)\b|suggested sources/.test(s)) {
      const miss = inputsFor(n).filter(b => !n.bindings[b.key]?.source)
      if (miss.length) {
        n = { ...n, bindings: { ...n.bindings, ...Object.fromEntries(miss.map(b => [b.key, { source: b.input.suggested, owner: OWNERS[0], confidence: 'Medium' as const, status: 'idle' as const }])) } }
        ch.push(`Bind suggested sources to ${miss.length} input${miss.length > 1 ? 's' : ''}`)
      }
    }
    if (rest) {
      let k = 0
      const inds = n.inds.map(i => ({ ...i, perms: Object.fromEntries(Object.entries(i.perms).map(([id, p]) => { if (!missingMeta(p)) return [id, p]; k++; return [id, { ...p, owner: p.owner || ASSUMPTION_OWNERS[0], source: p.source || ASSUMPTION_SOURCES[0], confidence: p.confidence || 'Medium' as const }] })) }))
      if (k) { n = { ...n, inds }; ch.push(`Document owner, source and confidence on ${k} open assumption${k > 1 ? 's' : ''}`) }
    }

    if (!ch.length) return null
    const tracked = (['brand', 'asset', 'subjectType', 'therapyArea', 'lifecycle', 'inds'] as (keyof Config)[]).filter(k => n[k] !== c[k])
    n = { ...n, aiFields: Array.from(new Set([...c.aiFields, ...tracked])) }
    const keys = (Object.keys(n) as (keyof Config)[]).filter(k => n[k] !== c[k])
    const before = c
    const pick = (src: Config) => Object.fromEntries(keys.map(k => [k, src[k]])) as Partial<Config>
    const target = n
    const missing = [...validate(stage, target).map(i => i.msg), ...(stage === 1 && target.inds.some(i => !i.arch) ? ['Archetype for each stream — you choose it in the next step.'] : [])]
    return {
      kind: 'proposal', title: `I can fill ${ch.length} thing${ch.length > 1 ? 's' : ''} for you`, changes: ch, missing,
      link: stage < LAST && validate(stage, target).length === 0 ? { label: `Continue to ${STAGES[stage].title}`, go: () => nextRef.current() } : undefined,
      apply: () => setC(prev => ({ ...prev, ...pick(target) })),
      undo: () => setC(prev => ({ ...prev, ...pick(before) })),
    }
  }

  const casperRespond = (t: string): Reply => {
    const s = t.toLowerCase().trim()
    if (/^(hi|hello|hey|yo|good (morning|afternoon|evening))\b/.test(s)) return { kind: 'text', title: `Hi ${ME.split(' ')[0]}`, body: `You’re on ${S.title}${c.brand ? ` for ${c.brand}` : ''}. ${issues[stage - 1].length ? `${issues[stage - 1].length} item${issues[stage - 1].length > 1 ? 's' : ''} left on this step.` : 'This step looks complete.'} What should we set up?` }
    if (/^(thanks|thank you|thx|cheers)\b/.test(s)) return { kind: 'text', title: 'Anytime', body: 'I’ll be here. Ask me to audit before publishing whenever you’re ready.' }
    if (/who are you|what are you|what can you do|^help\b|what do you do/.test(s)) return { kind: 'text', title: `I’m ${ASSISTANT}, your configuration assistant`, body: `I fill fields from plain-language descriptions (model name, brand, therapy area, lifecycle, streams, sources and forecasters), explain each step, and audit the model before you publish. I follow the ${LAST}-step lifecycle and the CoE rules: I don’t recommend archetypes, never edit engine math or locked assumptions, and every change waits for your Apply.` }
    const f = fillFrom(t)
    if (f) return f
    if (stage === 1 && !/audit|missing|ready|check/.test(s)) {
      const miss = issues[0]
      return { kind: 'list', title: miss.length ? 'I couldn’t map that to a field yet. Here’s what’s still needed' : 'Model setup is complete', empty: 'Everything required is filled. Continue to Archetype when you’re ready.', items: miss.map(i => ({ tone: 'err' as const, text: i.msg })) }
    }
    return respond(t)
  }

  if (published) return <PublishedScreen c={c} when={published} onExit={onExit} />

  return (
    <div className="flex flex-1 flex-col">
      {/* persistent context bar */}
      <div className="sticky top-14 z-20 flex h-[50px] items-center gap-3 border-b border-border bg-surface px-5 text-sm">
        <div className="flex min-w-0 flex-1 items-center gap-2 overflow-hidden whitespace-nowrap">
          <button type="button" onClick={onExit} className="flex shrink-0 items-center gap-1 text-text-2 hover:text-text"><ArrowLeft size={14} />Library</button>
          <span className="text-text-3">/</span>
          <span className="truncate font-semibold">{c.brand || 'Untitled model'}</span>
          {ind.name && <span className="hidden min-w-0 truncate text-text-2 md:inline">/ {ind.name}</span>}
          <span className="hidden shrink-0 lg:inline-flex">{c.inds.some(i => i.arch && ARCH_DETAIL[i.arch].ceiling) ? <Badge tone="warn">Screening grade</Badge> : ind.arch && <Badge tone="brand">{archName(ind)}</Badge>}</span>
          {ins.length > 0 && <span className={cx('hidden shrink-0 items-center gap-1 text-xs xl:flex', stale ? 'text-warn' : 'text-text-3')}><Database size={12} />Data {okData}/{ins.length}{stale ? ` · ${stale} not current` : ''}</span>}
        </div>
        <div className="flex shrink-0 items-center gap-2.5">
          <span className="hidden items-center gap-1.5 text-xs text-text-2 xl:flex"><span>{c.market || 'Geography at Publish'}</span><span className="text-text-3">·</span><span>{c.cycle || 'Cycle at Publish'}</span></span>
          <span className="hidden md:inline-flex"><Badge tone="neutral">{c.version} · Draft</Badge></span>
          <span className="hidden items-center gap-1.5 text-xs text-text-3 sm:flex">{saving === 'saving' ? <><Loader2 size={12} className="animate-spin" />Saving…</> : <><Check size={12} />Saved</>}</span>
          <button type="button" onClick={() => setSharing(true)} title="Collaborators" className="hidden items-center -space-x-1.5 sm:flex">
            {c.team.slice(0, 4).map(m => <span key={m.name} className="grid h-7 w-7 place-items-center rounded-full border-2 border-surface bg-brand-soft text-[10px] font-semibold text-brand">{m.name.split(/[\s.]+/).filter(Boolean).map(x => x[0]).slice(0, 2).join('')}</span>)}
          </button>
          <Btn variant="secondary" size="sm" icon={<Users size={14} />} onClick={() => setSharing(true)}>Share</Btn>
          <Btn variant="ghost" size="sm" icon={<History size={14} />} onClick={() => setHistory(true)} title="Change history"><span className="hidden 2xl:inline">History</span></Btn>
          <Btn variant="secondary" size="sm" onClick={() => { notify({ tone: 'ok', text: 'Draft saved. Resume it from the library.' }); onExit() }}>Save & exit</Btn>
        </div>
      </div>

      <div className={cx('grid flex-1 lg:grid-cols-[232px_minmax(0,1fr)]',
        stage === REVIEW && 'wide:grid-cols-[232px_minmax(0,1fr)_300px]')}>
        <aside className="bg-brand-dark text-white lg:sticky lg:top-[106px] lg:h-[calc(100dvh-106px)] lg:overflow-y-auto">
          <div className="p-5">
            <p className="font-mono text-[11px] uppercase tracking-widest text-white/50">Configuration</p>
            <div className="mt-3 flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-white transition-all" style={{ width: `${(doneCount / (LAST - 1)) * 100}%` }} /></div>
              <span className="font-mono text-xs text-white/70">{doneCount}/{LAST - 1}</span>
            </div>
          </div>
          <ol className="flex gap-1 overflow-x-auto px-3 pb-4 lg:flex-col lg:overflow-visible">
            {STAGES.map(s => {
              const st = status(s.id)
              const n = issues[s.id - 1].length
              const locked = !canGo(s.id)
              return (
                <li key={s.id} className="shrink-0">
                  <button type="button" onClick={() => go(s.id)} disabled={locked} aria-current={s.id === stage ? 'step' : undefined}
                    title={locked ? `Complete ${STAGES[firstOpen - 1].title} first` : undefined}
                    className={cx('flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left outline-none transition-colors focus-visible:ring-2 focus-visible:ring-white/70 disabled:cursor-not-allowed', s.id === stage ? 'bg-white text-brand-dark' : locked ? 'opacity-55' : 'hover:bg-white/10')}>
                    <span className={cx('grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-semibold',
                      st === 'done' && 'bg-[#34d399] text-brand-dark', st === 'error' && 'bg-[#fb7185] text-white',
                      st === 'current' && 'bg-brand text-white', st === 'todo' && 'border border-white/40 text-white/80')}>
                      {st === 'done' ? <Check size={13} strokeWidth={3} /> : st === 'error' ? '!' : locked ? <Lock size={11} /> : s.id}
                    </span>
                    <span className="min-w-0">
                      <span className="flex items-center gap-1.5 whitespace-nowrap text-[13px] font-semibold leading-tight">{s.title}
                      </span>
                      <span className={cx('block whitespace-nowrap text-[11px]', s.id === stage ? 'text-text-2' : 'text-white/55')}>
                        {st === 'done' ? 'Complete' : st === 'error' ? (s.id === LAST ? `${blocking.length} step${blocking.length > 1 ? 's' : ''} to fix` : `${n} to fix`) : locked ? 'Locked' : s.sub}
                      </span>
                    </span>
                  </button>
                </li>
              )
            })}
          </ol>
        </aside>

        <AgentCtx.Provider value={agent}>
        <main className="flex min-w-0 flex-col">
          <div key={stage} className="rise @container relative mx-auto w-full max-w-[900px] flex-1 px-5 py-7 sm:px-6">
            <p className="font-mono text-xs uppercase tracking-widest text-brand">Step {stage} of {LAST}</p>
            <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
              <h1 className="text-[28px] font-semibold tracking-tight">{S.title}</h1>
            </div>
            <p className="mt-1 text-sm text-text-2">{S.desc}</p>

            {demo?.done && stage === 1 && <div className="mt-6 rounded-lg bg-[linear-gradient(90deg,#0000c90d,#7c3aed12,#db277710)] p-[1px]"><Banner tone="ok" title={`${ASSISTANT} filled 5 fields and 3 revenue streams`} action={<Btn size="sm" icon={<ArrowRight size={14} />} onClick={() => go(2)}>Continue to Archetype</Btn>}>Each filled field is tagged “Filled by {ASSISTANT}”. Review or edit anything before you continue. Editing a field clears its tag.</Banner></div>}
            {fixNote && (
              <div className="mt-6">
                <Banner tone={fixNote.left.length ? 'warn' : 'ok'}
                  title={fixNote.changes.length ? `${ASSISTANT} fixed ${fixNote.changes.length} item${fixNote.changes.length > 1 ? 's' : ''}${fixNote.left.length ? ` · ${fixNote.left.length} still need${fixNote.left.length > 1 ? '' : 's'} you` : ''}` : 'These need your decision'}
                  action={<div className="flex shrink-0 gap-1">{fixNote.changes.length > 0 && <Btn size="sm" variant="secondary" icon={<RotateCcw size={14} />} onClick={() => { setC(fixNote.before); setFixNote(null); notify({ tone: 'info', text: 'Fixes undone.' }) }}>Undo</Btn>}<Btn size="sm" variant="ghost" onClick={() => setFixNote(null)}>Dismiss</Btn></div>}>
                  {fixNote.changes.length > 0 && <ul className="mt-1 space-y-0.5">{fixNote.changes.map((t, k) => <li key={k} className="flex items-start gap-1.5"><Check size={13} className="mt-0.5 shrink-0 text-ok" />{t}</li>)}</ul>}
                  {fixNote.left.length > 0 && <><p className="mt-2 text-xs font-semibold text-text">Still needs you</p><ul className="mt-0.5 list-disc pl-4">{fixNote.left.map((t, k) => <li key={k}>{t}</li>)}</ul></>}
                  <p className="mt-2 text-xs text-text-3">{ASSISTANT} never chooses an archetype from scratch or changes CoE-locked values. Check each change before you continue.</p>
                </Banner>
              </div>
            )}

            {show && issues[stage - 1].length > 0 && (
              <div className="mt-6">
                <Banner tone="err" title={`${issues[stage - 1].length} thing${issues[stage - 1].length > 1 ? 's' : ''} to fix before you continue`} action={<FixForMe onClick={() => fix([stage])} />}>
                  <ul className="mt-1 list-disc pl-4">{issues[stage - 1].map((i, k) => <li key={k}>{i.msg}</li>)}</ul>
                </Banner>
              </div>
            )}

            {stage === 1 && seed.from && !seed.copy && seed.from.status === 'Published' && (
              <div className="mt-6"><Banner tone="info" title={`Editing creates working version ${c.version}`}>
                Published {seed.from.version} stays live and unchanged for forecasters. When you publish {c.version}, they see a “newer version available” banner and move over when ready; their scenarios on {seed.from.version} stay pinned.
              </Banner></div>
            )}
            {c.lockedBy && (
              <div className="mt-6"><Banner tone="warn" title={`${c.lockedBy} is editing this draft · active 3 min ago`}>
                You’re viewing read-only so changes don’t collide.
                <div className="mt-2 flex gap-2">
                  {asked ? <span className="flex items-center gap-1.5 text-xs font-semibold"><Clock size={12} />Request sent — waiting for {c.lockedBy}</span>
                    : <Btn size="sm" variant="secondary" onClick={() => { setAsked(true); setTimeout(() => { update({ lockedBy: '' }); notify({ tone: 'ok', text: `${c.lockedBy} handed over control. You hold the lock.` }) }, 2200) }}>Request control</Btn>}
                </div>
              </Banner></div>
            )}
            {c.frozen && !c.override && (
              <div className="mt-6"><Banner tone="err" title={`${c.cycle} is frozen — submission deadline passed`}>
                Fields are read-only. A CoE override is logged to the audit trail with your reason.
                <div className="mt-2"><Btn size="sm" variant="secondary" onClick={() => setOverriding(true)}>Override with reason</Btn></div>
              </Banner></div>
            )}
            {c.frozen && c.override && <div className="mt-6"><Banner tone="info" title="Freeze override active">Logged: “{c.override}” — {ME}, today.</Banner></div>}
            {c.retired && (
              <div className="mt-6"><Banner tone="warn" title="Engine D-04 v1.4 retires Nov 30">
                This model can’t publish on a retired engine. Migrating keeps the indication and resets modules and bindings for the new archetype.
                <div className="mt-2"><Btn size="sm" icon={<GitBranch size={13} />} onClick={() => { c.inds.forEach(i => i.arch === 'D-04' && setArch(i.id, 'D-03')); update({ retired: false }); notify({ tone: 'ok', text: 'Migrated to Patient-Flow (D-03 v4.1). Review modules and data.' }) }}>Migrate to D-03 v4.1</Btn></div>
              </Banner></div>
            )}

            <fieldset disabled={readOnly} className={cx('mt-6 min-w-0 space-y-6', readOnly && 'pointer-events-none opacity-60')}>
              {stage === 1 && <StageBrand {...ctx} errs={show ? issues[0] : []} />}
              {stage === 2 && <StageArchetype {...ctx} />}
              {stage === 3 && <StageModes {...ctx} />}
              {stage === 4 && <StageModules {...ctx} errs={issues[3]} />}
              {stage === 5 && <StageData {...ctx} />}
              {stage === REVIEW && <><IndTabs c={c} stage={stage} issues={[]} onPick={id => update({ active: id })} /><StagePreview {...ctx} issues={issues} warns={warns} /></>}
              {stage === LAST && <StagePublish {...ctx} issues={issues} warns={warns} errs={show ? issues[LAST - 1] : []}
                onPublish={() => { setPublished(new Date().toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })); onPublished(c); notify({ tone: 'ok', text: `${c.brand} ${c.version} published` }) }}
                onAttempt={() => setAttempted(a => new Set(a).add(LAST))} />}
            </fieldset>
            {overriding && (
              <div className="fixed inset-0 z-50 grid place-items-center bg-brand-dark/50 p-4" role="dialog" aria-modal="true" aria-labelledby="ovr-title" onClick={() => setOverriding(false)}>
                <div className="rise w-full max-w-md rounded-lg bg-surface p-6 shadow-xl" onClick={e => e.stopPropagation()}>
                  <h2 id="ovr-title" className="text-lg font-semibold">Override the {c.cycle} freeze</h2>
                  <p className="mt-1 text-sm text-text-2">Your reason is written to the audit trail.</p>
                  <textarea autoFocus value={reason} onChange={e => setReason(e.target.value)} rows={3} placeholder="e.g. Label update approved Oct 2 — finance agreed late submission" className={cx(inputCls(), 'mt-4 h-auto py-2')} />
                  <div className="mt-5 flex justify-end gap-2">
                    <Btn variant="secondary" onClick={() => setOverriding(false)}>Cancel</Btn>
                    <Btn disabled={reason.trim().length < 10} onClick={() => { update({ override: reason.trim() }); setOverriding(false); notify({ tone: 'ok', text: 'Override logged. Editing unlocked.' }) }}>Override and edit</Btn>
                  </div>
                </div>
              </div>
            )}
          </div>
          {stage < LAST && (
            <footer className="sticky bottom-0 z-20 border-t border-border bg-surface/95 backdrop-blur">
              <div className="mx-auto flex max-w-[900px] items-center gap-3 px-5 py-3 sm:px-6">
                <Btn variant="ghost" icon={<ArrowLeft size={16} />} disabled={stage === 1} onClick={() => go(stage - 1)}>Back</Btn>
                <span className="ml-auto hidden truncate text-[13px] text-text-3 md:block">
                  {issues[stage - 1].length ? `${issues[stage - 1].length} item${issues[stage - 1].length > 1 ? 's' : ''} left on this step` : <span className="flex items-center gap-1 text-ok"><CheckCircle2 size={14} />Ready</span>}
                </span>
                <Btn onClick={next} className="shrink-0 max-md:ml-auto"><span className="hidden sm:inline">Next:</span> {STAGES[stage].title}<ArrowRight size={16} /></Btn>
              </div>
            </footer>
          )}
        </main>

        </AgentCtx.Provider>
        {stage === REVIEW && <SummaryPanel c={c} issues={issues} visited={visited} go={go} />}
        {sharing && <ShareDialog c={c} update={update} notify={notify} onClose={() => setSharing(false)} />}
        {history && <HistoryDrawer c={c} onClose={() => setHistory(false)} />}
        <Charles open={assist} onToggle={() => setAssist(v => !v)} busy={demoBusy} respond={casperRespond} greeting={casperGreeting} context={[c.brand || 'New model', `Step ${stage} · ${S.short}`, ind.name || 'Stream 1']}
          extra={<DemoCard steps={DEMO_STEPS} demo={demo} onRun={runDemo} onStop={() => { demoId.current++; setAgent({ section: null, field: null }); setDemo(null) }} onReview={() => { go(1); if (window.innerWidth < 1024) setAssist(false) }} />}
          chips={stage === 1 ? ['Set up a model for Braftovi, a brand in oncology at growth, with streams for NSCLC, CRC and melanoma', 'Add a stream for Crohn’s', 'What’s still missing?'] : stage === 2 ? ['Compare the archetypes', 'Explain this step'] : stage === 3 ? ['What are modes?', 'Audit before publish'] : stage === 4 ? ['Attach default modules', 'Explain this step'] : stage === 5 ? ['Bind suggested sources', 'Diagnose data bindings'] : ['Set geography to EU5', 'Audit before publish']} />
      </div>

    </div>
  )
}

function ShareDialog({ c, update, notify, onClose }: { c: Config; update: (p: Partial<Config>) => void; notify: (t: Toast) => void; onClose: () => void }) {
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  const avail = PEOPLE.filter(p => !c.team.some(m => m.name === p))
  const [who, setWho] = useState('')
  const [role, setRole] = useState<Role>('Editor')
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(who.trim())
  const external = isEmail && !/@pfizer\.com$/i.test(who.trim())
  const known = PEOPLE.includes(who)
  const dup = c.team.some(m => m.name.toLowerCase() === who.trim().toLowerCase())
  const invite = () => { if (!(isEmail || known) || dup) return; update({ team: [...c.team, { name: who, role }] }); notify({ tone: 'ok', text: isEmail ? `Invite emailed to ${who.trim()} as ${role}${external ? ' · pending CoE approval' : ''}.` : `${who.split(' (')[0]} invited as ${role}. They can open this model only.` }); setWho('') }
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-brand-dark/50 p-4" role="dialog" aria-modal="true" aria-labelledby="share-title" onClick={onClose}>
      <div className="rise w-full max-w-lg rounded-lg bg-surface p-6 shadow-xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div><h2 id="share-title" className="text-lg font-semibold">Share {c.brand || 'this model'}</h2><p className="mt-1 text-sm text-text-2">Access is per model. People you invite see this model only, not the rest of the library.</p></div>
          <Btn variant="ghost" size="sm" onClick={onClose} icon={<X size={16} />}><span className="sr-only">Close</span></Btn>
        </div>
        <div className="mt-5 flex flex-wrap gap-2">
          <div className="relative min-w-0 flex-1">
            <Mail size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-3" />
            <input list="share-people" aria-label="Name or email" value={who} onChange={e => setWho(e.target.value)} onKeyDown={e => e.key === 'Enter' && invite()} placeholder="Name or email address" className={cx(inputCls(), 'pl-9')} />
            <datalist id="share-people">{avail.map(p => <option key={p} value={p} />)}</datalist>
          </div>
          <select aria-label="Role" className={cx(inputCls(), 'w-fit!')} value={role} onChange={e => setRole(e.target.value as Role)}>{ROLES.filter(x => x.r !== 'Creator').map(x => <option key={x.r}>{x.r}</option>)}</select>
          <Btn onClick={invite} disabled={!(isEmail || known) || dup}>Invite</Btn>
        </div>
        <p className={cx('mt-1.5 text-xs', dup ? 'text-err' : external ? 'text-warn' : 'text-text-3')}>{dup ? 'Already has access.' : external ? 'External address. The invite is emailed after CoE approval and expires in 7 days.' : isEmail ? 'They get an email with a link to this model.' : 'Pick a colleague or type any email address.'}</p>
        <ul className="mt-5 divide-y divide-border rounded-md border border-border">
          {c.team.map(m => (
            <li key={m.name} className="flex items-center gap-3 px-3 py-2.5">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-soft text-[11px] font-semibold text-brand">{m.name.split(/[\s.]+/).filter(Boolean).map(x => x[0]).slice(0, 2).join('')}</span>
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{m.name}{m.name === ME && <span className="text-text-3"> (you)</span>}</span>{m.name.includes('@') ? <span className="text-[11px] text-warn">Invite sent · not yet accepted</span> : null}</span>
              {m.role === 'Creator' ? <Badge tone="brand">Creator</Badge> : (
                <>
                  <select aria-label={`Role for ${m.name}`} className={cx(inputCls(), 'h-8! w-fit! text-[13px]')} value={m.role} onChange={e => update({ team: c.team.map(x => x.name === m.name ? { ...x, role: e.target.value as Role } : x) })}>{ROLES.filter(x => x.r !== 'Creator').map(x => <option key={x.r}>{x.r}</option>)}</select>
                  <Btn variant="ghost" size="sm" icon={<X size={14} />} onClick={() => update({ team: c.team.filter(x => x.name !== m.name) })}><span className="sr-only">Remove {m.name}</span></Btn>
                </>
              )}
            </li>
          ))}
        </ul>
        <dl className="mt-4 grid gap-x-4 gap-y-1.5 text-xs sm:grid-cols-2">{ROLES.map(x => <div key={x.r}><dt className="inline font-semibold">{x.r}</dt><dd className="inline text-text-2"> · {x.d}</dd></div>)}</dl>
        <p className="mt-3 text-xs text-text-3">Super User and Forecaster are platform roles from IAM. Forecasters are assigned at Publish. BD models sit in a separate restricted partition.</p>
      </div>
    </div>
  )
}

function HistoryDrawer({ c, onClose }: { c: Config; onClose: () => void }) {
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-brand-dark/40" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label="Change history" onClick={e => e.stopPropagation()} className="rise flex h-full w-full max-w-md flex-col bg-surface shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-border p-5">
          <div><p className="font-mono text-[11px] uppercase tracking-widest text-text-3">Change history</p><p className="font-semibold">{c.brand || 'Untitled model'} · {c.version} {c.release}</p><p className="text-xs text-text-2">What changed, who changed it, and when. Kept with every published version.</p></div>
          <Btn variant="ghost" size="sm" onClick={onClose} icon={<X size={16} />}><span className="sr-only">Close</span></Btn>
        </div>
        <ol className="flex-1 space-y-3 overflow-y-auto p-5">
          {c.log.length === 0 && <li className="text-sm text-text-2">No changes yet in this working version.</li>}
          {c.log.map((e, k) => (
            <li key={k} className="flex gap-3 text-[13px]">
              <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" />
              <div className="min-w-0"><p>{e.what}</p><p className="text-xs text-text-3">{e.who} · {e.when}</p></div>
            </li>
          ))}
          <li className="flex gap-3 text-[13px]"><span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-border-strong" /><div><p>Working version {c.version} opened</p><p className="text-xs text-text-3">{ME} · Today</p></div></li>
        </ol>
      </aside>
    </div>
  )
}

function IndTabs({ c, issues, onPick }: { c: Config; stage: number; issues: Issue[]; onPick: (id: string) => void }) {
  const ind = c.inds.find(i => i.id === c.active) ?? c.inds[0]
  return (
    <div className="mt-6 overflow-hidden rounded-lg border border-border bg-surface">
      <StreamList c={c} ind={ind} update={p => p.active && onPick(p.active)} tabs
        sub={i => issues.some(x => x.ind === i.id) ? ['Needs attention', false] : [i.arch ? archName(i.arch) : 'Ready', true]} />
    </div>
  )
}


/* ───────────────────────── Summary panel ───────────────────────── */

function SummaryPanel({ c, issues, visited, go }: { c: Config; issues: Issue[][]; visited: Set<number>; go: (n: number) => void }) {
  const ins = inputsFor(c)
  const bound = ins.filter(b => resolved(c.bindings[b.key])).length
  const open = c.inds.reduce((n, i) => n + Object.values(i.perms).filter(p => p.open).length, 0)
  const rows: { label: string; value: ReactNode; stage: number }[] = [
    { label: 'Model', value: c.brand ? `${c.brand} · ${c.asset} · ${c.subjectType}` : <span className="text-text-3">Not set</span>, stage: 1 },
    { label: 'Geography & cycle', value: visited.has(LAST) ? `${c.market} · ${c.cycle}` : <span className="text-text-3">Set at Publish</span>, stage: LAST },
    { label: 'Streams & archetypes', value: <ul className="space-y-0.5">{c.inds.map(i => <li key={i.id}>{i.name || 'Untitled'} <span className="text-text-3">· {ARCHETYPES.find(a => a.id === i.arch)?.name ?? 'not chosen'}</span></li>)}</ul>, stage: 2 },
    { label: 'Modules', value: c.inds.some(i => i.arch) ? c.inds.map(i => `${i.modules.length}`).join(' + ') + ' attached' : '—', stage: 4 },
    { label: 'Data', value: ins.length ? `${bound} of ${ins.length} bound` : '—', stage: 5 },
  ]
  return (
    <aside className="hidden border-l border-border bg-surface wide:block">
      <div className="sticky top-[106px] max-h-[calc(100dvh-106px)] overflow-y-auto p-5">
        <p className="font-mono text-[11px] uppercase tracking-widest text-text-3">Model summary</p>
        <dl className="mt-4 divide-y divide-border">
          {rows.map(r => {
            const bad = visited.has(r.stage) && issues[r.stage - 1].length > 0
            return (
              <div key={r.label} className="group py-3">
                <dt className="flex items-center justify-between text-xs text-text-3">
                  <span className="flex items-center gap-1">{r.label}{bad && <AlertCircle size={11} className="text-err" />}</span>
                  <button type="button" onClick={() => go(r.stage)} className="font-semibold text-brand hover:underline">Edit</button>
                </dt>
                <dd className="mt-0.5 text-[13px] font-medium text-text">{r.value}</dd>
              </div>
            )
          })}
        </dl>
        <div className="mt-4 rounded-md bg-background p-3 text-xs text-text-2">
          <p className="font-semibold text-text">Tier: {c.grade}</p>
          <p className="mt-1">Tiers only move down in use — a screening model can never be promoted into a valuation.</p>
        </div>
      </div>
    </aside>
  )
}

/* ───────────────────────── Step 1 · Brand setup ───────────────────────── */

function StageBrand({ c, update, errs }: Ctx & { errs: Issue[] }) {
  const err = (f: string) => errs.find(e => e.field === f)?.msg
  const ai = (k: keyof Config) => c.aiFields.includes(k)
  // Editing a field the assistant filled clears its marker: the value is now the user's.
  const setF = <K extends keyof Config>(k: K, v: Config[K]) => update({ [k]: v, aiFields: c.aiFields.filter(x => x !== k) } as Partial<Config>)
  const [pending, setPending] = useState<string | null>(null)
  const addInd = () => { const id = 'i' + Date.now(); update({ inds: [...c.inds, emptyInd(id, '')], active: id }) }
  const rmInd = (id: string) => {
    const inds = c.inds.filter(i => i.id !== id)
    update({ inds, active: c.active === id ? inds[0]?.id ?? '' : c.active, bindings: Object.fromEntries(Object.entries(c.bindings).filter(([k]) => !k.startsWith(`${id}:`))) })
  }

  return (
    <>
      <Banner tone="info" title={`Geography and planning cycle are set at Publish (Step ${LAST})`}>This keeps the model structure reusable across cycles and geographies. Prefer to talk it through? Describe the model to {ASSISTANT} and review what it fills.</Banner>

      <AgentSection id="subject"><Card title="Forecast subject" sub="What this model forecasts. Required fields are marked *.">
        <div className="grid gap-5 @xl:grid-cols-2">
          <Field label="Model name" required error={err('brand')} ai={ai('brand')} agent="brand"><input className={inputCls(!!err('brand'))} value={c.brand} onChange={e => setF('brand', e.target.value)} placeholder="e.g. Velsipity US model" /></Field>
          <Field label="Brand or asset name" required error={err('asset')} ai={ai('asset')} agent="asset"><input className={inputCls(!!err('asset'))} value={c.asset} onChange={e => setF('asset', e.target.value)} placeholder="e.g. Velsipity" /></Field>
          <Field label="Asset type" ai={ai('subjectType')} agent="subjectType">
            <select className={inputCls()} value={c.subjectType} onChange={e => setF('subjectType', e.target.value)}>
              {['Brand / Asset', 'Pipeline asset', 'Franchise', 'Portfolio', 'Portfolio component', 'Market-level asset', 'Other modeled unit'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Therapy area" hint="Reference only — does not restrict archetype" ai={ai('therapyArea')} agent="therapyArea">
            <select className={inputCls()} value={c.therapyArea} onChange={e => setF('therapyArea', e.target.value)}>
              {['Oncology', 'Immunology', 'Neurology', 'Rare disease', 'Cardiometabolic', 'Infectious disease', 'Vaccines', 'Other'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Lifecycle stage" ai={ai('lifecycle')} agent="lifecycle">
            <select className={inputCls()} value={c.lifecycle} onChange={e => setF('lifecycle', e.target.value)}>
              {['Pipeline (Pre-Launch)', 'Launch', 'Growth', 'Mature', 'Loss of exclusivity'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
        </div>
        <fieldset className="mt-5">
          <legend className="mb-2 text-[11px] font-bold uppercase tracking-wider text-text-2">Multi-asset options</legend>
          <div className="space-y-2">
            <label className="flex items-start gap-2.5 text-sm"><input type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 accent-brand" checked={c.competing} onChange={e => update({ competing: e.target.checked })} />Model competing assets drawing from the same patient pool (e.g. Brand A 1L vs Brand B 1L)</label>
            <label className="flex items-start gap-2.5 text-sm"><input type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 accent-brand" checked={c.subnational} onChange={e => update({ subnational: e.target.checked })} />Enable subnational breakout (provinces, regions, channels) — configurable at Publish</label>
          </div>
        </fieldset>
      </Card></AgentSection>

      <AgentSection id="streams"><Card title="Revenue streams" sub={c.aiFields.includes('inds') ? `Streams were filled by ${ASSISTANT} — review the names below.` : undefined} right={<Btn variant="secondary" size="sm" icon={<Plus size={14} />} onClick={addInd}>Add stream</Btn>}>
        <div className="mb-4"><Banner tone="info" title="A stream is one revenue line of the subject, forecast on its own.">Each stream gets its own archetype in Step 2. Split by indication, line of therapy, biomarker cohort, channel or sub-region. Reorder streams here; the order carries through every step.</Banner></div>
        {err('inds') && <p className="mb-3 flex items-center gap-1 text-xs text-err"><AlertCircle size={12} />{err('inds')}</p>}
        <ul className="space-y-3">
          {c.inds.map((i, k) => {
            const e = err(`ind-${i.id}`)
            const set = (p: Partial<Ind>) => update({ inds: c.inds.map(x => x.id === i.id ? { ...x, ...p } : x) })
            return (
              <li key={i.id} className={cx('rounded-md border p-4', e ? 'border-err bg-err-soft/30' : c.active === i.id ? 'border-brand/40 bg-brand-soft/30' : 'border-border')}>
                <div className="flex flex-wrap items-end gap-3">
                  <div className="grid min-w-[220px] flex-1 gap-3 @xl:grid-cols-2">
                    <Field label={`Stream ${k + 1} name`} error={e} agent={`stream-${k}`}><input className={inputCls(!!e)} value={i.name} onFocus={() => update({ active: i.id })} onChange={ev => set({ name: ev.target.value })} placeholder={`Revenue Stream ${k + 1}`} /></Field>
                    <Field label="Stream dimension"><select className={inputCls()} value={i.dim || ''} onChange={ev => set({ dim: ev.target.value })}>
                      <option value="">Not specified</option>{['Indication', 'Geography', 'Product', 'Biomarker', 'Line of therapy', 'Asset type', 'Channel', 'Age', 'Other'].map(o => <option key={o}>{o}</option>)}
                    </select></Field>
                    {i.dim === 'Other' && (
                      <div className="@xl:col-span-2">
                        <Field label="Define the dimension"><input className={cx(inputCls(), 'py-0')} value={i.dimOther || ''} onChange={ev => set({ dimOther: ev.target.value })} placeholder="e.g. Treatment setting, Disease severity" /></Field>
                      </div>
                    )}
                  </div>
                  <div className="mb-1 flex gap-1">
                    <Btn variant="ghost" size="sm" disabled={k === 0} onClick={() => update({ inds: c.inds.map((x, j, a) => j === k - 1 ? a[k] : j === k ? a[k - 1] : x) })}><span className="sr-only">Move up</span>↑</Btn>
                    <Btn variant="ghost" size="sm" disabled={k === c.inds.length - 1} onClick={() => update({ inds: c.inds.map((x, j, a) => j === k + 1 ? a[k] : j === k ? a[k + 1] : x) })}><span className="sr-only">Move down</span>↓</Btn>
                    <Btn variant="ghost" size="sm" icon={<Copy size={14} />} onClick={() => { const id = `i${Date.now()}`; update({ inds: [...c.inds.slice(0, k + 1), { ...i, id, name: `${i.name || 'Stream'} (copy)` }, ...c.inds.slice(k + 1)], active: id }) }}><span className="sr-only">Duplicate stream</span></Btn>
                  </div>
                  <Btn variant="danger" size="sm" className="mb-1" disabled={c.inds.length === 1} title={c.inds.length === 1 ? 'A model needs at least one stream' : undefined} icon={<X size={14} />} onClick={() => i.arch ? setPending(i.id) : rmInd(i.id)}><span className="sr-only">Remove stream</span></Btn>
                </div>
              </li>
            )
          })}
        </ul>
        {pending && (() => {
          const i = c.inds.find(x => x.id === pending)
          const nb = Object.keys(c.bindings).filter(k => k.startsWith(`${pending}:`)).length
          return (
            <div className="mt-4"><Banner tone="warn" title={`Remove ${i?.name || 'this stream'}?`}
              action={<div className="flex shrink-0 gap-2"><Btn size="sm" variant="secondary" onClick={() => setPending(null)}>Keep</Btn><Btn size="sm" variant="danger" onClick={() => { rmInd(pending); setPending(null) }}>Remove</Btn></div>}>
              Clears {nb} data binding{nb === 1 ? '' : 's'} and {i?.modules.length ?? 0} modules. Published versions are untouched.
            </Banner></div>
          )
        })()}
      </Card></AgentSection>
    </>
  )
}

/* ───────────────────────── Step 2 · Archetypes ───────────────────────── */

const ARCH_GRID: { id: ArchId; name: string; blurb: string; who: string }[] = [
  { id: 'D-01', name: 'Prevalent Share', blurb: 'Re-stated pool of treated patients; brand captures a share each period. No memory of how patients arrived.', who: 'Brand forecasters · IIS / Marketing' },
  { id: 'D-02', name: 'Rx Share', blurb: 'Prescription basket defines the market; volume trended forward; brand takes a share. No patient state.', who: 'Finance · Alliance convention' },
  { id: 'D-03', name: 'Patient Flow', blurb: 'New patients start and persist by a decay surface; book = convolution of start cohorts × persistency.', who: 'Brand forecasters · Chronic / Specialty' },
  { id: 'D-05', name: 'Market Stock-Flow', blurb: 'Eligible stock depleted by capture, replenished by aging and re-entry. Dose chains, waning, boosters.', who: 'Vaccines forecasters · US & International' },
  { id: 'D-07', name: 'Peak-Year Sizing', blurb: 'Time-collapsed funnel at a single peak year. Ranges not points, confidence grades, reverse-solve tables.', who: 'Business Assessment · BD&L' },
]
const archName = (id: ArchId | null) => ARCH_GRID.find(a => a.id === id)?.name ?? (id === 'D-06' ? 'Trend / Extrapolation' : ARCHETYPES.find(a => a.id === id)?.name ?? '')

function StageArchetype({ c, ind, update, updInd, setArch, notify, fix }: Ctx) {
  const [pending, setPending] = useState<ArchId | null>(null)
  const [detail, setDetail] = useState<ArchId | null>(null)
  const sel = ind.arch
  const advance = () => { const nxt = c.inds.find(i => i.id !== ind.id && !i.arch); if (nxt) update({ active: nxt.id }) }
  const pick = (id: ArchId) => { if (ind.arch === id) return; if (ind.arch) setPending(id); else { setArch(ind.id, id); advance() } }
  const others = c.inds.filter(i => i.id !== ind.id)
  const differ = others.filter(i => i.arch !== sel)
  const applyAll = () => {
    if (!sel) return
    differ.forEach(i => setArch(i.id, sel))
    notify({ tone: 'ok', text: `${archName(sel)} applied to all ${c.inds.length} streams.` })
  }
  const coreCount = (a: ArchId) => MODULES.filter(m => m.required?.includes(a)).length
  const impact = (() => {
    const nb = Object.keys(c.bindings).filter(k => k.startsWith(`${ind.id}:`)).length
    return `${Object.keys(ind.modes).filter(k => k !== 'trend' && !k.startsWith('time_')).length} modes and ${ind.modules.length} attached modules reset to the new archetype’s defaults, ${nb} data binding${nb === 1 ? '' : 's'} for this stream ${nb === 1 ? 'is' : 'are'} cleared, and its assumptions reset.${c.baseline ? ' The baseline will need regenerating.' : ''} Other streams aren’t touched.`
  })()
  const badCombo = sel && c.grade === 'Valuation' && (ind.engine.includes('beta') || ARCH_DETAIL[sel].status !== 'Certified')
  const legacy = sel === 'D-04'

  return (
    <>
      <Banner tone="info" title="Archetypes define the core mathematical engine that converts eligible patients into volume.">They are the middle of the funnel. Upstream and downstream calculations are handled by modules configured in Step 4.</Banner>

      <section className="overflow-hidden rounded-lg border border-border bg-surface">
        <StreamList c={c} ind={ind} update={update} tabs
          sub={i => i.arch ? [i.arch, true] : ['No archetype', false]}
          footer={c.inds.length > 1 && (
            <Btn size="sm" variant="secondary" icon={sel && !differ.length ? <Check size={14} /> : <Zap size={14} />} disabled={!sel || !differ.length} onClick={applyAll}
              title={!sel ? 'Pick an archetype for the selected stream first' : sel && differ.some(i => i.arch) ? 'Streams with a different archetype reset to its defaults.' : undefined}>
              {sel && !differ.length ? 'Applied to all streams' : sel ? `Apply ${archName(sel)} to all` : 'Apply to all streams'}
            </Btn>
          )} />

        <div className="@container min-w-0 p-4">
          <p className="mb-3 text-[13px] text-text-2">Archetype for <b className="text-text">{ind.name || 'this stream'}</b> — your choice; nothing is pre-selected.</p>
          {pending && <div className="mb-3">
            <Banner tone="warn" title={`Switch ${ind.name || 'this stream'} to ${archName(pending)}? This affects later steps.`}
              action={<div className="flex shrink-0 flex-col gap-2 @md:flex-row"><Btn size="sm" variant="secondary" onClick={() => setPending(null)}>Keep current</Btn><Btn size="sm" onClick={() => { setArch(ind.id, pending); setPending(null); notify({ tone: 'info', text: `${ind.name || 'Stream'} switched to ${archName(pending)}. Review modes and modules.` }) }}>Switch</Btn></div>}>
              {impact}
            </Banner>
          </div>}
          {sel && !pending && (
            <div className="mb-3 flex items-start gap-2 rounded-md border border-ok/25 bg-ok-soft px-3 py-2.5 text-[13px]">
              <CheckCircle2 size={15} className="mt-0.5 shrink-0 text-ok" />
              <p className="min-w-0"><b>{archName(sel)}</b> selected for {ind.name || 'this stream'}. It loads {modesFor(sel).length} modes and {coreCount(sel)} core modules in the next steps.</p>
            </div>
          )}
          <div className="grid grid-cols-1 gap-2" role="radiogroup" aria-label={`Archetype for ${ind.name || 'this stream'}`}>
            {ARCH_GRID.map(a => {
              const on = sel === a.id
              const d = ARCH_DETAIL[a.id]
              const open = detail === a.id
              return (
                <div key={a.id} className={cx('rounded-md border transition-all', on ? 'border-brand bg-brand-soft/30 ring-1 ring-brand' : 'border-border hover:border-text-2')}>
                  <button type="button" role="radio" aria-checked={on} onClick={() => pick(a.id)}
                    className="flex w-full items-start gap-4 rounded-md p-3 text-left outline-none focus-visible:ring-2 focus-visible:ring-brand">
                    <span className="flex min-w-0 flex-1 flex-col">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold">{a.name}</span>
                        <span className="font-mono text-[10px] text-text-3">{a.id}</span>
                        <span className="sr-only">{d.status}</span>{d.status !== 'Certified' && <Badge tone="warn">{d.status}</Badge>}
                      </span>
                      <span className="mt-1 text-xs leading-snug text-text-2">{a.blurb}</span>
                      <span className="mt-2 flex flex-wrap items-center gap-2">
                        <span className="text-[11px] text-text-3">{modesFor(a.id).length} modes · {coreCount(a.id)} core modules</span>
                      </span>
                    </span>
                    <span aria-hidden className={cx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 transition-colors', on ? 'border-brand' : 'border-border-strong')}>{on && <span className="h-2.5 w-2.5 rounded-full bg-brand" />}</span>
                  </button>
                  <div className="px-3 pb-2.5">
                    <button type="button" aria-expanded={open} onClick={() => setDetail(open ? null : a.id)} className="inline-flex items-center gap-1 text-xs font-semibold text-brand hover:underline">
                      {open ? 'Hide details' : 'View details'}<ChevronDown size={13} className={cx('transition-transform', open && 'rotate-180')} />
                    </button>
                    {open && (
                      <dl className="mt-2 grid gap-3 rounded-md bg-background p-3 text-xs @xl:grid-cols-2">
                        <div><dt className="font-semibold text-text">Question it answers</dt><dd className="mt-0.5 text-text-2">{d.question}</dd></div>
                        <div><dt className="font-semibold text-text">Typical use (reference only)</dt><dd className="mt-0.5 text-text-2">{d.uses.join(' · ')}</dd></div>
                        <div><dt className="font-semibold text-text">Modes it loads</dt><dd className="mt-0.5 text-text-2">{modesFor(a.id).map(m => m.label).join(' · ')}</dd></div>
                        <div><dt className="font-semibold text-text">Limits</dt><dd className="mt-0.5 text-text-2">{d.limit}</dd></div>
                      </dl>
                    )}
                  </div>
                </div>
              )
            })}
            <div className={cx('flex items-start gap-4 rounded-md border border-dashed p-3', sel === 'D-06' ? 'border-brand ring-1 ring-brand' : 'border-border-strong bg-background')}>
              <div className="flex min-w-0 flex-1 flex-col">
                <span className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-text-2">Trend / Extrapolation</span>
                  <Badge>Under discussion</Badge>
                </span>
                <span className="mt-1 text-xs leading-snug text-text-3">Evidence supports this as a cross-engine capability rather than a standalone archetype.</span>
                <span className="mt-2 flex flex-wrap items-center gap-2">
                  {sel === 'D-06' ? <Badge tone="brand"><Check size={10} />Used standalone</Badge>
                    : <Btn size="sm" variant="secondary" onClick={() => pick('D-06')}>Use as standalone<ArrowUpRight size={13} /></Btn>}
                  <span className="text-[10px] text-text-3">Alignment pending</span>
                </span>
              </div>
              <span aria-hidden className={cx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2', sel === 'D-06' ? 'border-brand' : 'border-border-strong')}>{sel === 'D-06' && <span className="h-2.5 w-2.5 rounded-full bg-brand" />}</span>
            </div>
          </div>
        </div>
      </section>

      {legacy && <Banner tone="warn" title="This stream uses Brand Inflow-Outflow (D-04), which is under review">It may fold into Patient Flow. Pick Patient Flow above to migrate.</Banner>}

      {badCombo && <div><Banner tone="err" title="Not allowed at Valuation tier" action={<FixForMe onClick={() => fix([2])} />}>{ind.engine.includes('beta') ? 'Beta engines' : 'Archetypes under review'} can’t back a valuation. Pick a certified engine or another archetype.</Banner></div>}
    </>
  )
}


function StreamList({ c, ind, update, sub, footer, tabs }: Pick<Ctx, 'c' | 'ind' | 'update'> & { sub: (i: Ind) => [string, boolean]; footer?: ReactNode; tabs?: boolean }) {
  const done = c.inds.filter(i => sub(i)[1]).length
  // Horizontal tab strip across the top of the section
  if (tabs) return (
    <div className="flex items-end gap-3 border-b border-border bg-background/60 px-3 pt-2">
      <ul role="tablist" aria-label="Revenue streams" className="-mb-px flex min-w-0 flex-1 gap-1 overflow-x-auto">
        {c.inds.map((i, k) => {
          const on = i.id === ind.id
          const [label, ok] = sub(i)
          return (
            <li key={i.id} className="shrink-0">
              <button type="button" role="tab" aria-selected={on} onClick={() => update({ active: i.id })} title={label}
                className={cx('flex items-center gap-2 rounded-t-md border border-b-2 px-3.5 py-2.5 text-left transition-colors', on ? 'border-border border-b-brand bg-surface text-text' : 'border-transparent text-text-2 hover:bg-surface/70 hover:text-text')}>
                <span className={cx('grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-semibold', ok ? 'bg-ok text-white' : on ? 'bg-brand text-white' : 'border border-border-strong text-text-2')}>{ok ? <Check size={11} strokeWidth={3} /> : k + 1}</span>
                <span className="whitespace-nowrap text-[13px] font-semibold">{i.name || `Stream ${k + 1}`}</span>
                <span className={cx('whitespace-nowrap text-[11px]', on ? 'text-brand' : 'text-text-3')}>{label}</span>
              </button>
            </li>
          )
        })}
      </ul>
      <div className="flex shrink-0 items-center gap-3 pb-2">
        <span className="font-mono text-[11px] text-text-3">{done}/{c.inds.length}</span>
        {footer}
      </div>
    </div>
  )
  return (
    <div className="border-b border-border bg-background/60 @3xl:border-b-0 @3xl:border-r">
      <div className="flex items-center justify-between gap-2 px-4 pb-2 pt-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-text-3">Revenue streams</p>
        <span className="font-mono text-[11px] text-text-3">{done}/{c.inds.length}</span>
      </div>
      <ul role="tablist" aria-label="Revenue streams" aria-orientation="vertical" className="space-y-1 px-2 pb-2">
        {c.inds.map((i, k) => {
          const on = i.id === ind.id
          const [label, ok] = sub(i)
          return (
            <li key={i.id}>
              <button type="button" role="tab" aria-selected={on} onClick={() => update({ active: i.id })}
                className={cx('flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left transition-colors', on ? 'bg-surface shadow-sm ring-1 ring-brand' : 'hover:bg-surface')}>
                <span className={cx('grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-semibold', ok ? 'bg-ok text-white' : on ? 'bg-brand text-white' : 'border border-border-strong text-text-2')}>{ok ? <Check size={12} strokeWidth={3} /> : k + 1}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-semibold">{i.name || `Stream ${k + 1}`}</span>
                  <span className={cx('block truncate text-[11px]', ok ? 'text-brand' : 'text-text-3')}>{label}</span>
                </span>
                {on && <ChevronRight size={16} className="shrink-0 text-brand" />}
              </button>
            </li>
          )
        })}
      </ul>
      {footer && <div className="border-t border-border p-3">{footer}</div>}
    </div>
  )
}

function getBridgeReason(label: string, from: string, to: string) {
  const r: Record<string, string> = {
    'Aggregate Churn>Cohort KM': 'requires initial-stock imputation',
    'Forward DoT>Cohort KM': 'requires initial-stock imputation and fitting a survival surface to stated durations',
    'Cohort KM>Aggregate Churn': 'requires collapsing the survival surface into one monthly rate, losing start-cohort detail',
    'Forward DoT>Aggregate Churn': 'requires deriving an implied monthly discontinuation rate from stated durations',
    'Cohort KM>Forward DoT': 'requires converting survival curves into explicit durations of therapy per cohort',
    'Aggregate Churn>Forward DoT': 'requires converting the churn rate into explicit durations of therapy per cohort',
    'Independent>Named Feeders': 'requires naming the upstream brand and realized share feeding each line',
    'Independent>Progression-Derived': 'requires restating later-line history as upstream drop-offs',
    'Named Feeders>Progression-Derived': 'requires replacing named feeder shares with drop-off-derived eligibility',
    'Progression-Derived>Named Feeders': 'requires specifying a feeder brand and share where eligibility was derived',
    'Named Feeders>Independent': 'requires re-sizing each line from epi, dropping feeder links',
    'Progression-Derived>Independent': 'requires re-sizing each line from epi, dropping upstream links',
  }
  if (label === 'Actuals regime') {
    if (to === 'Claims-level actuals') return 'requires re-mapping the actuals boundary to patient-level claims and re-running calibration'
    if (to === 'Pre-launch (no actuals)') return 'removes the actuals boundary, so calibration falls back to analog assumptions'
    return 'requires aggregating claims history up to the reported-sales boundary'
  }
  return r[`${from}>${to}`] ?? `changes the ${label.toLowerCase()} and requires a bridge to restate history under the new specification`
}

function StageModes({ c, ind, update, updInd, go, notify }: Ctx) {
  const [seen, setSeen] = useState<Set<string>>(() => new Set([ind.id]))
  const [bridge, setBridge] = useState<Record<string, { label: string; from: string; to: string }>>(() => {
    const initB: Record<string, { label: string; from: string; to: string }> = {}
    if (ind.arch === 'D-03' && ind.modes.persist === 'Cohort KM') {
      initB[`${ind.id}:persist`] = { label: 'Persistence specification', from: 'Aggregate Churn', to: 'Cohort KM' }
    }
    return initB
  })
  useEffect(() => { setSeen(x => x.has(ind.id) ? x : new Set(x).add(ind.id)) }, [ind.id])
  const [touched, setTouched] = useState(false)
  const arch = ind.arch
  const modes = arch ? { ...Object.fromEntries(modesFor(arch).map(x => [x.id, modeDefault(arch, x)])), ...ind.modes } : {}
  const groups = arch ? modesFor(arch).filter(m => !m.showIf || m.showIf(modes)) : []
  const reqN = groups.filter(m => !m.optional).length
  const set = (m: Pick<ModeDef, 'id' | 'label'>, v: string) => {
    if (modes[m.id] === v) return
    const currentVal = modes[m.id]
    updInd(ind.id, { modes: { ...ind.modes, [m.id]: v } })
    const k = `${ind.id}:${m.id}`
    setBridge(b => {
      const prevOrig = b[k]?.from ?? currentVal
      const n = { ...b }
      if (prevOrig === v) {
        delete n[k]
      } else {
        n[k] = { label: m.label, from: prevOrig, to: v }
      }
      return n
    })
  }
  const sameArch = c.inds.filter(i => i.id !== ind.id && i.arch === arch)
  const copyAll = () => { sameArch.forEach(i => updInd(i.id, { modes: { ...ind.modes } })); notify({ tone: 'ok', text: `Modes copied to ${sameArch.length} ${archName(arch)} stream${sameArch.length > 1 ? 's' : ''}.` }) }
  const bridgesOf = (id: string) => Object.entries(bridge).filter(([k]) => k.startsWith(`${id}:`)).map(([, v]) => v)
  const bridgeFor = (mid: string) => bridge[`${ind.id}:${mid}`]
  const pending = bridgesOf(ind.id).length

  const BridgeNote = ({ id }: { id: string }) => {
    const b = bridgeFor(id)
    if (!b) return null
    return (
      <div role="status" className="mt-2.5 flex items-start gap-2 rounded-md border border-warn/30 bg-warn-soft/50 px-3 py-2.5 text-[13px]">
        <AlertTriangle size={14} className="mt-0.5 shrink-0 text-warn" />
        <p className="min-w-0 flex-1"><b>Bridge required:</b> Switching from {b.from} to {b.to} {getBridgeReason(b.label, b.from, b.to)} — flagged as an assumption requiring sign-off.</p>
        <button type="button" onClick={() => set({ id, label: b.label }, b.from)} className="inline-flex shrink-0 items-center gap-1 rounded px-1.5 py-0.5 text-xs font-semibold text-brand hover:underline"><RotateCcw size={12} />Undo</button>
      </div>
    )
  }

  return (
    <section className="overflow-hidden rounded-lg border border-border bg-surface">
      <StreamList c={c} ind={ind} update={update} tabs
        sub={i => {
          if (!i.arch) return ['No archetype yet', false]
          const n = bridgesOf(i.id).length
          return [n ? `${n} to sign off` : seen.has(i.id) ? 'Reviewed' : 'Defaults', seen.has(i.id)]
        }}
        footer={c.inds.length > 1 && (
          <Btn size="sm" variant="secondary" icon={<Copy size={14} />} disabled={!arch || !sameArch.length} onClick={copyAll}
            title={arch && sameArch.length ? `Copies these modes to ${sameArch.length} other stream${sameArch.length > 1 ? 's' : ''} on ${archName(arch)}.` : 'Modes only copy between streams on the same engine.'}>Apply to all</Btn>
        )} />

      <div className="@container min-w-0 p-5">
        {!arch ? (
          <EmptyState icon={<Layers size={18} />} title={`No archetype for ${ind.name || 'this stream'}`} action={<Btn size="sm" onClick={() => go(2)}>Choose an archetype</Btn>}>Modes are specific to the engine, so pick one first.</EmptyState>
        ) : (
          <div>
            <div className="mb-4 flex flex-wrap items-end justify-between gap-2 border-b border-border pb-4">
              <div className="min-w-0">
                <h3 className="text-lg font-bold tracking-tight">{ind.name || 'Stream'}</h3>
                <p className="text-sm text-text-2">{archName(arch)} · {groups.length} modes valid for this archetype</p>
              </div>
              <span className="text-xs text-text-3">{reqN} required · {groups.length - reqN} optional{pending ? ` · ${pending} bridge${pending > 1 ? 's' : ''} to sign off` : ''}</span>
            </div>
            <div className="divide-y divide-border">
              {groups.map(m => {
                return (
                  <div key={m.id} role="group" aria-label={m.label} className="grid min-w-0 gap-x-8 gap-y-2 py-4 first:pt-0 last:pb-0 @xl:grid-cols-[minmax(0,1fr)_minmax(0,300px)] @xl:items-start">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-text">{m.label}</span>
                        {m.optional ? <Badge>Optional</Badge> : <Badge tone="brand">Required</Badge>}
                      </div>
                      <p className="mt-0.5 text-xs text-text-2">{m.help}</p>
                    </div>
                    <div className="min-w-0">
                    <select className={cx(inputCls(m.id === 'time' && modes.time === 'Custom' && !!customTimeErr(modes) && touched), 'w-full')} value={modes[m.id]} onChange={e => set(m, e.target.value)} aria-label={m.label}>
                      {m.options.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                    {m.id === 'time' && modes.time === 'Custom' && (() => {
                      const err = customTimeErr(modes)
                      return (
                        <div className="mt-3 rounded-md border border-border bg-background/60 p-3">
                          <div className="grid grid-cols-2 gap-3">
                            <Field label="Repeat every" required error={touched && err.startsWith('Enter') ? err : undefined}>
                              <input type="number" min={1} step={1} className={inputCls(touched && err.startsWith('Enter'))} value={modes.time_n ?? ''} onBlur={() => setTouched(true)} onChange={e => updInd(ind.id, { modes: { ...ind.modes, time_n: e.target.value } })} />
                            </Field>
                            <Field label="Unit">
                              <select className={inputCls()} value={modes.time_unit ?? 'months'} onChange={e => updInd(ind.id, { modes: { ...ind.modes, time_unit: e.target.value } })}>
                                {['weeks', 'months', 'years'].map(u => <option key={u}>{u}</option>)}
                              </select>
                            </Field>
                            <Field label="From year (optional)">
                              <input type="number" className={inputCls()} placeholder="2026" value={modes.time_from ?? ''} onChange={e => updInd(ind.id, { modes: { ...ind.modes, time_from: e.target.value } })} />
                            </Field>
                            <Field label="To year (optional)" error={touched && err.startsWith('End') ? err : undefined}>
                              <input type="number" className={inputCls(touched && err.startsWith('End'))} placeholder="2035" value={modes.time_to ?? ''} onBlur={() => setTouched(true)} onChange={e => updInd(ind.id, { modes: { ...ind.modes, time_to: e.target.value } })} />
                            </Field>
                          </div>
                          <p className="mt-2 text-[11px] text-text-3">Open question: custom granularity, date range, or both. Fields shown cover both until confirmed.</p>
                        </div>
                      )
                    })()}
                    </div>
                    <div className="@xl:col-span-2"><BridgeNote id={m.id} /></div>
                  </div>
                )
              })}
            </div>
            <div className="mt-6 rounded-md border border-border bg-background/60 p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-text-3">Selected configuration</p>
              <dl className="mt-2 flex flex-wrap gap-x-5 gap-y-1.5 text-[13px]">
                {groups.map(m => <div key={m.id} className="flex gap-1.5"><dt className="text-text-3">{m.label}</dt><dd className="font-semibold">{modes[m.id] === 'Custom' && m.id === 'time' ? `Every ${modes.time_n || '?'} ${modes.time_unit ?? 'months'}${modes.time_from || modes.time_to ? ` · ${modes.time_from || '…'}–${modes.time_to || '…'}` : ''}` : modes[m.id] || '—'}</dd></div>)}
              </dl>
            </div>
            <p className="mt-4 text-xs text-text-3">Mode list and labels follow the taxonomy working draft. Selections are kept when you move between steps.</p>
          </div>
        )}
      </div>
    </section>
  )
}


const needArch = (go: (n: number) => void, name: string) => (
  <EmptyState icon={<Layers size={18} />} title={`No archetype for ${name || 'this indication'}`} action={<Btn size="sm" onClick={() => go(2)}>Choose an archetype</Btn>}>Buckets, modules and assumptions all come from the archetype.</EmptyState>
)

/* ───────────────────────── Step 4 · Modules ───────────────────────── */



type ModFilter = 'All' | 'Attached' | 'Core' | 'Optional'

function StageModules({ c, ind, update, updInd, go, errs, fix }: Ctx & { errs?: Issue[] }) {
  const [mapOpen, setMapOpen] = useState(false)
  const [openB, setOpenB] = useState<Set<string>>(() => new Set(BUCKETS.slice(0, 1)))
  const [lockInfo, setLockInfo] = useState<Mod | null>(null)
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<ModFilter>('All')
  const arch = ind.arch
  const req = requiredFor(arch)
  const conflicts = (errs || []).filter(e => e.ind === ind.id && e.field === 'needs')
  const toggle = (m: Mod) => updInd(ind.id, { modules: ind.modules.includes(m.id) ? ind.modules.filter(x => x !== m.id) : [...ind.modules, m.id] })
  const shared = (m: Mod) => (m.data === 'price' && c.shared.price) || (m.data === 'g2n' && c.shared.g2n)
  const valid = arch ? MODULES.filter(m => validFor(m, arch)) : []
  const hidden = MODULES.length - valid.length
  const attached = valid.filter(m => ind.modules.includes(m.id) || req.includes(m.id))
  const invalidOn = arch ? MODULES.filter(m => ind.modules.includes(m.id) && !validFor(m, arch)) : []
  const term = q.trim().toLowerCase()
  const shown = (m: Mod) => {
    const on = ind.modules.includes(m.id) || req.includes(m.id)
    if (filter === 'Attached' && !on) return false
    if (filter === 'Core' && !req.includes(m.id)) return false
    if (filter === 'Optional' && req.includes(m.id)) return false
    return !term || `${m.name} ${m.desc} ${m.cat}`.toLowerCase().includes(term)
  }
  const searching = !!term || filter !== 'All'
  const seq = ind.modules.map(id => valid.find(m => m.id === id)).filter((m): m is Mod => !!m)
  const move = (k: number, d: number) => {
    const ids = seq.map(m => m.id); [ids[k], ids[k + d]] = [ids[k + d], ids[k]]
    updInd(ind.id, { modules: [...ids, ...ind.modules.filter(id => !ids.includes(id))] })
  }

  return (
    <div className="@container space-y-5">
    <div className="grid items-start gap-5 @2xl:grid-cols-[minmax(0,1fr)_300px]">
    <section className="min-w-0 overflow-hidden rounded-lg border border-border bg-surface">
      <StreamList c={c} ind={ind} update={update} tabs
        sub={i => !i.arch ? ['No archetype yet', false] : [`${i.modules.length} modules`, i.modules.length > 0]} />

      <div className="@container min-w-0 space-y-4 p-5">
        {!arch ? (
          <EmptyState icon={<Layers size={18} />} title={`No archetype for ${ind.name || 'this stream'}`} action={<Btn size="sm" onClick={() => go(2)}>Choose an archetype</Btn>}>Buckets and modules come from the archetype.</EmptyState>
        ) : (
          <>
            <div className="border-b border-border pb-4">
              <h3 className="text-lg font-bold tracking-tight text-text">{ind.name || 'Stream'}</h3>
              <p className="mt-0.5 text-sm text-text-2">{archName(arch)} <span className="text-text-3">({ind.engine})</span></p>
            </div>

            {conflicts.map(e => <Banner key={e.msg} tone="err" title="Module conflict" action={<FixForMe onClick={() => fix([4])} />}>{e.msg}</Banner>)}
            {invalidOn.length > 0 && (
              <Banner tone="err" title={`${invalidOn.length} attached module${invalidOn.length > 1 ? 's aren’t' : ' isn’t'} valid for ${archName(arch)}`}
                action={<div className="flex shrink-0 gap-2"><FixForMe onClick={() => fix([4])} /><Btn size="sm" variant="secondary" onClick={() => updInd(ind.id, { modules: ind.modules.filter(id => !invalidOn.some(m => m.id === id)) })}>Remove</Btn></div>}>
                {invalidOn.map(m => m.name).join(', ')}
              </Banner>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[200px] flex-1">
                <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-3" />
                <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search modules" aria-label="Search modules" className={cx(inputCls(), 'pl-9')} />
              </div>
              <div className="inline-flex flex-wrap rounded-md border border-border-strong bg-surface p-0.5" role="radiogroup" aria-label="Filter modules">
                {(['All', 'Attached', 'Core', 'Optional'] as ModFilter[]).map(f => (
                  <button type="button" key={f} role="radio" aria-checked={filter === f} onClick={() => setFilter(f)}
                    className={cx('rounded px-2.5 py-1.5 text-[13px] font-medium transition-colors', filter === f ? 'bg-text text-white' : 'text-text-2 hover:text-text')}>{f}</button>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-text-3">
              <span>{valid.length} modules valid for {archName(arch)} across {BUCKETS.length} buckets{hidden ? ` · ${hidden} not applicable are hidden` : ''}</span>
              {!searching && <button type="button" className="font-semibold text-brand hover:underline" onClick={() => setOpenB(openB.size === BUCKETS.length ? new Set() : new Set(BUCKETS))}>{openB.size === BUCKETS.length ? 'Collapse all' : 'Expand all'}</button>}
            </div>

            <div className="space-y-2.5">
              {BUCKETS.map((b, bi) => {
                const all = valid.filter(m => m.cat === b)
                const list = all.filter(shown)
                if (!list.length) return null
                const on = all.filter(m => ind.modules.includes(m.id) || req.includes(m.id)).length
                const bad = all.some(m => ind.modules.includes(m.id) && m.needs && !ind.modules.includes(byName(m.needs).id))
                const isOpen = searching || openB.has(b)
                return (
                  <section key={b} className="overflow-hidden rounded-lg border border-border bg-surface">
                    <button type="button" aria-expanded={isOpen} aria-controls={`bucket-${bi}`} disabled={searching}
                      onClick={() => setOpenB(prev => { const n = new Set(prev); n.has(b) ? n.delete(b) : n.add(b); return n })}
                      className={cx('flex w-full items-center gap-3 px-4 py-3 text-left outline-none transition-colors focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand disabled:cursor-default', isOpen ? 'bg-brand-dark text-white' : 'hover:bg-surface-2')}>
                      <span className={cx('font-mono text-xs font-semibold', isOpen ? 'text-white/70' : 'text-text-3')}>{String(bi + 1).padStart(2, '0')}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-bold leading-snug">{b}</span>
                        <span className={cx('block text-[11px]', isOpen ? 'text-white/65' : 'text-text-3')}>{all.length} module{all.length > 1 ? 's' : ''}{searching ? ` · ${list.length} match` : ''}</span>
                      </span>
                      {bad && <AlertCircle size={15} className="shrink-0 text-[#fca5a5]" aria-label="Has a conflict" />}
                      <span className={cx('shrink-0 rounded-full px-2 py-0.5 font-mono text-[11px] tabular-nums', isOpen ? 'bg-white/15' : on ? 'bg-brand-soft text-brand' : 'bg-surface-2 text-text-3')}>{on}/{all.length}</span>
                      {!searching && <ChevronDown size={17} className={cx('shrink-0 transition-transform', isOpen && 'rotate-180')} />}
                    </button>
                    {isOpen && (
                      <div id={`bucket-${bi}`} role="group" aria-label={b} className="grid gap-2 bg-background/60 p-3 @xl:grid-cols-2">
                        {list.map(m => {
                          const isReq = req.includes(m.id)
                          const isOn = ind.modules.includes(m.id) || isReq
                          const govd = GOVERNED.has(m.name)
                          const missing = m.needs && isOn && !ind.modules.includes(byName(m.needs).id)
                          return (
                            <div key={m.id} className={cx('flex min-w-0 items-stretch rounded-md border transition-colors', isOn ? 'border-brand bg-brand-soft/40' : 'border-border bg-surface hover:border-border-strong')}>
                              <button type="button" role="checkbox" aria-checked={isOn} disabled={isReq} onClick={() => toggle(m)}
                                className="flex min-w-0 flex-1 items-start gap-3 px-3 py-2.5 text-left outline-none focus-visible:ring-2 focus-visible:ring-brand disabled:cursor-default">
                                <span aria-hidden className={cx('mt-0.5 grid h-4.5 w-4.5 shrink-0 place-items-center rounded border-2 transition-colors', isOn ? 'border-brand bg-brand text-white' : 'border-border-strong bg-surface')}>{isOn && <Check size={11} strokeWidth={3} />}</span>
                                <span className="min-w-0 flex-1">
                                  <span className="flex flex-wrap items-center gap-1.5">
                                    <span className="text-[13px] font-semibold text-text">{m.name}</span>
                                    {isReq ? <Badge>Core · required</Badge> : <Badge tone="neutral">Optional</Badge>}
                                  </span>
                                  <span className="mt-0.5 block text-[11px] leading-snug text-text-2">{m.desc}</span>
                                  {(govd || shared(m) || m.needs) && (
                                    <span className="mt-1.5 flex flex-wrap items-center gap-1">
                                      {govd && <Badge tone="warn"><ShieldAlert size={10} />Governed</Badge>}
                                      {shared(m) && <Badge tone="neutral">Shared · brand-level</Badge>}
                                      {m.needs && <Badge tone={missing ? 'err' : 'neutral'}>Needs {m.needs}</Badge>}
                                    </span>
                                  )}
                                </span>
                              </button>
                              {isReq && <button type="button" onClick={() => setLockInfo(m)} title="Why is this required?" aria-label={`Why is ${m.name} required?`} className="grid w-9 shrink-0 place-items-center rounded-r text-text-3 hover:bg-surface-2 hover:text-brand"><Lock size={14} /></button>}
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </section>
                )
              })}
              {searching && !valid.some(shown) && <EmptyState icon={<Search size={18} />} title="No modules match" action={<Btn size="sm" variant="secondary" onClick={() => { setQ(''); setFilter('All') }}>Clear search</Btn>}>Try another term, or switch the filter to All.</EmptyState>}
            </div>
            <p className="text-xs text-text-3">Module names, buckets and archetype mapping follow the taxonomy working draft. New modules or formula edits are version requests to the platform team.</p>
          </>
        )}
      </div>
    </section>

    {arch && (
      <aside className="min-w-0 @2xl:sticky @2xl:top-4">
        <div className="mb-5 overflow-hidden rounded-lg border border-border bg-surface">
          <div className="relative h-28 border-b border-border bg-[#f7f8fb] [background-image:linear-gradient(#e3e7ef_1px,transparent_1px),linear-gradient(90deg,#e3e7ef_1px,transparent_1px)] [background-size:16px_16px]">
            <svg viewBox="0 0 300 112" className="absolute inset-0 h-full w-full" aria-hidden>
              <path d="M70,30 C110,30 110,56 150,56" stroke="#7c3aed" strokeWidth="2" fill="none" /><path d="M70,84 C110,84 110,56 150,56" stroke="#0891b2" strokeWidth="2" fill="none" /><path d="M210,56 C235,56 235,56 250,56" stroke="#059669" strokeWidth="2" fill="none" />
              {[[14, 18], [14, 72], [150, 42], [250, 42]].map(([x, y], k) => <rect key={k} x={x} y={y} width={k > 1 ? (k === 3 ? 40 : 60) : 56} height="26" rx="5" fill="#ffffff" stroke="#cbd2de" />)}
            </svg>
          </div>
          <div className="p-4">
            <p className="text-sm font-semibold">Module map</p>
            <p className="mt-1 text-xs text-text-2">See how {ind.name || 'this stream'} is calculated: {ind.modules.length} attached modules wired from inputs to the output, in run order. Open any node for its values and connections.</p>
            <button type="button" onClick={() => setMapOpen(true)} className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-md bg-brand px-3 py-2 text-sm font-semibold text-white hover:bg-brand-dark"><Workflow size={15} />Open module map</button>
          </div>
        </div>
        <ModelFlow c={c} ind={ind} go={go} mapOnly map={mapOpen} onMap={setMapOpen} />
        {seq.length > 1 && (
          <Card title="Calculation sequence" sub="Order the modules run in. The model flow follows this order." className="mb-5">
            <ol className="space-y-1.5 p-3">
              {seq.map((m, k) => (
                <li key={m.id} className="flex items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-1.5">
                  <span className="w-5 shrink-0 font-mono text-[11px] text-text-3">{k + 1}</span>
                  <span className="min-w-0 flex-1 truncate text-[13px] font-medium" title={m.name}>{m.name}</span>
                  {m.needs && seq.findIndex(x => x.name === m.needs) > k && <span title={`Runs before ${m.needs}, which it depends on`}><AlertTriangle size={13} className="text-warn" /></span>}
                  <button type="button" disabled={k === 0} onClick={() => move(k, -1)} aria-label={`Move ${m.name} up`} className="grid h-6 w-6 place-items-center rounded text-text-2 hover:bg-surface-2 disabled:opacity-30"><ChevronDown size={14} className="rotate-180" /></button>
                  <button type="button" disabled={k === seq.length - 1} onClick={() => move(k, 1)} aria-label={`Move ${m.name} down`} className="grid h-6 w-6 place-items-center rounded text-text-2 hover:bg-surface-2 disabled:opacity-30"><ChevronDown size={14} /></button>
                </li>
              ))}
            </ol>
          </Card>
        )}
      </aside>
    )}
    </div>

    {lockInfo && (
      <div className="fixed inset-0 z-50 grid place-items-center bg-brand-dark/50 p-4" role="dialog" aria-modal="true" aria-labelledby="lock-title" onClick={() => setLockInfo(null)}>
        <div className="rise w-full max-w-md rounded-lg bg-surface p-6 shadow-xl" onClick={e => e.stopPropagation()}>
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-md bg-surface-2 text-text-2"><Lock size={17} /></span>
            <div><h2 id="lock-title" className="text-lg font-semibold">{lockInfo.name} is required</h2><p className="text-xs text-text-3">Core module · {archName(arch)}</p></div>
          </div>
          <ul className="mt-4 space-y-2 text-sm text-text-2">
            <li className="flex gap-2"><Check size={15} className="mt-0.5 shrink-0 text-brand" />The {archName(arch)} engine needs this module to calculate the forecast, so it is always on.</li>
            <li className="flex gap-2"><Check size={15} className="mt-0.5 shrink-0 text-brand" />To change it, pick a different archetype in step 2 or raise a version request with the platform team.</li>
          </ul>
          <div className="mt-6 flex justify-end gap-2">
            <Btn variant="secondary" onClick={() => { setLockInfo(null); go(2) }}>Change archetype</Btn>
            <Btn onClick={() => setLockInfo(null)}>Got it</Btn>
          </div>
        </div>
      </div>
    )}
    </div>
  )
}


/* ───────────────────────── Step 4 · Data bindings ───────────────────────── */

/** Latest vendor refresh per governed source (demo values). */
const SOURCE_REFRESH: Record<string, string> = {
  'IQVIA NPA weekly': 'Oct 2026', 'IQVIA LAAD claims': 'Sep 2026', 'Symphony PatientSource': 'Sep 2026', 'Komodo Health': 'Sep 2026', 'Internal Epi Library': 'Aug 2026',
  'UN population (WPP)': 'Jul 2026', 'Internal Pricing (Model N)': 'Oct 2026', 'SAP actuals (net sales)': 'Oct 2026', 'CDC NIS-Teen / Adult': 'Sep 2026',
}
/** Sources are bound by the platform from the governed catalogue; the configurator reviews them (no manual selection). */
const autoBinding = (b: Bound, x?: Binding): Binding => {
  const source = x?.source || b.input.suggested
  return { source, owner: x?.owner ?? '', confidence: x?.confidence ?? 'Medium', status: 'ok', msg: 'Bound automatically.', fresh: { state: 'Current', refreshed: SOURCE_REFRESH[source] ?? 'Sep 2026', boundary: 'Aug 2026', coverage: 100 } }
}

function StageData({ c, go }: Ctx) {
  const ins = inputsFor(c)
  if (!ins.length) return <EmptyState icon={<Database size={18} />} title="Nothing to bind yet" action={<Btn size="sm" onClick={() => go(2)}>Choose archetypes</Btn>}>Inputs appear once each revenue stream has an archetype.</EmptyState>
  const groups = Array.from(new Set(ins.map(b => b.scope))).map(scope => ({
    scope, label: scope === 'brand' ? 'All streams' : c.inds.find(i => i.id === scope)?.name || 'Untitled stream',
    rows: ins.filter(b => b.scope === scope),
  }))
  const refresh = (b: Bound) => { const x = c.bindings[b.key]; return x?.source ? SOURCE_REFRESH[x.source] ?? x.fresh?.refreshed ?? '—' : '—' }

  return (
    <>
      <Banner tone="info" title="Governed sources are bound automatically">
        The platform binds each input to its governed source for the stream it feeds. Review what each input draws from and when it was last refreshed, then continue.
      </Banner>
      <div className="overflow-x-auto rounded-lg border border-border bg-surface">
        <table className="w-full min-w-[560px] text-sm">
          <thead>
            <tr className="border-b border-border bg-background/60 text-left text-xs uppercase tracking-wide text-text-3">
              <th scope="col" className="w-[44%] px-4 py-3 font-semibold">Input</th>
              <th scope="col" className="px-4 py-3 font-semibold">Source</th>
              <th scope="col" className="w-[150px] px-4 py-3 font-semibold">Latest refresh</th>
            </tr>
          </thead>
          {groups.map(g => (
            <tbody key={g.scope}>
              {groups.length > 1 && (
                <tr className="border-b border-border bg-surface-2/60">
                  <th scope="rowgroup" colSpan={3} className="px-4 py-2 text-left text-xs font-semibold text-text">
                    {g.label}<span className="ml-2 font-normal text-text-3">{g.scope === 'brand' ? 'Shared across every revenue stream' : `${g.rows.length} input${g.rows.length > 1 ? 's' : ''}`}</span>
                  </th>
                </tr>
              )}
              {g.rows.map(b => (
                <tr key={b.key} className="border-b border-border last:border-0">
                  <td className="px-4 py-3"><p className="font-medium text-text">{b.input.name}</p><p className="text-xs text-text-3">Feeds {b.input.feeds}</p></td>
                  <td className="px-4 py-3 text-text">{c.bindings[b.key]?.source || <span className="text-text-3">Binding…</span>}</td>
                  <td className="px-4 py-3 tabular-nums text-text-2">{refresh(b)}</td>
                </tr>
              ))}
            </tbody>
          ))}
        </table>
      </div>
    </>
  )
}

/* ───────────────────────── Step 5 · Assumptions & governance ───────────────────────── */

const CONF_CLS: Record<string, string> = { High: 'bg-[#d6efef] text-[#1d6b6b]', Medium: 'bg-[#dbeafe] text-[#1e3a8a]', Low: 'bg-[#ede9fe] text-[#5b21b6]' }
type RegFilter = 'All' | 'CoE-locked' | 'Forecaster-editable' | 'Needs info' | 'Low confidence'

function SetByPill({ open }: { open: boolean }) {
  return open
    ? <span className="inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-[#d6efef] px-2 py-0.5 text-[11px] font-bold text-[#1d6b6b]"><LockOpen size={10} />Forecaster</span>
    : <span className="inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-brand-dark px-2 py-0.5 text-[11px] font-bold text-white"><Lock size={10} />CoE-locked</span>
}

function StagePerms({ c, ind, update, updInd, go, errs, fix, notify }: Ctx & { errs: Issue[] }) {
  const [filter, setFilter] = useState<RegFilter>('All')
  const [view, setView] = useState<'CoE configurator' | 'Forecaster preview'>('CoE configurator')
  const [openRow, setOpenRow] = useState<string | null>(null)
  if (!ind.arch) return needArch(go, ind.name)
  const arch = ind.arch
  const setP = (id: string, patch: Partial<Perm>) => updInd(ind.id, { perms: { ...ind.perms, [id]: { ...ind.perms[id], ...patch } } })
  const AS = assumptionsFor(arch).filter(a => ind.perms[a.id])
  const open = AS.filter(a => ind.perms[a.id].open).length
  const gaps = AS.filter(a => missingMeta(ind.perms[a.id])).length
  const fill = () => updInd(ind.id, { perms: Object.fromEntries(Object.entries(ind.perms).map(([k, p]) => [k, missingMeta(p) ? { ...p, owner: p.owner || ASSUMPTION_OWNERS[0], source: p.source || ASSUMPTION_SOURCES[0], confidence: p.confidence || 'Medium' } : p])) })
  const rowErr = (id: string) => errs.find(x => x.field === `${ind.id}:${id}`)
  const match = (a: Assumption) => {
    const p = ind.perms[a.id]
    return filter === 'All' || (filter === 'CoE-locked' ? !p.open : filter === 'Forecaster-editable' ? p.open : filter === 'Needs info' ? missingMeta(p) || outOfBand(p) : p.confidence === 'Low')
  }
  const rows = AS.filter(match)
  const fc = view === 'Forecaster preview'
  const fEdits = AS.filter(a => ind.perms[a.id].fval !== undefined && ind.perms[a.id].fval !== ind.perms[a.id].value).length
  const cols = '@3xl:grid-cols-[minmax(0,1.7fr)_minmax(0,0.9fr)_118px_minmax(0,1fr)_minmax(0,1.1fr)_84px_32px]'

  return (
    <>
      {open === 0 && <Banner tone="warn" title="Forecasters can’t change anything">Every assumption is CoE-locked, so the handed-over model is read-only. Open at least the share path.</Banner>}
      {c.cascade.length > 0 && ind.id === c.inds[0].id && (
        <Card title="Share cascade" sub="Nested shares multiply. The product is the brand’s share of patients." right={<Badge tone={cascadeTotal(c) > 100 ? 'err' : 'ok'}>{cascadeTotal(c)}% total</Badge>}>
          <div className="flex flex-wrap items-center gap-2">
            {c.cascade.map((v, k) => (
              <span key={k} className="flex items-center gap-2">
                {k > 0 && <X size={12} className="text-text-3" />}
                <label className="flex items-center gap-1.5 text-xs text-text-2">{['Class', 'Sub-class', 'Brand'][k] ?? `Level ${k + 1}`}
                  <input type="number" value={v} onChange={e => update({ cascade: c.cascade.map((x, j) => j === k ? Number(e.target.value) : x) })} className={cx(inputCls(v > 100), 'h-8 w-20')} />%</label>
              </span>
            ))}
          </div>
          {cascadeTotal(c) > 100 && <div className="mt-2 flex flex-wrap items-center justify-between gap-2"><p className="flex items-center gap-1 text-xs text-err"><AlertCircle size={12} />A level above 100% pushes share past the whole market. Each level is a share of the one before.</p><FixForMe onClick={() => fix([3])} /></div>}
        </Card>
      )}
      {gaps > 0 && !fc && <Banner tone="err" title={`${gaps} row${gaps > 1 ? 's need' : ' needs'} an owner, source and confidence`} action={<div className="flex shrink-0 gap-2"><FixForMe onClick={() => fix([6])} /><Btn size="sm" variant="secondary" onClick={fill}>Fill with defaults</Btn></div>}>Every number in the register needs a documented owner, source and confidence rating.</Banner>}

      {!fc && (() => {
        const owners = Array.from(new Set(AS.map(a => ind.perms[a.id]?.owner).filter(Boolean)))
        const pending = owners.filter(o => !c.notified.includes(`${ind.id}:${o}`))
        return owners.length > 0 && (
          <Card title="Assumption owners" sub="Each row is owned by a business function. Owners are notified, update their rows, and every change is versioned." right={<Btn size="sm" variant="secondary" icon={<Bell size={14} />} disabled={!pending.length} onClick={() => { update({ notified: [...c.notified, ...pending.map(o => `${ind.id}:${o}`)] }); notify({ tone: 'ok', text: `Notified ${pending.map(o => OWNER_CONTACT[o] ?? o).join(', ')}.` }) }}>{pending.length ? `Notify ${pending.length} owner${pending.length > 1 ? 's' : ''}` : 'All notified'}</Btn>}>
            <ul className="flex flex-wrap gap-2">
              {owners.map(o => {
                const n = AS.filter(a => ind.perms[a.id]?.owner === o).length
                const sent = c.notified.includes(`${ind.id}:${o}`)
                return <li key={o} className="flex items-center gap-2 rounded-full border border-border px-3 py-1 text-[13px]"><span className="font-semibold">{o}</span><span className="text-text-3">{OWNER_CONTACT[o] ?? ''} · {n} row{n > 1 ? 's' : ''}</span>{sent ? <Badge tone="ok"><Check size={10} />Notified</Badge> : <Badge tone="neutral">Not notified</Badge>}</li>
              })}
            </ul>
          </Card>
        )
      })()}
      <Card title="Assumptions register" sub={`${ind.name || 'Stream'} · ${archName(arch)}. Every slot the model uses, who sets it, and whether forecasters may change it after handoff.`}
        right={<div className="flex flex-wrap items-center gap-2"><Badge tone="brand">{open} editable · {AS.length - open} locked</Badge></div>}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex flex-wrap rounded-md border border-border-strong bg-surface p-0.5" role="radiogroup" aria-label="Filter register">
            {(['All', 'CoE-locked', 'Forecaster-editable', 'Needs info', 'Low confidence'] as RegFilter[]).map(f => {
              const n = AS.filter(a => f === 'All' || (f === 'CoE-locked' ? !ind.perms[a.id].open : f === 'Forecaster-editable' ? ind.perms[a.id].open : f === 'Needs info' ? missingMeta(ind.perms[a.id]) || outOfBand(ind.perms[a.id]) : ind.perms[a.id].confidence === 'Low')).length
              return (
                <button type="button" key={f} role="radio" aria-checked={filter === f} onClick={() => setFilter(f)}
                  className={cx('rounded px-2.5 py-1.5 text-[12px] font-medium transition-colors', filter === f ? 'bg-text text-white' : 'text-text-2 hover:text-text')}>{f} <span className="opacity-60">{n}</span></button>
              )
            })}
          </div>
          <div className="flex items-center gap-2 text-xs text-text-2"><span className="hidden @xl:inline">View as</span><Segmented value={view} options={['CoE configurator', 'Forecaster preview']} onChange={v => setView(v as typeof view)} /></div>
        </div>
        {fc && <div className="mt-3"><Banner tone="info" title="Forecaster preview">This is what the forecaster gets after handoff: CoE-locked rows are read-only; editable rows accept values inside the band. Preview edits are flagged and don’t change the CoE baseline.{fEdits > 0 && <> <b>{fEdits} forecaster edit{fEdits > 1 ? 's' : ''}</b> in this preview.</>}</Banner></div>}

        <div className={cx('mt-4 hidden gap-3 border-b border-border px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-text-3 @3xl:grid', cols)}>
          <span>Assumption</span><span>Value</span><span>Set by</span><span>Owner</span><span>Source</span><span>Confidence</span><span />
        </div>
        <ul className="mt-2 space-y-2 @3xl:mt-0 @3xl:space-y-0 @3xl:divide-y @3xl:divide-border">
          {rows.map(a => {
            const p = ind.perms[a.id]
            const meta = assumptionMeta(a, arch)
            const e = rowErr(a.id)
            const bad = missingMeta(p) || outOfBand(p)
            const edited = p.value !== a.base
            const fEdited = p.fval !== undefined && p.fval !== p.value
            const isOpen = openRow === a.id && !fc
            const lbl = (t: string) => <span className="text-[10px] font-semibold uppercase tracking-wider text-text-3 @3xl:hidden">{t}</span>
            return (
              <li key={a.id} className={cx('rounded-md border @3xl:rounded-none @3xl:border-0', bad && !fc ? 'border-err/40 bg-err-soft/25' : 'border-border')}>
                <div className={cx('grid grid-cols-2 items-center gap-x-3 gap-y-2 px-3 py-3', cols)}>
                  <div className="col-span-2 min-w-0 @3xl:col-span-1">
                    <p className="text-[13px] font-semibold leading-snug">{a.name}</p>
                    <p className="text-[11px] text-text-3">{meta.cat} · feeds {meta.feeds}</p>
                    <span className="mt-1 flex flex-wrap gap-1">
                      {edited && !fc && <Badge tone="brand"><History size={10} />Edited · was {a.base}</Badge>}
                      {fEdited && <Badge tone="warn"><Users size={10} />Forecaster edit</Badge>}
                      {bad && !fc && <Badge tone="err"><AlertCircle size={10} />Needs info</Badge>}
                    </span>
                  </div>
                  <div className="min-w-0">
                    {lbl('Value')}
                    {fc && p.open ? (
                      <span className="flex items-center gap-1">
                        <input type="number" aria-label={`${a.name} forecaster value`} value={p.fval ?? p.value} min={p.min} max={p.max}
                          onChange={ev => { const v = Number(ev.target.value); setP(a.id, { fval: Math.min(p.max, Math.max(p.min, v)) }) }}
                          className={cx(inputCls(), 'h-8 w-20 px-2 tabular-nums')} />
                        <span className="text-[11px] text-text-3">{a.unit}</span>
                      </span>
                    ) : (
                      <p className="text-[13px] tabular-nums"><b>{p.value}</b> <span className="text-[11px] text-text-3">{a.unit}</span></p>
                    )}
                    {p.open && <p className="text-[11px] text-text-3">Band {p.min}–{p.max}</p>}
                  </div>
                  <div className="min-w-0">{lbl('Set by')}<div><SetByPill open={p.open} /></div></div>
                  <div className="min-w-0">{lbl('Owner')}<p className={cx('truncate text-[13px]', !p.owner && 'text-err')}>{p.owner || 'Missing'}</p></div>
                  <div className="min-w-0">{lbl('Source')}<p className={cx('truncate text-[13px]', !p.source && 'text-err')} title={p.source}>{p.source || 'Missing'}</p></div>
                  <div className="min-w-0">{lbl('Confidence')}<div>{p.confidence ? <span className={cx('inline-block rounded-full px-2 py-0.5 text-[11px] font-bold', CONF_CLS[p.confidence])}>{p.confidence}</span> : <span className="text-[13px] text-err">Missing</span>}</div></div>
                  <div className="col-span-2 flex justify-end @3xl:col-span-1">
                    {fc ? (fEdited ? <button type="button" onClick={() => setP(a.id, { fval: undefined })} className="text-xs font-semibold text-brand hover:underline" title="Reset to CoE default"><RotateCcw size={14} /><span className="sr-only">Reset</span></button> : !p.open && <Lock size={14} className="text-text-3" aria-label="Locked" />)
                      : <button type="button" aria-expanded={isOpen} onClick={() => setOpenRow(isOpen ? null : a.id)} aria-label={`Edit ${a.name}`}
                          className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs font-semibold text-brand hover:bg-brand-soft"><span className="@3xl:sr-only">Edit</span><ChevronDown size={15} className={cx('transition-transform', isOpen && 'rotate-180')} /></button>}
                  </div>
                </div>
                {e && !fc && !isOpen && <p className="px-3 pb-2 text-xs text-err">{e.msg.split(': ').slice(1).join(': ')}</p>}
                {isOpen && (
                  <div className="mx-3 mb-3 rounded-md bg-background p-3">
                    <div className="grid gap-3 @xl:grid-cols-2 @3xl:grid-cols-4">
                      <Field label="Set by" className="@xl:col-span-2">
                        <Segmented value={p.open ? 'Forecaster-editable' : 'CoE-locked'} options={['CoE-locked', 'Forecaster-editable']} onChange={v => setP(a.id, { open: v === 'Forecaster-editable' })} />
                      </Field>
                      <Field label={`Default value (${a.unit})`}>
                        <input type="number" value={p.value} onChange={ev => setP(a.id, { value: Number(ev.target.value) })} className={cx(inputCls(outOfBand(p)), 'tabular-nums')} />
                      </Field>
                      {p.open ? (
                        <Field label="Editable band" error={outOfBand(p) ? 'Default must sit inside the band' : undefined}>
                          <span className="flex items-center gap-1.5">
                            <input type="number" aria-label={`${a.name} minimum`} value={p.min} onChange={ev => setP(a.id, { min: Number(ev.target.value) })} className={cx(inputCls(outOfBand(p)), 'px-2')} />
                            <span className="text-text-3">–</span>
                            <input type="number" aria-label={`${a.name} maximum`} value={p.max} onChange={ev => setP(a.id, { max: Number(ev.target.value) })} className={cx(inputCls(outOfBand(p)), 'px-2')} />
                          </span>
                        </Field>
                      ) : <div className="hidden @3xl:block" />}
                      <Field label="Owner" required><select className={inputCls(!p.owner)} value={p.owner} onChange={ev => setP(a.id, { owner: ev.target.value })}><option value="">Choose…</option>{ASSUMPTION_OWNERS.map(o => <option key={o}>{o}</option>)}</select></Field>
                      <Field label="Source" required><select className={inputCls(!p.source)} value={p.source} onChange={ev => setP(a.id, { source: ev.target.value })}><option value="">Choose…</option>{ASSUMPTION_SOURCES.map(o => <option key={o}>{o}</option>)}</select></Field>
                      <Field label="Confidence" required><select className={inputCls(!p.confidence)} value={p.confidence} onChange={ev => setP(a.id, { confidence: ev.target.value as Perm['confidence'] })}><option value="">Choose…</option>{['High', 'Medium', 'Low'].map(o => <option key={o}>{o}</option>)}</select></Field>
                      {p.open ? <Field label="Grain"><select className={inputCls()} value={p.grain} onChange={ev => setP(a.id, { grain: ev.target.value })}>{['Monthly', 'Quarterly', 'Annual', 'One value'].map(g => <option key={g}>{g}</option>)}</select></Field> : <div className="hidden @3xl:block" />}
                      <Field label="Notes / rationale" className="@xl:col-span-2 @3xl:col-span-4">
                        <input className={inputCls()} value={p.notes} onChange={ev => setP(a.id, { notes: ev.target.value })} placeholder="Why this value, and what would change it" />
                      </Field>
                    </div>
                    <p className="mt-2 flex items-center gap-1.5 text-[11px] text-text-3"><History size={11} />{edited ? `Default changed ${a.base} → ${p.value} ${a.unit} by ${ME} · today` : 'At CoE default · no changes'}</p>
                  </div>
                )}
              </li>
            )
          })}
          {rows.length === 0 && <li className="py-8 text-center text-sm text-text-2">No rows match this filter.</li>}
        </ul>
      </Card>
    </>
  )
}


/* ───────────────────────── Step 7 · Baseline forecast ───────────────────────── */

const ARCH_SCALE: Record<ArchId, number> = { 'D-01': 1, 'D-02': 0.72, 'D-03': 1, 'D-04': 0.85, 'D-05': 1.45, 'D-06': 0.3, 'D-07': 1.2 }
const RAMP = [0.12, 0.49, 0.77, 0.93, 1]
const YEARS = ['Y1', 'Y2', 'Y3', 'Y4', 'Y5']

/** Illustrative only: the engine's calculation logic is pending from forecasting & engineering. Driven by the configured archetype and governed values. */
function computeBaseline(c: Config): BaseRow[] {
  return c.inds.filter(i => i.arch).map((i, k) => {
    const arch = i.arch!
    const eng = ENGINE_ASSUMPTIONS[arch].map(a => a.base ? Math.max((i.perms[a.id]?.value ?? a.base) / a.base, 0.05) : 1)
    const engF = Math.pow(eng.reduce((p, x) => p * x, 1), 1 / Math.max(eng.length, 1))
    const g2n = i.perms.g2n?.value ?? 38, price = i.perms.price?.value ?? 4.5
    const peak = 580 * ARCH_SCALE[arch] * (k === 0 ? 1 : 0.45) * engF * (1 - g2n / 100) / 0.62
    return { id: i.id, name: i.name || `Stream ${k + 1}`, eng: archName(arch), v: RAMP.map((r, j) => Math.max(0, Math.round(peak * r * Math.pow(1 + (price - 4.5) / 100, j)))) }
  })
}

const STREAM_CLS = ['bg-brand', 'bg-[#4aa8a8]', 'bg-[#8b5cf6]', 'bg-[#f59e0b]', 'bg-[#64748b]']

const STREAM_HEX = ['#0000c9', '#4aa8a8', '#8b5cf6', '#f59e0b', '#64748b']
const STREAM_MARK = ['circle', 'square', 'triangle', 'diamond', 'circle'] as const

function SeriesMark({ x, y, kind, color }: { x: number; y: number; kind: typeof STREAM_MARK[number]; color: string }) {
  const p = { fill: '#fff', stroke: color, strokeWidth: 2 }
  if (kind === 'square') return <rect x={x - 4} y={y - 4} width={8} height={8} {...p} />
  if (kind === 'triangle') return <path d={`M${x} ${y - 5}L${x + 5} ${y + 4}H${x - 5}Z`} {...p} />
  if (kind === 'diamond') return <path d={`M${x} ${y - 5}L${x + 5} ${y}L${x} ${y + 5}L${x - 5} ${y}Z`} {...p} />
  return <circle cx={x} cy={y} r={4} {...p} />
}

/** Multi-series line chart: one line per revenue stream plus a dashed brand total. Used on Review. */
function BaselineLineChart({ rows, brand }: { rows: BaseRow[]; brand: string }) {
  const [hover, setHover] = useState<number | null>(null)
  const tot = YEARS.map((_, j) => rows.reduce((a, r) => a + r.v[j], 0))
  const W = 640, H = 260, L = 56, R = 16, T = 16, B = 36
  const step = 100 * Math.pow(10, Math.max(0, Math.floor(Math.log10(Math.max(...tot, 1))) - 2))
  const max = Math.ceil(Math.max(...tot, 1) / (step * 4)) * step * 4
  const ticks = [0, 1, 2, 3, 4].map(k => (max / 4) * k)
  const x = (j: number) => L + (j * (W - L - R)) / (YEARS.length - 1)
  const y = (v: number) => T + (H - T - B) * (1 - v / max)
  const path = (v: number[]) => v.map((n, j) => `${j ? 'L' : 'M'}${x(j)} ${y(n)}`).join('')
  const fmt = (n: number) => `$${n.toLocaleString()}M`
  const name = brand || 'Brand'
  return (
    <figure>
      <div className="relative">
        <svg viewBox={`0 0 ${W} ${H}`} className="block h-auto w-full" role="img" onMouseLeave={() => setHover(null)}
          aria-label={`Net revenue by year. ${rows.map(r => `${r.name}: ${r.v.map((v, j) => `${YEARS[j]} ${fmt(v)}`).join(', ')}`).join('. ')}. ${name} total: ${tot.map((t, j) => `${YEARS[j]} ${fmt(t)}`).join(', ')}.`}>
          {ticks.map(t => (
            <g key={t}>
              <line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke="var(--color-border)" strokeDasharray={t ? '3 4' : undefined} />
              <text x={L - 8} y={y(t)} dy="0.32em" textAnchor="end" fontSize="11" fill="var(--color-text-3)">${t.toLocaleString()}M</text>
            </g>
          ))}
          {YEARS.map((yr, j) => <text key={yr} x={x(j)} y={H - B + 20} textAnchor="middle" fontSize="11" fill="var(--color-text-3)">{yr}</text>)}
          {hover !== null && <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} stroke="var(--color-border-strong)" />}
          <path d={path(tot)} fill="none" stroke="var(--color-text)" strokeWidth={2} strokeDasharray="6 4" />
          {rows.map((r, k) => <path key={r.id} d={path(r.v)} fill="none" stroke={STREAM_HEX[k % STREAM_HEX.length]} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />)}
          {tot.map((t, j) => <circle key={j} cx={x(j)} cy={y(t)} r={3} fill="var(--color-text)" />)}
          {rows.map((r, k) => r.v.map((v, j) => <SeriesMark key={`${r.id}${j}`} x={x(j)} y={y(v)} kind={STREAM_MARK[k % STREAM_MARK.length]} color={STREAM_HEX[k % STREAM_HEX.length]} />))}
          {YEARS.map((yr, j) => <rect key={yr} x={x(j) - (W - L - R) / 8} y={T} width={(W - L - R) / 4} height={H - T - B} fill="transparent" onMouseEnter={() => setHover(j)} />)}
        </svg>
        {hover !== null && (
          <div className="pointer-events-none absolute top-2 z-10 min-w-[180px] rounded-md border border-border bg-surface px-3 py-2 text-xs shadow-lg"
            style={{ left: `${(x(hover) / W) * 100}%`, transform: hover >= YEARS.length - 2 ? 'translateX(calc(-100% - 12px))' : 'translateX(12px)' }}>
            <p className="mb-1 font-semibold text-text">{YEARS[hover]} · net revenue</p>
            {rows.map((r, k) => <p key={r.id} className="flex items-center justify-between gap-4"><span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: STREAM_HEX[k % STREAM_HEX.length] }} />{r.name}</span><span className="tabular-nums">{fmt(r.v[hover])}</span></p>)}
            <p className="mt-1 flex justify-between gap-4 border-t border-border pt-1 font-semibold"><span>{name} total</span><span className="tabular-nums">{fmt(tot[hover])}</span></p>
          </div>
        )}
      </div>
      <figcaption className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-text-2">
        {rows.map((r, k) => (
          <span key={r.id} className="flex items-center gap-1.5">
            <svg width="22" height="10" aria-hidden><line x1="0" x2="22" y1="5" y2="5" stroke={STREAM_HEX[k % STREAM_HEX.length]} strokeWidth="2.5" /><SeriesMark x={11} y={5} kind={STREAM_MARK[k % STREAM_MARK.length]} color={STREAM_HEX[k % STREAM_HEX.length]} /></svg>
            {r.name} · {r.eng}
          </span>
        ))}
        <span className="flex items-center gap-1.5"><svg width="22" height="10" aria-hidden><line x1="0" x2="22" y1="5" y2="5" stroke="var(--color-text)" strokeWidth="2" strokeDasharray="5 3" /></svg>{name} total</span>
      </figcaption>
    </figure>
  )
}

function BaselineTable({ rows, brand }: { rows: BaseRow[]; brand: string }) {
  const tot = YEARS.map((_, j) => rows.reduce((a, r) => a + r.v[j], 0))
  const sum = (v: number[]) => v.reduce((a, b) => a + b, 0)
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[520px] text-[13px]">
        <thead><tr className="border-b border-border text-[11px] font-semibold uppercase tracking-wider text-text-2">
          <th className="py-2 pl-2 text-left">Net revenue ($M)</th>{[...YEARS, '5-yr'].map(h => <th key={h} className="py-2 pr-2 text-right">{h}</th>)}</tr></thead>
        <tbody>
          {rows.map((r, k) => (
            <tr key={r.id} className={cx(k % 2 === 1 && 'bg-background')}>
              <td className="py-2.5 pl-2"><span className="flex items-center gap-2"><span className={cx('h-2.5 w-2.5 shrink-0 rounded-sm', STREAM_CLS[k % STREAM_CLS.length])} /><span className="min-w-0">{r.name} <span className="text-text-3">· {r.eng}</span></span></span></td>
              {r.v.map((v, j) => <td key={j} className="py-2.5 pr-2 text-right tabular-nums">{v.toLocaleString()}</td>)}<td className="py-2.5 pr-2 text-right tabular-nums">{sum(r.v).toLocaleString()}</td>
            </tr>
          ))}
          <tr className="border-t-2 border-brand font-bold">
            <td className="py-2.5 pl-2">{brand || 'Brand'} total</td>{tot.map((v, j) => <td key={j} className="py-2.5 pr-2 text-right tabular-nums">{v.toLocaleString()}</td>)}<td className="py-2.5 pr-2 text-right tabular-nums">{sum(tot).toLocaleString()}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

/* ───────────────────────── Step 8 · Review ───────────────────────── */

function EditLink({ stage, go }: { stage: number; go: (n: number) => void }) {
  return <button type="button" onClick={() => go(stage)} className="shrink-0 text-xs font-semibold text-brand hover:underline">Edit<span className="sr-only"> {STAGES[stage - 1].title}</span></button>
}

/** Calculation-chain tones, grouped by the role a node plays in the calculation (start → funnel → share → regimen → adjustments → revenue). */
const CHAIN_TONE = {
  start: 'border-brand-dark bg-brand-dark text-white',
  engine: 'border-brand/25 bg-brand-soft text-brand-dark',
  funnel: 'border-[#cfdcf3] bg-[#eef4fd] text-[#1e3a8a]',
  share: 'border-[#bfe3ef] bg-[#e7f6fb] text-[#0e6a85]',
  regimen: 'border-[#ddd3fb] bg-[#f4f0ff] text-[#5b21b6]',
  adjust: 'border-[#f0d9ad] bg-warn-soft text-warn',
  gross: 'border-[#bfe5d1] bg-ok-soft text-ok',
  end: 'border-ok bg-ok text-white',
} as const
type ChainTone = keyof typeof CHAIN_TONE
const BUCKET_TONE: Record<string, ChainTone> = {
  'Population & top-of-funnel': 'funnel', 'Segmentation & structure': 'funnel', 'Lines of therapy & disease states': 'funnel',
  'Share machinery': 'share', 'Persistence, dosing & regimen': 'regimen',
  'Cross-product & franchise': 'adjust', 'Events, LOE & scenarios': 'adjust', 'Actuals, calibration & reconciliation': 'adjust',
  'Conversion, financial & integration': 'gross',
}
// Attached modules that don't change the numbers (reporting, sync, tooling) sit outside the chain.
const OFF_CHAIN = new Set(['Presentation export', 'Submission & sync machinery', 'Versioning & documentation', 'Automated report generation', 'Porting & migration suites', 'Scenario comparison reporting', 'Scenario management'])
const NET_MODULES = new Set(['Gross-to-net engines', 'Parallel trade'])

type FlowParam = { k: string; v: string; lock?: boolean }
type FlowNode = { id: string; label: string; tone: ChainTone; tag: string; stage: number; body: ReactNode; phase: number; side?: string; params?: FlowParam[]; code?: string }

type PortType = 'data' | 'patients' | 'share' | 'volume' | 'value'
const PORT: Record<PortType, { c: string; out: string }> = {
  data: { c: '#7c3aed', out: 'table' }, patients: { c: '#0891b2', out: 'patients' }, share: { c: '#db2777', out: 'share %' },
  volume: { c: '#d97706', out: 'units' }, value: { c: '#059669', out: 'revenue $' },
}
const portOf = (n: FlowNode): PortType => n.tone === 'start' ? 'data' : n.tone === 'share' || /share/i.test(n.label) ? 'share' : n.tone === 'gross' || n.tone === 'end' || /sales|revenue|price/i.test(n.label) ? 'value' : /volume|units|dose|regimen/i.test(n.label) || n.tone === 'regimen' ? 'volume' : 'patients'

/** Node-editor view of one stream: nodes in calculation order left to right, wired port to port. Wheel to zoom, drag to pan, click a node to expand it in place. */
function ModuleMap({ title, nodes, feeds, offChain, go, onClose }: { title: string; nodes: FlowNode[]; feeds: FlowNode[]; offChain: Mod[]; go: (n: number) => void; onClose: () => void }) {
  const W = 248, HEAD = 40, ROW = 28, PAD = 10, DETAIL = 200, GX = 96, GY = 30, P = 56
  const [sel, setSel] = useState<string | null>(null)
  const phases = Array.from(new Set(nodes.map(n => n.phase))).sort((a, b) => a - b)
  const cols = phases.map(p => nodes.filter(n => n.phase === p))
  cols[0] = [...cols[0], ...feeds]
  type Edge = { from: string; to: string; kind: 'flow' | 'feed' }
  const edges: Edge[] = []
  cols.forEach((col, ci) => {
    const next = cols[ci + 1]; if (!next) return
    const a = col.filter(n => !n.side)
    a.forEach((n, i) => next.forEach((m, j) => { if (a.length * next.length <= 9 || Math.min(i, next.length - 1) === j) edges.push({ from: n.id, to: m.id, kind: 'flow' }) }))
  })
  feeds.forEach(f => edges.push({ from: f.id, to: f.side!, kind: 'feed' }))
  const all = [...nodes, ...feeds]
  const byId = Object.fromEntries(all.map(n => [n.id, n]))
  const insOf = (id: string) => edges.filter(e => e.to === id)
  const baseH = (n: FlowNode) => HEAD + (insOf(n.id).length + (n.params?.length ?? 0) + 1) * ROW + PAD
  const hOf = (n: FlowNode) => baseH(n) + (sel === n.id ? DETAIL : 0)
  const colH = cols.map(col => col.reduce((t, n) => t + hOf(n), 0) + (col.length - 1) * GY)
  const height = P * 2 + Math.max(...colH)
  const width = P * 2 + cols.length * W + (cols.length - 1) * GX
  const pos: Record<string, { x: number; y: number; col: number }> = {}
  cols.forEach((col, ci) => { let y = P + (height - P * 2 - colH[ci]) / 2; col.forEach(n => { pos[n.id] = { x: P + ci * (W + GX), y, col: ci }; y += hOf(n) + GY }) })
  const inY = (e: Edge) => { const i = insOf(e.to).indexOf(e); return pos[e.to].y + HEAD + i * ROW + ROW / 2 }
  const outY = (n: FlowNode) => pos[n.id].y + HEAD + (insOf(n.id).length + (n.params?.length ?? 0)) * ROW + ROW / 2

  // Viewport: pan (tx, ty) and zoom (z) applied as one transform.
  const [view, setView] = useState({ z: 1, tx: 0, ty: 0 })
  const wrap = useRef<HTMLDivElement>(null)
  const drag = useRef<{ x: number; y: number; tx: number; ty: number; moved: boolean } | null>(null)
  const clampZ = (z: number) => Math.min(2, Math.max(0.3, z))
  const [ease, setEase] = useState(false)
  const eased = (f: () => void) => { setEase(true); f(); setTimeout(() => setEase(false), 260) }
  const zoomAt = (factor: number, cx0?: number, cy0?: number) => setView(v => {
    const r = wrap.current?.getBoundingClientRect(); const px = cx0 ?? (r ? r.width / 2 : 0), py = cy0 ?? (r ? r.height / 2 : 0)
    const z = clampZ(v.z * factor); const k = z / v.z
    return { z, tx: px - (px - v.tx) * k, ty: py - (py - v.ty) * k }
  })
  const fit = () => { const r = wrap.current?.getBoundingClientRect(); if (!r) return; const z = clampZ(Math.min((r.width - 32) / width, (r.height - 32) / height, 1)); setView({ z, tx: (r.width - width * z) / 2, ty: Math.max(16, (r.height - height * z) / 2) }) }
  useEffect(() => { fit() }, [])
  useEffect(() => {
    const el = wrap.current; if (!el) return
    // Trackpad: two-finger scroll pans, pinch (sent as ctrl+wheel) zooms. Mouse: Ctrl/⌘ + wheel zooms. Batched per frame for smoothness.
    let raf = 0, dz = 0, dx = 0, dy = 0, px = 0, py = 0
    const flush = () => {
      raf = 0
      setView(v => {
        let { z, tx, ty } = v
        if (dz) { const nz = clampZ(z * Math.exp(-dz * 0.01)); const k = nz / z; tx = px - (px - tx) * k; ty = py - (py - ty) * k; z = nz }
        return { z, tx: tx - dx, ty: ty - dy }
      })
      dz = dx = dy = 0
    }
    const wheel = (e: WheelEvent) => {
      e.preventDefault()
      const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 400 : 1
      const r = el.getBoundingClientRect(); px = e.clientX - r.left; py = e.clientY - r.top
      if (e.ctrlKey || e.metaKey) dz += Math.max(-30, Math.min(30, e.deltaY * unit))
      else { dx += e.deltaX * unit; dy += e.deltaY * unit }
      if (!raf) raf = requestAnimationFrame(flush)
    }
    el.addEventListener('wheel', wheel, { passive: false }); return () => { el.removeEventListener('wheel', wheel); cancelAnimationFrame(raf) }
  }, [])
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') sel ? setSel(null) : onClose(); if (e.key === '+' || e.key === '=') zoomAt(1.2); if (e.key === '-') zoomAt(1 / 1.2); if (e.key === '0') fit() }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [sel])
  const focusNode = (id: string) => {
    setSel(id); setEase(true); setTimeout(() => setEase(false), 260)
    const r = wrap.current?.getBoundingClientRect(); const p = pos[id]; if (!r || !p) return
    setView(v => { const z = Math.max(v.z, 0.85); return { z, tx: r.width / 2 - (p.x + W / 2) * z, ty: Math.min(80, r.height / 3 - p.y * z) } })
  }

  const lit = (e: Edge) => !!sel && (e.from === sel || e.to === sel)
  const near = (id: string) => !sel || id === sel || edges.some(e => lit(e) && (e.from === id || e.to === id))
  const wire = (e: Edge) => { const a = byId[e.from]; const x1 = pos[e.from].x + W, y1 = outY(a), x2 = pos[e.to].x, y2 = inY(e); const d = Math.max(50, (x2 - x1) / 2); return `M${x1},${y1} C${x1 + d},${y1} ${x2 - d},${y2} ${x2},${y2}` }
  const Dot = ({ t, className }: { t: PortType; className?: string }) => <span className={cx('absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full ring-2 ring-surface', className)} style={{ background: PORT[t].c }} />
  const Chip = ({ n }: { n: FlowNode }) => <button type="button" onClick={e => { e.stopPropagation(); focusNode(n.id) }} className="inline-flex max-w-full items-center gap-1 rounded-full border border-border bg-surface px-2 py-0.5 text-[11px] hover:border-brand"><span className="h-2 w-2 shrink-0 rounded-full" style={{ background: PORT[portOf(n)].c }} /><span className="truncate">{n.label.split(' (')[0]}</span></button>

  return createPortal(
    <div className="fixed inset-0 z-[70] flex bg-background" role="dialog" aria-modal="true" aria-labelledby="map-title">
      <div className="rise flex h-dvh w-full flex-col overflow-hidden text-text">
        <header className="flex flex-wrap items-center gap-3 border-b border-border bg-surface px-5 py-3">
          <span className="grid h-9 w-9 place-items-center rounded-md bg-brand-soft text-brand"><Workflow size={18} /></span>
          <div className="min-w-0 flex-1">
            <h2 id="map-title" className="text-base font-semibold">Module map</h2>
            <p className="truncate text-xs text-text-2">{title} · calculation sequence left to right · {nodes.length} nodes in {cols.length} stages</p>
          </div>
          <ul className="hidden flex-wrap gap-3 text-[11px] text-text-2 md:flex">{(Object.keys(PORT) as PortType[]).map(t => <li key={t} className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full" style={{ background: PORT[t].c }} />{t === 'value' ? 'revenue' : t}</li>)}</ul>
          <Btn variant="secondary" size="sm" onClick={onClose} icon={<X size={15} />}>Close</Btn>
        </header>

        <div ref={wrap} className={cx('relative min-h-0 flex-1 touch-none select-none overflow-hidden bg-[#f7f8fb]', drag.current ? 'cursor-grabbing' : 'cursor-grab')}
          style={{ backgroundImage: 'linear-gradient(#e3e7ef 1px, transparent 1px), linear-gradient(90deg, #e3e7ef 1px, transparent 1px), linear-gradient(#eef1f6 1px, transparent 1px), linear-gradient(90deg, #eef1f6 1px, transparent 1px)', backgroundSize: `${96 * view.z}px ${96 * view.z}px, ${96 * view.z}px ${96 * view.z}px, ${16 * view.z}px ${16 * view.z}px, ${16 * view.z}px ${16 * view.z}px`, backgroundPosition: `${view.tx}px ${view.ty}px` }}
          onPointerDown={e => { if ((e.target as HTMLElement).closest('[data-node]')) return; drag.current = { x: e.clientX, y: e.clientY, tx: view.tx, ty: view.ty, moved: false }; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId) }}
          onPointerMove={e => { const d = drag.current; if (!d) return; const dx = e.clientX - d.x, dy = e.clientY - d.y; if (Math.abs(dx) + Math.abs(dy) > 3) d.moved = true; setView(v => ({ ...v, tx: d.tx + dx, ty: d.ty + dy })) }}
          onPointerUp={() => { const d = drag.current; drag.current = null; if (d && !d.moved) setSel(null) }}>
          <div className="absolute left-0 top-0 origin-top-left will-change-transform" style={{ width, height, transform: `translate(${view.tx}px, ${view.ty}px) scale(${view.z})`, transition: ease ? 'transform .25s ease-out' : undefined }}>
            {cols.map((_, ci) => <span key={ci} className="absolute font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-text-3" style={{ left: P + ci * (W + GX), top: 22 }}>{ci === 0 ? 'Inputs' : ci === cols.length - 1 ? 'Output' : `Step ${ci}`}</span>)}
            <svg className="absolute inset-0 overflow-visible" width={width} height={height} aria-hidden>
              {edges.map((e, k) => { const t = portOf(byId[e.from]); return <path key={k} d={wire(e)} fill="none" stroke={PORT[t].c} strokeWidth={lit(e) ? 3.5 : 2.2} strokeLinecap="round" strokeDasharray={e.kind === 'feed' ? '6 6' : undefined} opacity={sel ? (lit(e) ? 1 : 0.15) : 0.75} className="transition-[d] duration-300" /> })}
            </svg>
            {all.map(n => {
              const p = pos[n.id]; const ins = insOf(n.id); const out = portOf(n); const on = sel === n.id
              const outs = edges.filter(e => e.from === n.id).map(e => byId[e.to])
              return (
                <div key={n.id} data-node role="button" tabIndex={0} aria-expanded={on} onClick={() => on ? setSel(null) : focusNode(n.id)} onKeyDown={e => e.key === 'Enter' && (on ? setSel(null) : focusNode(n.id))}
                  className={cx('absolute cursor-pointer rounded-lg border bg-surface shadow-[0_6px_20px_-10px_rgba(15,23,42,.35)] outline-none transition-[top,height,opacity,box-shadow] duration-300 focus-visible:ring-2 focus-visible:ring-brand', on ? 'z-10 border-brand shadow-[0_16px_40px_-12px_rgba(0,0,201,.35)]' : 'border-border hover:border-border-strong', !near(n.id) && 'opacity-35', n.side && 'border-dashed')}
                  style={{ left: p.x, top: p.y, width: W, height: hOf(n) }}>
                  <div className="flex items-center gap-2 rounded-t-lg border-b border-border bg-surface-2/60 px-3" style={{ height: HEAD, boxShadow: `inset 3px 0 0 ${PORT[out].c}` }}>
                    {!n.side && p.col > 0 && <span className="font-mono text-[10px] text-text-3">#{p.col}</span>}
                    <span className="min-w-0 flex-1 truncate text-[13px] font-semibold">{n.label}</span>
                    {n.code && <span className="rounded bg-surface px-1.5 font-mono text-[10px] text-text-2 ring-1 ring-border">M{n.code}</span>}
                    <ChevronDown size={14} className={cx('text-text-3 transition-transform', on && 'rotate-180 text-brand')} />
                  </div>
                  {ins.map(e => (
                    <div key={e.from} className="relative flex items-center pl-5 pr-3 text-[12px] text-text-2" style={{ height: ROW }}>
                      <Dot t={portOf(byId[e.from])} className="-left-1.5" /><span className="truncate">{byId[e.from].label.split(' (')[0]}</span>
                    </div>
                  ))}
                  {n.params?.map(pr => (
                    <div key={pr.k} className="flex items-center gap-2 px-3 text-[12px]" style={{ height: ROW }}>
                      <span className={cx('max-w-[100px] shrink-0 truncate rounded border px-1.5 py-0.5 font-mono text-[11px] tabular-nums', pr.lock ? 'border-border bg-surface-2 text-text-2' : 'border-brand/40 bg-brand-soft text-brand')}>{pr.v}</span>
                      <span className="min-w-0 flex-1 truncate text-text-2">{pr.k}</span>
                      {pr.lock ? <Lock size={11} className="shrink-0 text-text-3" /> : <LockOpen size={11} className="shrink-0 text-brand" />}
                    </div>
                  ))}
                  <div className="relative flex items-center justify-end pl-3 pr-5 text-[12px] font-semibold" style={{ height: ROW }}>
                    {PORT[out].out}<Dot t={out} className="-right-1.5" />
                  </div>
                  {on && (
                    <div className="rise mx-2 overflow-y-auto rounded-md border border-border bg-background p-3 text-xs leading-relaxed text-text-2" style={{ height: DETAIL - 8 }} onClick={e => e.stopPropagation()} onWheel={e => e.stopPropagation()}>
                      <p className="mb-1 font-mono text-[10px] font-semibold uppercase tracking-wider text-text-3">{n.tag}</p>
                      {n.body}
                      {outs.length > 0 && <div className="mt-2"><p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-text-3">Output goes to</p><div className="flex flex-wrap gap-1">{outs.map(x => <Chip key={x.id} n={x} />)}</div></div>}
                      <button type="button" onClick={() => go(n.stage)} className="mt-2 inline-flex items-center gap-1 font-semibold text-brand hover:underline">Edit in step {n.stage} · {STAGES[n.stage - 1].short}<ArrowRight size={12} /></button>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          <div className="absolute bottom-4 right-4 flex items-center gap-0.5 rounded-lg border border-border bg-surface p-1 shadow-md" onPointerDown={e => e.stopPropagation()}>
            <button type="button" aria-label="Zoom out" onClick={() => eased(() => zoomAt(1 / 1.2))} className="grid h-8 w-8 place-items-center rounded-md text-lg text-text-2 hover:bg-surface-2">−</button>
            <button type="button" onClick={() => eased(() => zoomAt(1 / view.z))} title="Reset to 100%" className="w-14 rounded-md py-1 text-center font-mono text-[11px] text-text-2 hover:bg-surface-2">{Math.round(view.z * 100)}%</button>
            <button type="button" aria-label="Zoom in" onClick={() => eased(() => zoomAt(1.2))} className="grid h-8 w-8 place-items-center rounded-md text-lg text-text-2 hover:bg-surface-2">+</button>
            <span className="mx-1 h-5 w-px bg-border" />
            <button type="button" onClick={() => eased(fit)} className="rounded-md px-2.5 py-1.5 text-xs font-semibold text-text-2 hover:bg-surface-2">Fit</button>
          </div>
          <div className="pointer-events-none absolute bottom-4 left-4 hidden max-w-xs rounded-lg border border-border bg-surface/95 p-3 text-[11px] leading-snug text-text-2 shadow-md backdrop-blur sm:block">
            <p className="mb-1 text-xs font-semibold text-text">Reading the map</p>
            Wires carry one node’s output into the next: the colour is the quantity passed on. Blue value boxes are forecaster-editable; grey are CoE-locked. Dashed = data feed into a module.
            <p className="mt-1.5 text-text-3">Pinch (or Ctrl + scroll) to zoom · scroll or drag to pan · click a node to expand</p>
            {offChain.length > 0 && <p className="mt-1.5 text-text-3">Outside the calculation: {offChain.map(m => m.name).join(', ')}.</p>}
          </div>
        </div>
      </div>
    </div>,
    document.body,
  )
}

function ModelFlow({ c, ind, go, compact, map, onMap, mapOnly }: { c: Config; ind: Ind; go: (n: number) => void; compact?: boolean; map?: boolean; onMap?: (v: boolean) => void; mapOnly?: boolean }) {
  const arch = ind.arch!
  const [openNode, setOpenNode] = useState<string | null>(null)
  const bound = inputsFor(c, ind.id)
  const steps = CHAINS[arch]
  const last = steps[steps.length - 1]
  const engAs = ENGINE_ASSUMPTIONS[arch]
  const asSteps = steps.filter(s => s.kind === 'assumption')
  const attached = ind.modules.map(id => MODULES.find(m => m.id === id)).filter((m): m is Mod => !!m)
  const onChain = attached.filter(m => !OFF_CHAIN.has(m.name))
  const offChain = attached.filter(m => OFF_CHAIN.has(m.name))
  const val = (id: string) => { const a = assumptionsFor(arch).find(x => x.id === id); const p = ind.perms[id]; return a && p ? { a, p } : null }

  const [graphOwn, setGraphOwn] = useState(false)
  const graph = map ?? graphOwn
  const setGraph = onMap ?? setGraphOwn
  const paramsOf = (ids: string[]): FlowParam[] => ids.map(val).filter(Boolean).map(x => ({ k: x!.a.name, v: `${x!.p.value}${x!.a.unit.startsWith('%') ? '%' : ` ${x!.a.unit}`}`, lock: !x!.p.open }))
  const valueRows = (ids: string[]) => ids.map(val).filter(Boolean).map(x => (
    <li key={x!.a.id} className="flex items-center justify-between gap-3">
      <span>{x!.a.name}</span>
      <span className="flex items-center gap-1.5 tabular-nums text-text"><b>{x!.p.value}{x!.a.unit.startsWith('%') ? '%' : ` ${x!.a.unit}`}</b>{x!.p.open ? <span className="inline-flex items-center gap-1 text-[11px] text-brand"><LockOpen size={11} />{x!.p.min}–{x!.p.max}</span> : <span className="inline-flex items-center gap-1 text-[11px] text-text-3"><Lock size={11} />CoE-locked</span>}</span>
    </li>
  ))
  const modNode = (m: Mod): FlowNode => ({
    id: m.id, label: m.name, tone: BUCKET_TONE[m.cat] ?? 'funnel', tag: `Module ${m.code} · ${m.cat}`, stage: 4, phase: 0, code: m.code,
    body: <><p>{m.desc}</p><p className="mt-1 text-text-3">{m.cat}{m.data ? ` · needs ${MODULE_INPUTS[m.data]?.name ?? 'an input'}` : ''}</p></>,
  })
  const engNode = (s: Step): FlowNode => {
    const k = asSteps.indexOf(s)
    const ids = s.kind === 'assumption' ? engAs.filter((_, i) => Math.min(i, asSteps.length - 1) === k).map(a => a.id) : []
    return {
      id: s.id, label: s.label, tone: 'engine', tag: s.kind === 'assumption' ? 'Engine · assumption' : 'Engine · derived', stage: s.kind === 'assumption' ? 6 : 3, phase: 0, params: paramsOf(ids),
      body: ids.length ? <ul className="space-y-1">{valueRows(ids)}</ul> : <p>Calculated by the {archName(arch)} engine ({ind.engine.split(' ')[0]}) from the steps above{s.id === 'vol' ? `, in ${ind.modes.units ?? 'units'}` : ''}. Formula is fixed; changes are version requests.</p>,
    }
  }
  const inBucket = (...b: string[]) => onChain.filter(m => b.includes(m.cat) && !NET_MODULES.has(m.name)).map(modNode)
  const derivedMid = steps.filter(s => s.kind === 'derived' && s !== last && s.id !== 'vol')
  const vol = steps.find(s => s.id === 'vol' && s !== last)
  const finalIsNet = last.id === 'net'

  const ph = (p: number, arr: Omit<FlowNode, 'phase'>[]) => arr.map(n => ({ ...n, phase: p }))
  const nodes: FlowNode[] = [
    ...ph(0, steps.filter(s => s.kind === 'input').map((s): Omit<FlowNode, 'phase'> => ({
      id: s.id, label: s.label, tone: 'start', tag: 'Bound input', stage: 5, params: bound.slice(0, 3).map(b => ({ k: b.input.name, v: c.bindings[b.key]?.source ? 'Bound' : 'Missing', lock: true })),
      body: bound.length ? <ul className="space-y-1">{bound.map(b => { const x = c.bindings[b.key]; return <li key={b.key} className="flex items-center justify-between gap-3"><span>{b.input.name}</span><span className={cx('text-right', x?.source ? 'text-text' : 'text-err')}>{x?.source || 'Not bound'}{x?.status === 'ok' && <CheckCircle2 size={12} className="ml-1 inline text-ok" />}</span></li> })}</ul> : <p>No inputs bound yet.</p>,
    }))),
    ...ph(1, inBucket('Population & top-of-funnel', 'Segmentation & structure', 'Lines of therapy & disease states')),
    ...asSteps.flatMap((s, k) => ph(2 + k / 10, [engNode(s)])),
    ...ph(3, inBucket('Share machinery')),
    ...derivedMid.flatMap((s, k) => ph(4 + k / 10, [engNode(s)])),
    ...ph(5, inBucket('Persistence, dosing & regimen', 'Cross-product & franchise', 'Events, LOE & scenarios')),
    ...(vol ? ph(6, [engNode(vol)]) : []),
    ...ph(7, inBucket('Actuals, calibration & reconciliation', 'Conversion, financial & integration')),
    ...(finalIsNet ? [
      ...ph(8, [{ id: 'gross', label: 'Gross sales', tone: 'gross' as const, tag: 'Derived', stage: 4, params: paramsOf(['price']), body: <><p>Volume × price{c.shared.price ? ', priced at brand level' : ''}.</p><ul className="mt-1 space-y-1">{valueRows(['price'])}</ul></> }]),
      ...ph(9, onChain.filter(m => NET_MODULES.has(m.name)).map(modNode)),
      ...ph(10, [{ id: 'net', label: 'Net revenue', tone: 'end' as const, tag: 'Output', stage: 4, params: paramsOf(['g2n']), body: <><ul className="space-y-1">{valueRows(['g2n'])}</ul><p className="mt-1">{c.inds.length > 1 ? `Rolls up with ${c.inds.length - 1} other stream${c.inds.length === 2 ? '' : 's'} into the ${c.brand || 'brand'} total.` : `This stream is the ${c.brand || 'brand'} total.`}</p></> }]),
    ] : ph(10, [{ ...engNode(last), tone: 'end' as const, tag: 'Output' }])),
  ]
  // Data feeds that enter mid-chain (module-specific inputs), drawn as side branches in the node view.
  const feeds: FlowNode[] = onChain.filter(m => m.data && MODULE_INPUTS[m.data]).map(m => {
    const inp = MODULE_INPUTS[m.data!]; const b = bound.find(x => x.input.id === inp.id); const x = b && c.bindings[b.key]
    return { id: `feed-${m.id}`, label: inp.name, tone: 'start' as const, tag: 'Data feed', stage: 5, phase: 0, side: m.id, body: <><p>Feeds <b className="text-text">{m.name}</b>.</p><p className="mt-1">Source: <span className={x?.source ? 'text-text' : 'text-err'}>{x?.source || inp.suggested + ' (suggested)'}</span></p></> }
  })

  const legend: [ChainTone, string][] = [['start', 'Input'], ['engine', 'Engine'], ['funnel', 'Population'], ['share', 'Share'], ['regimen', 'Regimen'], ['adjust', 'Adjustments'], ['gross', 'Revenue']]
  const mapEl = graph && <ModuleMap title={`${ind.name || 'Stream'} · ${archName(arch)}`} nodes={nodes} feeds={feeds} offChain={offChain} go={n => { setGraph(false); go(n) }} onClose={() => setGraph(false)} />
  if (mapOnly) return <>{mapEl}</>
  return (
    <div className="mx-auto max-w-xl">
      <div className={cx('flex flex-wrap items-center justify-between gap-2', compact ? 'mb-2' : 'mb-3')}>
        <p className={cx('text-text-2', compact ? 'text-xs' : 'text-[13px]')}>Click any node to expand it · {nodes.length} steps</p>
        <Btn size="sm" variant="secondary" icon={<Workflow size={14} />} onClick={() => setGraph(true)}>Module map</Btn>
        <ul className={cx('flex flex-wrap gap-y-1 text-text-3', compact ? 'gap-x-2 text-[10px]' : 'gap-x-3 text-[11px]')}>
          {legend.map(([t, l]) => <li key={t} className="flex items-center gap-1"><span className={cx('h-2.5 w-2.5 rounded-sm border', CHAIN_TONE[t])} />{l}</li>)}
        </ul>
      </div>
      <ol className={cx(compact && 'max-h-[calc(100dvh-300px)] min-h-[240px] overflow-y-auto pr-1')}>
        {nodes.map((n, k) => {
          const isOpen = openNode === n.id
          const solid = n.tone === 'start' || n.tone === 'end'
          return (
            <li key={n.id}>
              {k > 0 && <div aria-hidden className={cx('mx-auto w-0.5 bg-border', compact ? 'h-2' : 'h-4')} />}
              <div className={cx('overflow-hidden rounded-lg border', CHAIN_TONE[n.tone])}>
                <button type="button" aria-expanded={isOpen} onClick={() => setOpenNode(isOpen ? null : n.id)}
                  className={cx('relative flex w-full items-center justify-center text-center font-semibold', compact ? 'px-7 py-1.5 text-[12px] leading-tight' : 'px-10 py-3 text-[14px]')}>
                  {n.label}
                  <ChevronDown size={compact ? 12 : 14} className={cx('absolute opacity-60 transition-transform', compact ? 'right-2' : 'right-3', isOpen && 'rotate-180')} />
                </button>
                {isOpen && (
                  <div className={cx('border-t bg-surface px-4 py-3 text-left text-xs text-text-2', solid ? 'border-white/20' : 'border-border')}>
                    <div className="mb-1.5 flex items-center justify-between gap-3">
                      <span className="font-mono text-[10px] font-semibold uppercase tracking-wider text-text-3">{n.tag}</span>
                      <EditLink stage={n.stage} go={go} />
                    </div>
                    {n.body}
                  </div>
                )}
              </div>
            </li>
          )
        })}
      </ol>
      {offChain.length > 0 && (
        <p className="mt-4 border-t border-border pt-3 text-xs text-text-3">Also attached, outside the calculation: {offChain.map(m => m.name).join(', ')}.</p>
      )}
      {mapEl}
    </div>
  )
}

function StagePreview({ c, ind, go, issues, warns, fix }: Ctx & { issues: Issue[][]; warns: { msg: string; stage: number }[] }) {
  const [code, setCode] = useState(false)
  const errs = STAGES.slice(0, LAST - 1).flatMap(s => issues[s.id - 1].map(i => ({ ...i, stage: s.id })))
  if (!ind.arch) return needArch(go, ind.name)
  const AS = assumptionsFor(ind.arch)
  const b = c.baseline
  const stale = !!b && b.sig !== baselineSig(c)
  const ins = inputsFor(c)
  return (
    <>
      <Card title="Configuration check" sub={errs.length ? `${errs.length} blocking · ${warns.length} to review` : warns.length ? `Valid · ${warns.length} to review` : 'Valid. Nothing to review.'}
        right={errs.length ? <div className="flex items-center gap-2"><Badge tone="err">Not ready to publish</Badge><FixForMe onClick={() => fix(STAGES.slice(0, REVIEW - 1).map(s => s.id))} /></div> : <Badge tone="ok"><Check size={10} />Ready to publish</Badge>}>
        {errs.length + warns.length === 0 ? <p className="flex items-center gap-2 text-sm text-ok"><CheckCircle2 size={16} />Every step checks out.</p> : (
          <ul className="divide-y divide-border">
            {[...errs.map(e => ({ ...e, tone: 'err' as const })), ...warns.map(w => ({ ...w, tone: 'warn' as const }))].map((x, k) => (
              <li key={k} className="flex flex-wrap items-center gap-x-3 gap-y-1 py-2.5 text-[13px] first:pt-0 last:pb-0">
                {x.tone === 'err' ? <AlertCircle size={16} className="shrink-0 text-err" /> : <AlertTriangle size={16} className="shrink-0 text-warn" />}
                <span className="min-w-[180px] flex-1">{x.msg}</span>
                <span className="text-xs text-text-3">{STAGES[x.stage - 1].short}</span>
                <Btn size="sm" variant="secondary" onClick={() => go(x.stage)}>{x.tone === 'err' ? 'Fix' : 'Review'}</Btn>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="Model summary" sub="Generated from your selections. Edit jumps back to the step.">
        <dl className="grid gap-x-6 gap-y-3 text-[13px] @xl:grid-cols-2">
          {[['Model', `${c.brand} · ${c.asset}`, 1], ['Asset type · therapy area', `${c.subjectType} · ${c.therapyArea}`, 1], ['Lifecycle stage', c.lifecycle, 1], ['Data bindings', `${ins.filter(x => resolved(c.bindings[x.key])).length} of ${ins.length} ready`, 5]].map(([k, v, st]) => (
            <div key={k as string} className="flex items-start justify-between gap-3 border-b border-border pb-2"><div className="min-w-0"><dt className="text-xs text-text-3">{k}</dt><dd className="font-medium">{v}</dd></div><EditLink stage={st as number} go={go} /></div>
          ))}
        </dl>
        <div className="mt-4 space-y-3">
          {c.inds.map(i => (
            <div key={i.id} className={cx('rounded-md border p-3', i.id === ind.id ? 'border-brand/40 bg-brand-soft/20' : 'border-border')}>
              <p className="text-sm font-semibold">{i.name || 'Untitled stream'} <span className="font-normal text-text-2">· {archName(i.arch)} <span className="text-text-3">({i.engine})</span></span></p>
              <div className="mt-2 grid gap-2 text-[12px] @xl:grid-cols-2">
                <div className="flex justify-between gap-2"><span className="min-w-0"><span className="block text-text-3">Modes</span>{i.arch ? modesFor(i.arch).map(m => i.modes[m.id]).filter(Boolean).join(' · ') : '—'}</span><EditLink stage={3} go={go} /></div>
                <div className="flex justify-between gap-2"><span><span className="block text-text-3">Modules</span>{i.modules.length} attached · {requiredFor(i.arch).length} core</span><EditLink stage={4} go={go} /></div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Model flow" sub={`How ${ind.name || 'this stream'} turns data into the forecast, top to bottom. Engine formulas are fixed — changes are version requests.`}>
        <ModelFlow c={c} ind={ind} go={go} />
      </Card>

      <Card title="Configuration document" sub="What publishing freezes for this version.">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 ">
              <p className="min-w-[220px] flex-1 text-[13px] text-text-2">Publishing {c.version} freezes a configuration document: engines, modes, modules and parameters are data; formulas live in the versioned module library.</p>
              <Btn variant="secondary" size="sm" onClick={() => setCode(v => !v)}>{code ? 'Hide configuration' : 'View configuration as code'}</Btn>
            </div>
            {code && <pre className="max-h-80 overflow-auto rounded-md bg-text p-4 text-[12px] text-white">{JSON.stringify({ model: c.brand, asset: c.asset, version: c.version, instances: c.inds.map(i => ({ name: i.name, archetype: i.arch, engine: i.engine, modes: i.modes, modules: i.modules.map(id => MODULES.find(m => m.id === id)?.name) })) }, null, 2)}</pre>}
          </div>
      </Card>
    </>
  )
}

/* ───────────────────────── Step 7 · Publish & assign ───────────────────────── */

function StagePublish({ c, update, go, notify, issues, warns, errs, onPublish, onAttempt }: Ctx & {
  issues: Issue[][]; warns: { msg: string; stage: number }[]; errs: Issue[]; onPublish: () => void; onAttempt: () => void
}) {
  const [confirm, setConfirm] = useState(false)
  const [busy, setBusy] = useState(false)
  const [fail, setFail] = useState(false)
  const blocking = STAGES.slice(0, LAST - 1).filter(s => issues[s.id - 1].length)
  const ready = blocking.length === 0 && issues[LAST - 1].length === 0
  const gov = c.inds.flatMap(i => MODULES.filter(m => i.modules.includes(m.id) && GOVERNED.has(m.name)).map(m => m.name))
  const assignees = [...(c.selfForecast ? [`${ME} (you)`] : []), ...c.forecasters]
  const dataOwners = Array.from(new Set(inputsFor(c).map(b => c.bindings[b.key]?.owner).filter(Boolean)))
  const asOwners = Array.from(new Set(c.inds.flatMap(i => Object.values(i.perms).map(p => p.owner)).filter(Boolean)))
  const VIS = [
    { v: 'Assigned forecasters only', d: 'Only the people assigned here can open the model.' },
    { v: 'Finance team (view)', d: 'Assignees edit; the finance team can view.' },
    { v: 'All forecasting users (view)', d: 'Read-only for everyone in Forecasting; edits by assignees.' },
  ]

  const publish = () => {
    setBusy(true); setFail(false)
    setTimeout(() => {
      setBusy(false)
      if (c.notes.toLowerCase().includes('fail')) { setFail(true); setConfirm(false); return }
      onPublish()
    }, 1300)
  }

  return (
    <>
      {fail && <Banner tone="err" title="Publish failed — nothing was changed" action={<Btn size="sm" variant="secondary" onClick={() => setConfirm(true)}>Try again</Btn>}>The version service timed out. Your draft is saved.</Banner>}

      <Card title="Geography & planning cycle" sub="Assigned here so the model structure stays reusable across cycles and geographies.">
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Geography" required error={errs.find(e => e.field === 'market')?.msg}>
            <select className={inputCls(!!errs.find(e => e.field === 'market'))} value={c.market} onChange={e => update({ market: e.target.value })}>
              {['United States', 'EU5', 'Japan', 'China', 'Rest of world'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Planning cycle" required error={errs.find(e => e.field === 'cycle')?.msg} hint="The submission this version is built for.">
            <select className={inputCls(!!errs.find(e => e.field === 'cycle'))} value={c.cycle} onChange={e => update({ cycle: e.target.value })}>
              {CYCLES.map(o => <option key={o.name}>{o.name}</option>)}
            </select>
          </Field>
        </div>
      </Card>

      <Card title="Release" sub="Working versions are drafts. A formal release (LE) is sealed and immutable once published.">
        <Segmented value={c.release} options={['Working version', 'LE1', 'LE2', 'LE3']} onChange={v => update({ release: v })} />
        <p className="mt-3 text-xs text-text-2">Publishing {c.version} {c.release === 'Working version' ? 'as a working version' : `as ${c.release}`} keeps earlier versions in history. Later edits open a new working version; this one stays live until that version is published.</p>
      </Card>

      <Card title="Readiness" sub={blocking.length ? `${blocking.length} step${blocking.length > 1 ? 's' : ''} need attention.` : `Steps 1–${LAST - 1} complete.`}>
        <ul className="grid gap-x-6 @2xl:grid-cols-2">
          {STAGES.slice(0, LAST - 1).map(s => {
            const iss = issues[s.id - 1]
            return (
              <li key={s.id} className="flex items-center gap-3 border-b border-border py-2.5">
                {iss.length ? <AlertCircle size={18} className="shrink-0 text-err" /> : <CheckCircle2 size={18} className="shrink-0 text-ok" />}
                <div className="min-w-0 flex-1"><p className="text-sm font-semibold">{s.title}</p><p className={cx('text-xs', iss.length ? 'text-err' : 'text-text-2')}>{iss.length ? iss[0].msg : 'Complete'}</p></div>
                {iss.length > 0 && <Btn variant="secondary" size="sm" onClick={() => go(s.id)}>Fix</Btn>}
              </li>
            )
          })}
        </ul>
      </Card>

      <div className="grid gap-6 @2xl:grid-cols-2">
        <Card title="Sealed in this version">
          <ul className="space-y-2 text-sm text-text-2">
            {['Engine versions & module internals', 'Calculation options and CoE-locked values', 'Data sources, fallbacks & refresh rules', ...(gov.length ? [`Governed modules: ${Array.from(new Set(gov)).join(', ')}`] : [])].map(x => <li key={x} className="flex gap-2"><Lock size={14} className="mt-0.5 shrink-0 text-text-3" />{x}</li>)}
          </ul>
        </Card>
        <Card title="Open to forecasters">
          <ul className="space-y-2 text-sm text-text-2">
            {c.inds.flatMap(i => assumptionsFor(i.arch).filter(a => i.perms[a.id]?.open).map(a => <li key={i.id + a.id} className="flex gap-2"><LockOpen size={14} className="mt-0.5 shrink-0 text-brand" /><span>{c.inds.length > 1 && <span className="text-text-3">{i.name} · </span>}{a.name} <span className="text-text-3">({i.perms[a.id].min}–{i.perms[a.id].max})</span></span></li>))}
          </ul>
        </Card>
      </div>

      <Card title="Assign forecasters" sub="Who builds forecasts in this model after handoff.">
        <label className={cx('mb-4 flex cursor-pointer items-start gap-3 rounded-md border p-3 transition-colors', c.selfForecast ? 'border-brand bg-brand-soft/40' : 'border-border hover:border-border-strong')}>
          <input type="checkbox" className="mt-0.5 h-4 w-4 shrink-0 accent-brand" checked={c.selfForecast} onChange={e => update({ selfForecast: e.target.checked })} />
          <span className="min-w-0"><span className="block text-sm font-semibold">I will also act as a forecaster</span><span className="block text-xs text-text-2">You’ll get this model in your forecaster workspace with the same editable boundaries as other assignees.</span></span>
        </label>
        <Field label="Forecasters" required={!c.selfForecast} error={errs.find(e => e.field === 'forecasters')?.msg} hint="They’re notified and see this model in their workspace.">
          <div className="flex flex-wrap gap-2">
            {FORECASTERS.map(f => {
              const on = c.forecasters.includes(f)
              return (
                <button type="button" key={f} aria-pressed={on} onClick={() => update({ forecasters: on ? c.forecasters.filter(x => x !== f) : [...c.forecasters, f] })}
                  className={cx('inline-flex items-center gap-2 rounded-full border py-1 pl-1 pr-3 text-[13px] transition-colors', on ? 'border-brand bg-brand-soft text-brand' : 'border-border-strong hover:border-text')}>
                  <span className={cx('grid h-6 w-6 place-items-center rounded-full text-[10px] font-semibold', on ? 'bg-brand text-white' : 'bg-surface-2 text-text-2')}>{on ? <Check size={12} /> : f.split(' ').map(x => x[0]).join('')}</span>{f}
                </button>
              )
            })}
          </div>
        </Field>
      </Card>

      <Card title="Visibility" sub="Who can find and open this model once it’s published.">
        <div className="grid gap-2 @2xl:grid-cols-3" role="radiogroup" aria-label="Model visibility">
          {VIS.map(o => {
            const on = c.visibility === o.v
            return (
              <button type="button" role="radio" aria-checked={on} key={o.v} onClick={() => update({ visibility: o.v })}
                className={cx('flex min-w-0 items-start gap-2.5 rounded-lg border p-3 text-left outline-none transition-colors focus-visible:ring-2 focus-visible:ring-brand', on ? 'border-brand bg-brand-soft/40 ring-1 ring-brand' : 'border-border hover:border-text-2')}>
                <span className={cx('mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full border-2', on ? 'border-brand' : 'border-border-strong')}>{on && <span className="h-2 w-2 rounded-full bg-brand" />}</span>
                <span className="min-w-0"><span className="block text-[13px] font-semibold">{o.v}</span><span className="mt-0.5 block text-[11px] leading-snug text-text-2">{o.d}</span></span>
              </button>
            )
          })}
        </div>
        {errs.find(e => e.field === 'visibility') && <p className="mt-2 flex items-center gap-1 text-xs text-err"><AlertCircle size={12} />{errs.find(e => e.field === 'visibility')!.msg}</p>}
        <div className="mt-5 border-t border-border pt-4">
          <Field label="Named viewers" hint="Read-only access, such as leadership or finance, in addition to the visibility above.">
            <div className="flex flex-wrap gap-2">
              {PEOPLE.filter(p => !c.forecasters.some(f => p.startsWith(f))).map(p => {
                const on = c.viewers.includes(p)
                return <button type="button" key={p} aria-pressed={on} onClick={() => update({ viewers: on ? c.viewers.filter(x => x !== p) : [...c.viewers, p] })} className={cx('inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[13px] transition-colors', on ? 'border-brand bg-brand-soft text-brand' : 'border-border-strong hover:border-text')}>{on && <Eye size={12} />}{p}</button>
              })}
            </div>
          </Field>
          <div className="mt-4"><Switch on={c.geoRestrict} onChange={v => update({ geoRestrict: v })} label={`Restrict to ${c.market || 'this geography'}: users in other markets can’t see this model, and confidential local pricing stays hidden from them`} /></div>
        </div>
      </Card>

      <div className="grid gap-6 @2xl:grid-cols-2">
        <Card title="Configuration team" sub="Ownership recorded with this version.">
          <dl className="space-y-2 text-[13px]">
            <div className="flex justify-between gap-3"><dt className="text-text-2">Configured by</dt><dd className="text-right font-medium">{ME} · CoE</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-text-2">Data owners</dt><dd className="text-right font-medium">{dataOwners.join(', ') || '—'}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-text-2">Assumption owners</dt><dd className="text-right font-medium">{asOwners.join(', ') || '—'}</dd></div>
          </dl>
        </Card>
        <Card title="Publish summary" sub="What will go live.">
          <dl className="space-y-2 text-[13px]">
            {[['Model', `${c.brand} ${c.version}`], ['Geography · cycle', `${c.market} · ${c.cycle}`], ['Streams', c.inds.map(i => `${i.name} (${archName(i.arch)})`).join(', ')], ['Baseline', c.baseline ? `Run #${c.baseline.n} · ${c.baseline.at}` : 'Not generated'], ['Release', `${c.version} · ${c.release}`], ['Forecasters', assignees.join(', ') || '—'], ['Visibility', c.visibility || '—'], ['Viewers', c.viewers.join(', ') || '—'], ['Geography access', c.geoRestrict ? `${c.market} only` : 'All markets']].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3"><dt className="shrink-0 text-text-2">{k}</dt><dd className="min-w-0 text-right font-medium">{v}</dd></div>
            ))}
          </dl>
        </Card>
      </div>

      <Card title="Version notes">
        <Field label="What changed" hint={`Shown in the audit history for ${c.version}. (Type “fail” to preview the error state.)`}>
          <textarea rows={3} value={c.notes} onChange={e => update({ notes: e.target.value })} placeholder="e.g. Persistency recalibrated to LAAD through Aug 2026." className={cx(inputCls(), 'h-auto py-2')} />
        </Field>
      </Card>

      <div className="flex flex-wrap items-center gap-3 border-t border-border pt-6">
        <Btn variant="ghost" icon={<ArrowLeft size={16} />} onClick={() => go(LAST - 1)}>Back</Btn>
        <div className="ml-auto flex flex-wrap items-center gap-3">
          <Btn variant="secondary" onClick={() => notify({ tone: 'ok', text: `${c.brand || 'Draft'} ${c.version} saved as draft` })}>Save draft</Btn>
          {!ready && <span className="text-xs text-text-3">{blocking.length ? 'Fix the steps above to publish' : 'Assign forecasters to publish'}</span>}
          <Btn onClick={() => { onAttempt(); if (ready) setConfirm(true) }} icon={<Send size={16} />}>Publish & assign</Btn>
        </div>
      </div>

      {confirm && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-brand-dark/50 p-4" role="dialog" aria-modal="true" aria-labelledby="pub-title" onKeyDown={e => e.key === 'Escape' && !busy && setConfirm(false)}>
          <div className="rise max-h-[calc(100dvh-32px)] w-full max-w-md overflow-y-auto rounded-lg bg-surface p-6 shadow-xl">
            <h2 id="pub-title" className="text-lg font-semibold">Publish {c.brand} {c.version}?</h2>
            <p className="mt-2 text-sm text-text-2">Publishing records {c.version} as the current version for this prototype. Later changes become a new version, and earlier versions stay in the audit history; scenarios built on {c.version} keep their assumptions.</p>
            <dl className="mt-4 space-y-1.5 rounded-md bg-background p-3 text-[13px]">
              {c.inds.map(i => <div key={i.id} className="flex justify-between gap-3"><dt className="text-text-2">{i.name}</dt><dd className="text-right font-medium">{ARCHETYPES.find(a => a.id === i.arch)?.name} · {i.engine}</dd></div>)}
              <div className="flex justify-between"><dt className="text-text-2">Tier</dt><dd className="font-medium">{c.grade}{c.inds.some(i => i.arch && ARCH_DETAIL[i.arch].ceiling) && ' · ceiling, can’t be re-graded by edits'}</dd></div>
              {c.inds.map(i => <div key={i.id + 'm'} className="flex justify-between gap-3"><dt className="text-text-2">Modes · {i.name}</dt><dd className="text-right text-xs">{Object.entries(i.modes).filter(([k]) => k !== 'trend').map(([, v]) => v).join(' · ')}</dd></div>)}
              <div className="flex justify-between gap-3"><dt className="text-text-2">Forecasters</dt><dd className="text-right font-medium">{assignees.join(', ')}</dd></div>
              <div className="flex justify-between gap-3"><dt className="text-text-2">Visibility</dt><dd className="text-right font-medium">{c.visibility}</dd></div>
              <div className="flex justify-between"><dt className="text-text-2">Published by</dt><dd className="font-medium">{ME} · now</dd></div>
            </dl>
            <div className="mt-6 flex justify-end gap-2">
              <Btn variant="secondary" disabled={busy} onClick={() => setConfirm(false)}>Cancel</Btn>
              <Btn disabled={busy} onClick={publish} icon={busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}>{busy ? 'Publishing…' : `Publish ${c.version}`}</Btn>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

function PublishedScreen({ c, when, onExit }: { c: Config; when: string; onExit: () => void }) {
  return (
    <main className="rise mx-auto w-full max-w-[720px] px-6 py-16">
      <span className="grid h-12 w-12 place-items-center rounded-full bg-ok-soft text-ok"><CheckCircle2 size={26} /></span>
      <div className="mt-5 flex flex-wrap items-center gap-2"><Badge tone="ok"><Check size={10} />Published</Badge><Badge tone="brand"><Users size={10} />Assigned</Badge></div>
      <h1 className="mt-2 text-[28px] font-semibold tracking-tight">{c.brand} {c.version} is live</h1>
      <p className="mt-1 text-text-2">{[...(c.selfForecast ? ['You'] : []), ...c.forecasters].join(', ')} {c.forecasters.length + (c.selfForecast ? 1 : 0) > 1 ? 'have' : 'has'} been assigned{c.forecasters.length ? ' and notified' : ''}.</p>
      <Card title="Version record" className="mt-8">
        <dl className="grid gap-x-6 gap-y-2 text-[13px] sm:grid-cols-2">
          {[['Version', `${c.version} · immutable`], ['Published', `${when} by ${ME}`], ['Market · cycle', `${c.market} · ${c.cycle}`], ['Visibility', c.visibility], ['Baseline', c.baseline ? `Run #${c.baseline.n}` : '—'], ['Tier', c.grade],
            ...c.inds.map(i => [i.name, `${ARCHETYPES.find(a => a.id === i.arch)?.name} · ${i.engine}`])].map(([k, v]) => (
            <div key={k} className="flex justify-between gap-3 border-b border-border py-1.5"><dt className="text-text-2">{k}</dt><dd className="text-right font-medium">{v}</dd></div>
          ))}
        </dl>
      </Card>
      <Card title="Next" className="mt-6">
        <ul className="space-y-2 text-sm text-text-2">
          <li className="flex gap-2"><Bell size={15} className="mt-0.5 shrink-0 text-brand" />You’ll get a notification when a forecaster submits or a feed goes stale.</li>
          <li className="flex gap-2"><GitBranch size={15} className="mt-0.5 shrink-0 text-brand" />To change anything, start a {nextVersion(c.version)} draft from Versions in the library.</li>
        </ul>
      </Card>
      <Btn className="mt-8" icon={<ArrowLeft size={16} />} onClick={onExit}>Back to library</Btn>
    </main>
  )
}

/* ───────────────────────── Profile menu & admin access control ───────────────────────── */

function ProfileMenu({ onAdmin, onLogout }: { onAdmin: () => void; onLogout: () => void }) {
  const [open, setOpen] = useState(false)
  const ref = useDismiss(open, () => setOpen(false))
  return (
    <div ref={ref} className="relative ml-1">
      <button type="button" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(v => !v)} title={`${ME} · Super User`}
        className="grid h-8 w-8 place-items-center rounded-full bg-brand-dark text-xs font-semibold text-white outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-brand">JA</button>
      {open && (
        <div role="menu" className="rise absolute right-0 top-11 z-40 w-64 overflow-hidden rounded-lg border border-border bg-surface shadow-xl">
          <div className="border-b border-border px-4 py-3">
            <p className="text-sm font-semibold">{ME}</p>
            <p className="text-xs text-text-2">j.andersen@pfizer.com</p>
            <div className="mt-2 flex gap-1"><Badge tone="brand">Super User</Badge><Badge>CoE Configurator</Badge></div>
          </div>
          <button type="button" role="menuitem" onClick={() => { setOpen(false); onAdmin() }} className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm hover:bg-surface-2"><ShieldCheck size={16} className="text-text-2" /><span><span className="block font-medium">Admin controls</span><span className="block text-xs text-text-3">Users, roles and access</span></span></button>
          <button type="button" role="menuitem" onClick={() => { setOpen(false); onLogout() }} className="flex w-full items-center gap-3 border-t border-border px-4 py-2.5 text-left text-sm hover:bg-surface-2"><LogOut size={16} className="text-text-2" />Log out</button>
        </div>
      )}
    </div>
  )
}

type Level = 'F' | 'S' | 'N'
type PersonaId = 'super' | 'editor' | 'viewer' | 'fc'
const PERSONAS: { id: PersonaId; name: string; who: string; probe?: boolean }[] = [
  { id: 'super', name: 'Super User', who: 'Manages users and admin settings. BD access is granted separately.' },
  { id: 'editor', name: 'Editor', who: 'CoE configurator. Creates models and edits configurations shared with them.' },
  { id: 'viewer', name: 'Viewer', who: 'Views configurations and outputs without editing.' },
  { id: 'fc', name: 'Forecaster', who: 'Brand forecaster on published, assigned models' },
]
// One letter per persona, in PERSONAS order: F = full, S = scoped, N = none.
const PERMS: { group: string; rows: [string, string, string][] }[] = [
  { group: 'Models', rows: [
    ['Create models (template, scratch, import)', 'FFNN', 'Creators create in their own brand and geography scope.'],
    ['Edit configuration (archetype, modes, modules)', 'FSNN', 'Editor: own or shared models.'],
    ['Publish and assign forecasters', 'FSNN', 'Editor: own models only.'],
    ['Cut formal releases (LE1, LE2)', 'FSNN', 'Editor: own models; release is immutable.'],
    ['Retire or delete models', 'FNNN', ''],
  ] },
  { group: 'Archetypes & modules', rows: [
    ['Manage archetype and module catalogue', 'FNNN', 'New archetypes need approval before forecasters see them.'],
    ['Select archetypes per revenue stream', 'FSNN', 'Within the models they can edit.'],
  ] },
  { group: 'Assumptions', rows: [
    ['Set values, bands and locks', 'FSNN', 'Within the models they can edit.'],
    ['Update assigned assumption rows', 'FSNN', 'Editor: own or shared models.'],
    ['Edit open assumptions within band', 'FNNS', 'Forecaster: inside the CoE band only.'],
  ] },
  { group: 'Data', rows: [
    ['Connect new data sources', 'FNNN', ''],
    ['Review bindings and refresh status', 'FSNS', 'Models they have access to.'],
  ] },
  { group: 'Forecasting', rows: [
    ['Run scenarios and submit forecasts', 'FNNS', 'Forecaster: assigned models.'],
  ] },
  { group: 'Access', rows: [
    ['Invite collaborators to a model', 'FSNN', 'Editor: own models. External emails need approval.'],
    ['Manage users and roles (this page)', 'FNNN', ''],
  ] },
  { group: 'Visibility', rows: [
    ['View published outputs', 'FSSS', 'Limited to assigned brands and geographies.'],
    ['View drafts', 'FSNN', 'Only models they are on.'],
    ['See confidential pricing across geographies', 'FSSN', 'Own geography unless granted.'],
    ['Access BD / pipeline models', 'SNNN', 'Granted per user by BD governance, never by role.'],
  ] },
]

type AdminUser = { id: string; name: string; email: string; persona: PersonaId; geos: string[]; brands: string[]; bd: 'No' | 'Yes'; status: 'Active' | 'Invited' | 'Suspended'; last: string }
const ADMIN_USERS: AdminUser[] = [
  { id: 'u1', name: 'J. Andersen', email: 'j.andersen@pfizer.com', persona: 'super', geos: ['Global'], brands: ['All'], bd: 'No', status: 'Active', last: 'Now' },
  { id: 'u2', name: 'K. Brandt', email: 'k.brandt@pfizer.com', persona: 'editor', geos: ['US', 'EU5'], brands: ['Elrexfio', 'Abrysvo'], bd: 'No', status: 'Active', last: 'Today, 09:40' },
  { id: 'u3', name: 'A. Nguyen', email: 'a.nguyen@pfizer.com', persona: 'editor', geos: ['US'], brands: ['Cibinqo', 'Abrysvo'], bd: 'No', status: 'Active', last: 'Yesterday' },
  { id: 'u4', name: 'E. Walsh', email: 'e.walsh@pfizer.com', persona: 'editor', geos: ['US'], brands: ['All'], bd: 'No', status: 'Active', last: 'Today, 08:02' },
  { id: 'u5', name: 'S. Patel', email: 's.patel@pfizer.com', persona: 'editor', geos: ['EU5'], brands: ['All'], bd: 'No', status: 'Active', last: 'Oct 6' },
  { id: 'u6', name: 'Michelle Tran', email: 'michelle.tran@pfizer.com', persona: 'fc', geos: ['US'], brands: ['Velsipity', 'Cibinqo'], bd: 'No', status: 'Active', last: 'Today, 10:15' },
  { id: 'u7', name: 'David Osei', email: 'david.osei@pfizer.com', persona: 'fc', geos: ['Japan'], brands: ['Nurtec ODT'], bd: 'No', status: 'Active', last: 'Oct 7' },
  { id: 'u8', name: 'L. Moreau', email: 'l.moreau@pfizer.com', persona: 'viewer', geos: ['EU5'], brands: ['All'], bd: 'No', status: 'Active', last: 'Oct 4' },
  { id: 'u9', name: 'R. Chen', email: 'r.chen@pfizer.com', persona: 'viewer', geos: ['Global'], brands: ['All'], bd: 'No', status: 'Active', last: 'Oct 3' },
  { id: 'u10', name: 'T. Okoye', email: 't.okoye@pfizer.com', persona: 'editor', geos: ['International'], brands: ['Elrexfio'], bd: 'No', status: 'Invited', last: '—' },
  { id: 'u11', name: 'M. Haddad', email: 'm.haddad@pfizer.com', persona: 'editor', geos: ['Global'], brands: ['BD pipeline'], bd: 'Yes', status: 'Active', last: 'Oct 1' },
]
const levelCls: Record<Level, string> = { F: 'bg-brand text-white', S: 'bg-brand-soft text-brand', N: 'bg-surface-2 text-text-3' }
const levelLbl: Record<Level, string> = { F: 'Full', S: 'Scoped', N: 'None' }

const GEO_OPTS = ['Global', 'US', 'EU5', 'Japan', 'International']
const BRAND_OPTS = ['All', 'Velsipity', 'Cibinqo', 'Abrysvo', 'Elrexfio', 'Nurtec ODT', 'BD pipeline']

/** Compact multi-select: shows up to two values, then "+N". Picking the "all" option clears the rest. */
function MultiPick({ label, options, value, onChange, all }: { label: string; options: string[]; value: string[]; onChange: (v: string[]) => void; all: string }) {
  const [open, setOpen] = useState(false)
  const ref = useDismiss(open, () => setOpen(false))
  const toggle = (o: string) => {
    if (o === all) return onChange([all])
    const base = value.filter(v => v !== all)
    const next = base.includes(o) ? base.filter(v => v !== o) : [...base, o]
    onChange(next.length ? next : [all])
  }
  return (
    <div ref={ref} className="relative">
      <button type="button" aria-label={label} aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(v => !v)} className={cx(inputCls(), 'flex h-8! min-w-[150px] items-center justify-between gap-2 text-left text-[13px]')}>
        <span className="truncate">{value.slice(0, 2).join(', ')}{value.length > 2 && <span className="text-text-3"> +{value.length - 2}</span>}</span><ChevronDown size={14} className="shrink-0 text-text-3" />
      </button>
      {open && (
        <div role="listbox" aria-multiselectable="true" className="rise absolute left-0 top-9 z-30 w-52 rounded-md border border-border bg-surface p-1 shadow-xl">
          {options.map(o => (
            <label key={o} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-[13px] hover:bg-surface-2">
              <input type="checkbox" className="accent-brand" checked={value.includes(o)} onChange={() => toggle(o)} />{o}
            </label>
          ))}
        </div>
      )}
    </div>
  )
}

function AccessControl({ notify, onBack }: { notify: (t: Toast) => void; onBack: () => void }) {
  const [tab, setTab] = useState('Users')
  const [users, setUsers] = useState(ADMIN_USERS)
  const [matrix, setMatrix] = useState(() => PERMS.map(g => g.rows.map(r => r[1].split('') as Level[])))
  const [dirty, setDirty] = useState(false)
  const [q, setQ] = useState('')
  const [fp, setFp] = useState<'All' | PersonaId>('All')
  const [inv, setInv] = useState<{ email: string; persona: PersonaId; geos: string[]; brands: string[] } | null>(null)
  const [audit, setAudit] = useState<LogEntry[]>([
    { what: 'M. Haddad: BD access granted', who: 'L. Ferris (BD governance)', when: 'Oct 3, 14:10' },
    { what: 'T. Okoye invited as Editor on Elrexfio (International)', who: 'K. Brandt', when: 'Oct 2, 11:30' },
    { what: 'Governance update: direct publish by CoE editors', who: ME, when: 'Sep 28, 16:45' },
  ])
  const log = (what: string) => setAudit(a => [{ what, who: ME, when: `Today, ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}` }, ...a])
  const pName = (id: PersonaId) => PERSONAS.find(p => p.id === id)!.name
  const setUser = (id: string, p: Partial<AdminUser>, msg: string) => { setUsers(us => us.map(u => u.id === id ? { ...u, ...p } : u)); log(msg) }
  const rows = users.filter(u => (fp === 'All' || u.persona === fp) && `${u.name} ${u.email} ${u.geos.join(' ')} ${u.brands.join(' ')}`.toLowerCase().includes(q.toLowerCase()))
  const cycle = (g: number, r: number, k: number) => { if (k === 0) return; setMatrix(m => m.map((gr, gi) => gi !== g ? gr : gr.map((row, ri) => ri !== r ? row : row.map((v, ci) => ci !== k ? v : (v === 'F' ? 'S' : v === 'S' ? 'N' : 'F'))))); setDirty(true) }
  const validEmail = inv && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inv.email.trim())

  return (
    <main className="mx-auto w-full max-w-[1240px] flex-1 px-6 py-10">
      <button type="button" onClick={onBack} className="flex items-center gap-1 text-sm text-text-2 hover:text-text"><ArrowLeft size={14} />Model library</button>
      <header className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-brand">Admin controls</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight">Role-based access</h1>
          <p className="mt-1 text-text-2">Who can do what, on which brands and geographies. Every change is audited.</p>
          <p className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-dashed border-warn/60 bg-warn/5 px-2.5 py-1 text-xs text-text-2"><Info size={12} className="text-warn" />Proposal for discussion. Roles, capabilities and scopes are not confirmed requirements.</p>
        </div>
        <Btn icon={<Mail size={16} />} onClick={() => { setTab('Users'); setInv({ email: '', persona: 'editor', geos: ['US'], brands: ['All'] }) }}>Invite user</Btn>
      </header>

      <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-3">
        {[[users.filter(u => u.status === 'Active').length, 'Active users', `Across ${PERSONAS.length} roles`], [users.filter(u => u.status === 'Invited').length, 'Pending invites', 'Not yet accepted'], [users.filter(u => u.persona === 'super' && u.bd === 'No').length, 'Super users without BD', 'BD is never inherited from role'], [users.filter(u => u.bd === 'Yes').length, 'BD access granted', 'Granted by BD governance only']].map(([n, l, d]) => (
          <div key={l} className="rounded-lg border border-border bg-surface p-4"><p className="font-mono text-2xl font-semibold leading-none">{n}</p><p className="mt-1 text-[13px] font-semibold">{l}</p><p className="text-xs text-text-3">{d}</p></div>
        ))}
      </div>

      <div className="mt-6 flex border-b border-border" role="tablist">
        {['Users', 'Roles & permissions', 'Access audit'].map(t => (
          <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={cx('-mb-px flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors', tab === t ? 'border-brand text-text' : 'border-transparent text-text-2 hover:text-text')}>{t}{t === 'Access audit' && <span className="rounded bg-surface-2 px-1.5 py-0.5 text-[10px] font-semibold text-text-3">Good to have</span>}</button>
        ))}
      </div>

      {tab === 'Users' && (
        <div className="mt-5 space-y-4">
          {inv && (
            <Card title="Invite by email" sub="They get an email link. Access starts at the scope you set here." right={<Btn variant="ghost" size="sm" icon={<X size={14} />} onClick={() => setInv(null)}><span className="sr-only">Cancel</span></Btn>}>
              <div className="grid gap-3 sm:grid-cols-[minmax(0,2fr)_repeat(3,minmax(0,1fr))_auto] sm:items-end">
                <Field label="Email"><input autoFocus className={inputCls()} value={inv.email} onChange={e => setInv({ ...inv, email: e.target.value })} placeholder="name@pfizer.com" /></Field>
                <Field label="Role"><select className={inputCls()} value={inv.persona} onChange={e => setInv({ ...inv, persona: e.target.value as PersonaId })}>{PERSONAS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
                <Field label="Geographies"><MultiPick label="Geographies" options={GEO_OPTS} all="Global" value={inv.geos} onChange={v => setInv({ ...inv, geos: v })} /></Field>
                <Field label="Brands"><MultiPick label="Brands" options={BRAND_OPTS} all="All" value={inv.brands} onChange={v => setInv({ ...inv, brands: v })} /></Field>
                <Btn disabled={!validEmail} onClick={() => { const e = inv.email.trim(); setUsers(us => [...us, { id: `u${Date.now()}`, name: e.split('@')[0], email: e, persona: inv.persona, geos: inv.geos, brands: inv.brands, bd: 'No', status: 'Invited', last: '—' }]); log(`${e} invited as ${pName(inv.persona)} · ${inv.geos.join(', ')} · ${inv.brands.join(', ')}`); notify({ tone: 'ok', text: `Invite emailed to ${e}.` }); setInv(null) }}>Send invite</Btn>
              </div>
            </Card>
          )}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full max-w-xs"><Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-2" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search users" className={cx(inputCls(), 'pl-9')} /></div>
            <select aria-label="Role" className={cx(inputCls(), 'w-fit!')} value={fp} onChange={e => setFp(e.target.value as typeof fp)}><option value="All">All roles</option>{PERSONAS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
          </div>
          <div className="overflow-x-auto rounded-lg border border-border bg-surface">
            <table className="w-full min-w-[900px] text-left text-[13px]">
              <thead className="border-b border-border bg-surface-2/60 text-xs text-text-2"><tr>{['User', 'Role', 'Geography', 'Brands', 'BD access', 'Status', 'Last active', ''].map(h => <th key={h} className="px-4 py-2.5 font-semibold">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-border">
                {rows.map(u => (
                  <tr key={u.id} className="align-middle">
                    <td className="px-4 py-2.5"><p className="font-semibold">{u.name}{u.name === ME && <span className="font-normal text-text-3"> (you)</span>}</p><p className="text-xs text-text-3">{u.email}</p></td>
                    <td className="px-4 py-2.5"><select aria-label={`Role for ${u.name}`} disabled={u.name === ME} className={cx(inputCls(), 'h-8! w-fit! text-[13px]')} value={u.persona} onChange={e => setUser(u.id, { persona: e.target.value as PersonaId }, `${u.name}: role ${pName(u.persona)} → ${pName(e.target.value as PersonaId)}`)}>{PERSONAS.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></td>
                    <td className="px-4 py-2.5"><MultiPick label={`Geographies for ${u.name}`} options={GEO_OPTS} all="Global" value={u.geos} onChange={v => setUser(u.id, { geos: v }, `${u.name}: geographies → ${v.join(', ')}`)} /></td>
                    <td className="px-4 py-2.5"><MultiPick label={`Brands for ${u.name}`} options={BRAND_OPTS} all="All" value={u.brands} onChange={v => setUser(u.id, { brands: v }, `${u.name}: brands → ${v.join(', ')}`)} /></td>
                    <td className="px-4 py-2.5"><span className="flex items-center gap-2"><Switch label={`BD access for ${u.name}`} on={u.bd === 'Yes'} onChange={v => setUser(u.id, { bd: v ? 'Yes' : 'No' }, `${u.name}: BD access ${v ? 'granted' : 'revoked'}`)} /><span className="text-xs text-text-2">{u.bd === 'Yes' ? 'Granted' : 'No access'}</span></span></td>
                    <td className="px-4 py-2.5"><Badge tone={u.status === 'Active' ? 'ok' : u.status === 'Invited' ? 'brand' : 'err'}>{u.status}</Badge></td>
                    <td className="px-4 py-2.5 text-text-3">{u.last}</td>
                    <td className="px-4 py-2.5 text-right">{u.name !== ME && <Btn variant="ghost" size="sm" onClick={() => setUser(u.id, { status: u.status === 'Suspended' ? 'Active' : 'Suspended' }, `${u.name}: ${u.status === 'Suspended' ? 'reactivated' : 'suspended'}`)}>{u.status === 'Suspended' ? 'Reactivate' : 'Suspend'}</Btn>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-text-3">Geography, brand and BD access are set independently of role. BD access is never inherited, including by Super Users, and only an authorised administrator can grant or revoke it. Model-level sharing (Editor or Viewer) is set from Share in the configurator.</p>
        </div>
      )}

      {tab === 'Roles & permissions' && (
        <div className="mt-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="w-full text-xs text-text-3">Governance capability list across CoE, Forecaster, and administrative roles.</p>
            <div className="flex flex-wrap items-center gap-3 text-xs text-text-2">{(['F', 'S', 'N'] as Level[]).map(l => <span key={l} className="flex items-center gap-1.5"><span className={cx('rounded px-1.5 py-0.5 text-[10px] font-semibold', levelCls[l])}>{levelLbl[l]}</span>{l === 'F' ? 'All models in scope' : l === 'S' ? 'Own, shared or assigned models, brands and geographies' : 'No access'}</span>)}<span className="text-text-3">Click a cell to change it.</span></div>
            <div className="flex gap-2">{dirty && <Btn variant="secondary" size="sm" onClick={() => { setMatrix(PERMS.map(g => g.rows.map(r => r[1].split('') as Level[]))); setDirty(false) }}>Discard</Btn>}<Btn size="sm" disabled={!dirty} onClick={() => { setDirty(false); log('Permission matrix updated'); notify({ tone: 'ok', text: 'Permissions saved. Changes apply at next sign-in.' }) }}>Save changes</Btn></div>
          </div>
          <div className="overflow-x-auto rounded-lg border border-border bg-surface">
            <table className="w-full min-w-[980px] text-[13px]">
              <thead className="sticky top-0 border-b border-border bg-surface">
                <tr><th className="w-[300px] px-4 py-3 text-left text-xs font-semibold text-text-2">Capability</th>{PERSONAS.map(p => (
                  <th key={p.id} className="px-2 py-3 text-center align-bottom">
                    <span className={cx('inline-flex items-center gap-1 text-[13px] font-semibold', p.probe && 'text-text-3')}>{p.name}{p.probe && '?'}
                      <span className="group relative inline-flex">
                        <button type="button" aria-label={`About ${p.name}: ${p.who}`} className="grid h-4 w-4 place-items-center rounded-full text-text-3 outline-none hover:text-brand focus-visible:text-brand"><Info size={13} /></button>
                        <span role="tooltip" className="pointer-events-none absolute left-1/2 top-full z-20 mt-1.5 w-48 -translate-x-1/2 rounded-md bg-text px-2.5 py-1.5 text-left text-[11px] font-normal leading-snug text-white opacity-0 shadow-lg transition-opacity group-hover:opacity-100 group-focus-within:opacity-100">{p.who}</span>
                      </span>
                    </span>
                  </th>
                ))}</tr>
              </thead>
              {PERMS.map((g, gi) => (
                <tbody key={g.group} className="divide-y divide-border border-t border-border">
                  <tr><td colSpan={PERSONAS.length + 1} className="bg-surface-2/60 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-text-3">{g.group}</td></tr>
                  {g.rows.map(([name, , note], ri) => (
                    <tr key={name}>
                      <td className="px-4 py-2.5"><p className="font-medium">{name}</p>{note && <p className="text-[11px] text-text-3">{note}</p>}</td>
                      {matrix[gi][ri].map((v, k) => (
                        <td key={k} className="px-2 py-2 text-center">
                          <button type="button" onClick={() => cycle(gi, ri, k)} disabled={k === 0} title={k === 0 ? 'Super User access is fixed' : `${PERSONAS[k].name}: ${levelLbl[v]} — click to change`} className={cx('min-w-[64px] rounded px-2 py-1 text-[11px] font-semibold transition-opacity', levelCls[v], k === 0 ? 'cursor-default' : 'hover:opacity-80')}>{levelLbl[v]}</button>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              ))}
            </table>
          </div>
        </div>
      )}

      {tab === 'Access audit' && (
        <Card className="mt-5" title="Access audit" sub="Role, scope and BD access changes. Retained with model version history.">
          <ol className="space-y-3">{audit.map((e, k) => <li key={k} className="flex gap-3 text-[13px]"><span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" /><div><p>{e.what}</p><p className="text-xs text-text-3">{e.who} · {e.when}</p></div></li>)}</ol>
        </Card>
      )}
    </main>
  )
}
